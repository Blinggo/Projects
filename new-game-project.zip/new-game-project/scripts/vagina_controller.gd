class_name VaginaController
extends Node

# ============================================================
# VAGINA CONTROLLER - PHASE 3
# - Wetness system + shader
# - Color reaction (blood flow)
# - Edging mechanic
# - Sensitivity zones with response curves
# Godot 4.6.1 - Mobile Renderer Compatible
# ============================================================

# --- MESH REFERENCE ---
@export var mesh_instance: MeshInstance3D

# --- CHARACTER PROFILE ---
@export_group("Character Profile")
## Optional: Assign a CharacterProfile resource to auto-load on _ready
@export var initial_profile: CharacterProfile
## Apply the initial_profile automatically when the scene starts
@export var auto_apply_initial_profile: bool = true

# --- WETNESS SHADER ---
@export_group("Wetness Shader Setup")
## Path to the wetness shader resource
@export var wetness_shader: Shader
## Optional: pre-existing albedo texture from your model
@export var albedo_texture_override: Texture2D
@export var normal_texture_override: Texture2D
@export var roughness_texture_override: Texture2D
## Auto-extract textures from existing material on _ready
@export var auto_extract_textures: bool = true

# --- SHAPE KEY NAMES ---
@export_group("Shape Key Names")
@export var sk_open_close: String = "Vagina Open/Closed"
@export var sk_labia_minora_length: String = "Labia Minora Length"
@export var sk_labia_minora_shape: String = "Labia Minora Shape"
@export var sk_labia_minora_symmetry: String = "Labia Minora Symmetry"
@export var sk_labia_majora_puff: String = "Labia Majora Puff"
@export var sk_clit_size: String = "Clit Size"
@export var sk_clit_hood_scale: String = "Clit Hood Scale"
@export var invert_open_close: bool = false

# --- CHARACTER CUSTOMIZATION ---
@export_group("Base Anatomy Customization")
@export_range(-1.0, 1.0, 0.01) var base_open_close: float = -0.3
@export_range(-1.0, 1.0, 0.01) var base_labia_minora_length: float = 0.0
@export_range(-1.0, 1.0, 0.01) var base_labia_minora_shape: float = 0.0
@export_range(-1.0, 1.0, 0.01) var base_labia_symmetry: float = -0.05
@export_range(-1.0, 1.0, 0.01) var base_majora_puff: float = 0.0
@export_range(-1.0, 1.0, 0.01) var base_clit_size: float = 0.0
@export_range(-1.0, 1.0, 0.01) var base_clit_hood: float = 0.3

# --- AROUSAL SYSTEM ---
@export_group("Arousal System")
@export_range(0.0, 2.0, 0.01) var arousal_build_rate: float = 0.25
@export_range(0.0, 1.0, 0.01) var arousal_decay_rate: float = 0.08
@export_range(0.0, 2.0, 0.01) var penetration_arousal_factor: float = 0.7
@export_range(0.0, 2.0, 0.01) var clit_arousal_factor: float = 1.2

# --- SENSITIVITY ZONES (NEW) ---
@export_group("Sensitivity Zones")
## Curve shape for clit response: 1.0=linear, >1=requires more stim, <1=very sensitive
@export_range(0.3, 3.0, 0.1) var clit_response_curve: float = 0.6
## Curve for penetration: most people need rhythm, not just pressure
@export_range(0.3, 3.0, 0.1) var penetration_response_curve: float = 1.3
## Curve for general stimulation
@export_range(0.3, 3.0, 0.1) var general_response_curve: float = 1.0

# --- EDGING (NEW) ---
@export_group("Edging Mechanic")
@export var enable_edging: bool = true
## Arousal threshold where edging kicks in (must be below 1.0)
@export_range(0.5, 0.99, 0.01) var edge_threshold: float = 0.85
## How strong the edge resistance gets (multiplier on arousal building)
@export_range(0.0, 1.0, 0.01) var edge_resistance_strength: float = 0.7
## How fast edge resistance builds while at edge (per second)
@export_range(0.0, 2.0, 0.01) var edge_resistance_build_rate: float = 0.5
## Stimulation intensity needed to break past the edge (0-1 scale)
@export_range(0.5, 1.5, 0.01) var edge_break_threshold: float = 0.95

# --- WETNESS (NEW) ---
@export_group("Wetness System")
@export var enable_wetness: bool = true
## How fast wetness builds with arousal (per second)
@export_range(0.0, 1.0, 0.01) var wetness_build_rate: float = 0.15
## How fast wetness evaporates without stimulation (per second)
@export_range(0.0, 0.5, 0.01) var wetness_decay_rate: float = 0.03
## Maximum wetness level
@export_range(0.0, 1.0, 0.01) var max_wetness: float = 0.9
## Wetness gets boosted by this amount when orgasming
@export_range(0.0, 1.0, 0.01) var orgasm_wetness_boost: float = 0.3

# --- COLOR REACTION (NEW) ---
@export_group("Color Reaction")
@export var enable_color_reaction: bool = true
## Color tint applied at full arousal (slight pink/red shift)
@export var arousal_color: Color = Color(1.15, 0.78, 0.82)
## Strength of color shift at max arousal
@export_range(0.0, 1.0, 0.01) var color_shift_strength: float = 0.35
## Subtle warm emission when very aroused
@export_range(0.0, 0.3, 0.01) var arousal_emission_strength: float = 0.05

# --- TUNING - OPENING ---
@export_group("Tuning - Opening Behavior")
@export_range(0.0, 1.0, 0.01) var arousal_opens_amount: float = 0.35
@export_range(0.0, 1.0, 0.01) var penetration_opens_amount: float = 0.85
@export_range(0.0, 1.0, 0.01) var gape_opens_amount: float = 0.6

# --- TUNING - SWELLING ---
@export_group("Tuning - Swelling Behavior")
@export_range(0.0, 1.0, 0.01) var arousal_swells_majora: float = 0.5
@export_range(0.0, 1.0, 0.01) var arousal_swells_clit: float = 0.4
@export_range(0.0, 1.0, 0.01) var stim_swells_clit: float = 0.5
@export_range(0.0, 1.0, 0.01) var arousal_retracts_hood: float = 0.6
@export_range(0.0, 1.0, 0.01) var stim_retracts_hood: float = 0.4

# --- GAPE SYSTEM ---
@export_group("Gape System")
@export_range(0.0, 1.0, 0.01) var gape_buildup_threshold: float = 0.6
@export_range(0.0, 1.0, 0.01) var gape_buildup_rate: float = 0.15
@export_range(0.0, 1.0, 0.01) var gape_recovery_rate: float = 0.05

# --- PULSING ---
@export_group("Pulsing & Throbbing")
@export var enable_pulsing: bool = true
@export_range(0.5, 3.0, 0.1) var heartbeat_speed: float = 1.2
@export_range(0.0, 0.3, 0.01) var clit_pulse_amount: float = 0.06
@export_range(0.0, 0.2, 0.01) var majora_pulse_amount: float = 0.03
@export_range(0.0, 0.15, 0.01) var opening_pulse_amount: float = 0.025

# --- ORGASM ---
@export_group("Orgasm Settings")
@export_range(1.0, 8.0, 0.1) var orgasm_duration: float = 4.0
@export_range(2.0, 8.0, 0.1) var orgasm_contraction_speed: float = 4.5
@export_range(0.0, 1.0, 0.01) var orgasm_contraction_strength: float = 0.5
## If true, orgasm only triggers when arousal is high enough
@export var require_high_arousal_for_orgasm: bool = true
@export_range(0.5, 1.0, 0.01) var orgasm_required_arousal: float = 0.95

# --- REFRACTORY PERIOD ---
@export_group("Refractory Period")
@export var enable_refractory: bool = true
@export var refractory_type: CharacterProfile.RefractoryType = CharacterProfile.RefractoryType.OVERSENSITIVE
@export_range(0.0, 60.0, 0.5) var refractory_duration: float = 8.0
@export_range(1.0, 10.0, 0.1) var refractory_arousal_decay_multiplier: float = 3.0
@export_range(0.0, 3.0, 0.05) var refractory_clit_sensitivity: float = 2.5
@export_range(0.0, 2.0, 0.05) var refractory_general_sensitivity: float = 0.4
@export_range(0.1, 2.0, 0.05) var refractory_wetness_persistence: float = 0.3

# --- DEBUG ---
@export_group("Debug")
@export var show_debug_ui: bool = true
@export var debug_print_values: bool = false

# --- INTERNAL ---
var state: VaginaState
var _shape_key_indices: Dictionary = {}
var _is_valid: bool = false
var _smooth_open: float = -0.3
var _smooth_majora: float = 0.0
var _smooth_clit_size: float = 0.0
var _smooth_hood: float = 0.3

# Shader material
var _wetness_material: ShaderMaterial
var _has_shader: bool = false

const SMOOTH_SPEED: float = 6.0


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	state = VaginaState.new()
	if auto_apply_initial_profile and initial_profile:
		apply_profile(initial_profile)
	_smooth_open = base_open_close
	_smooth_hood = base_clit_hood
	_validate_setup()
	if _is_valid:
		_cache_shape_key_indices()
		_setup_wetness_shader()
		print("[VaginaController] Phase 4A system initialized.")


func _process(delta: float) -> void:
	if not _is_valid:
		return
	
	_update_arousal(delta)
	_update_edging(delta)
	_update_gape(delta)
	_update_wetness(delta)
	_update_orgasm(delta)
	_update_refractory(delta)
	_update_pulse_phases(delta)
	_update_morphs(delta)
	_update_shader_uniforms()
	
	state.reset_frame_inputs()
	
	if debug_print_values and Engine.get_process_frames() % 30 == 0:
		_print_debug_info()

# ============================================================
# PROFILE SYSTEM - PHASE 4A
# ============================================================

## Apply a CharacterProfile to this controller (overwrites all customization)
func apply_profile(profile: CharacterProfile) -> void:
	if not profile:
		push_warning("[VaginaController] apply_profile called with null profile")
		return
		
	
	# Base Anatomy
	base_open_close = profile.base_open_close
	base_labia_minora_length = profile.base_labia_minora_length
	base_labia_minora_shape = profile.base_labia_minora_shape
	base_labia_symmetry = profile.base_labia_symmetry
	base_majora_puff = profile.base_majora_puff
	base_clit_size = profile.base_clit_size
	base_clit_hood = profile.base_clit_hood
	
	# Sensitivity & Arousal
	arousal_build_rate = profile.arousal_build_rate
	arousal_decay_rate = profile.arousal_decay_rate
	penetration_arousal_factor = profile.penetration_arousal_factor
	clit_arousal_factor = profile.clit_arousal_factor
	clit_response_curve = profile.clit_response_curve
	penetration_response_curve = profile.penetration_response_curve
	general_response_curve = profile.general_response_curve
	
	# Wetness
	wetness_build_rate = profile.wetness_build_rate
	wetness_decay_rate = profile.wetness_decay_rate
	max_wetness = profile.max_wetness
	
	# Edging
	enable_edging = profile.enable_edging
	edge_threshold = profile.edge_threshold
	edge_resistance_strength = profile.edge_resistance_strength
	edge_resistance_build_rate = profile.edge_resistance_build_rate
	edge_break_threshold = profile.edge_break_threshold
	
	# Orgasm
	orgasm_duration = profile.orgasm_duration
	orgasm_contraction_speed = profile.orgasm_contraction_speed
	orgasm_contraction_strength = profile.orgasm_contraction_strength
	orgasm_required_arousal = profile.orgasm_required_arousal
	
	# Gape
	gape_buildup_threshold = profile.gape_buildup_threshold
	gape_buildup_rate = profile.gape_buildup_rate
	gape_recovery_rate = profile.gape_recovery_rate
	
	# Color
	arousal_color = profile.arousal_color
	color_shift_strength = profile.color_shift_strength
	arousal_emission_strength = profile.arousal_emission_strength
	
	# Smooth state values reset to new base values
	_smooth_open = base_open_close
	_smooth_hood = base_clit_hood
	
	# Refractory
	refractory_type = profile.refractory_type
	refractory_duration = profile.refractory_duration
	refractory_arousal_decay_multiplier = profile.refractory_arousal_decay_multiplier
	refractory_clit_sensitivity = profile.refractory_clit_sensitivity
	refractory_general_sensitivity = profile.refractory_general_sensitivity
	refractory_wetness_persistence = profile.refractory_wetness_persistence
	print("[VaginaController] Applied profile: '", profile.profile_name, "'")
	
	# Voice profile
	apply_voice_profile(profile)
	
	# Particle profile
	apply_particle_profile(profile)
	
	# Realistic spray
	apply_spray_profile(profile)
	
	# Cream
	apply_cream_profile(profile)

## Extract current settings into a new CharacterProfile (for saving)
func extract_current_as_profile(profile_name_str: String = "Custom") -> CharacterProfile:
	var profile: CharacterProfile = CharacterProfile.new()
	profile.profile_name = profile_name_str
	
	# Base Anatomy
	profile.base_open_close = base_open_close
	profile.base_labia_minora_length = base_labia_minora_length
	profile.base_labia_minora_shape = base_labia_minora_shape
	profile.base_labia_symmetry = base_labia_symmetry
	profile.base_majora_puff = base_majora_puff
	profile.base_clit_size = base_clit_size
	profile.base_clit_hood = base_clit_hood
	
	# Sensitivity
	profile.arousal_build_rate = arousal_build_rate
	profile.arousal_decay_rate = arousal_decay_rate
	profile.penetration_arousal_factor = penetration_arousal_factor
	profile.clit_arousal_factor = clit_arousal_factor
	profile.clit_response_curve = clit_response_curve
	profile.penetration_response_curve = penetration_response_curve
	profile.general_response_curve = general_response_curve
	
	# Wetness
	profile.wetness_build_rate = wetness_build_rate
	profile.wetness_decay_rate = wetness_decay_rate
	profile.max_wetness = max_wetness
	
	# Edging
	profile.enable_edging = enable_edging
	profile.edge_threshold = edge_threshold
	profile.edge_resistance_strength = edge_resistance_strength
	profile.edge_resistance_build_rate = edge_resistance_build_rate
	profile.edge_break_threshold = edge_break_threshold
	
	# Orgasm
	profile.orgasm_duration = orgasm_duration
	profile.orgasm_contraction_speed = orgasm_contraction_speed
	profile.orgasm_contraction_strength = orgasm_contraction_strength
	profile.orgasm_required_arousal = orgasm_required_arousal
	
	# Gape
	profile.gape_buildup_threshold = gape_buildup_threshold
	profile.gape_buildup_rate = gape_buildup_rate
	profile.gape_recovery_rate = gape_recovery_rate
	
	# Color
	profile.arousal_color = arousal_color
	profile.color_shift_strength = color_shift_strength
	profile.arousal_emission_strength = arousal_emission_strength
	
	# Refractory
	profile.refractory_type = refractory_type
	profile.refractory_duration = refractory_duration
	profile.refractory_arousal_decay_multiplier = refractory_arousal_decay_multiplier
	profile.refractory_clit_sensitivity = refractory_clit_sensitivity
	profile.refractory_general_sensitivity = refractory_general_sensitivity
	profile.refractory_wetness_persistence = refractory_wetness_persistence
	
	return profile


## Save current settings as a profile to disk
func save_current_as_profile(profile_name_str: String, file_path: String) -> bool:
	var profile: CharacterProfile = extract_current_as_profile(profile_name_str)
	return profile.save_to_disk(file_path)


## Load a profile from disk and apply it
func load_and_apply_profile(file_path: String) -> bool:
	var profile: CharacterProfile = CharacterProfile.load_from_disk(file_path)
	if profile:
		apply_profile(profile)
		return true
	return false
	
# ============================================================
# PUBLIC API
# ============================================================

func apply_arousal_stimulation(amount: float) -> void:
	state.arousal_input_this_frame += amount

func set_penetration(amount: float) -> void:
	state.penetration_input_this_frame = clampf(amount, 0.0, 1.0)

func apply_clit_stimulation(amount: float) -> void:
	state.clit_stim_input_this_frame = clampf(amount, 0.0, 1.0)

func trigger_orgasm() -> void:
	if require_high_arousal_for_orgasm and state.accumulated_arousal < orgasm_required_arousal:
		print("[VaginaController] Orgasm denied - arousal too low (", snappedf(state.accumulated_arousal, 0.01), "/", orgasm_required_arousal, ")")
		return
	state.is_orgasming = true
	state.orgasm_time = 0.0
	state.edge_resistance = 0.0  # Clear edging when orgasming
	state.is_edging = false
	print("[VaginaController] Orgasm triggered!")

func reset() -> void:
	state.reset_all()
	_smooth_open = base_open_close
	_smooth_majora = 0.0
	_smooth_clit_size = 0.0
	_smooth_hood = base_clit_hood

func get_arousal() -> float:
	return state.accumulated_arousal

func get_gape() -> float:
	return state.accumulated_gape

func get_wetness() -> float:
	return state.accumulated_wetness

func is_at_edge() -> bool:
	return state.is_edging


# ============================================================
# AROUSAL with sensitivity curves
# ============================================================

func _update_arousal(delta: float) -> void:
	# Get refractory modifiers
	var clit_mod: float = _get_refractory_clit_modifier()
	var general_mod: float = _get_refractory_general_modifier()
	
	# Apply sensitivity curves to each input
	var clit_response: float = pow(state.clit_stim_input_this_frame, clit_response_curve)
	var pen_response: float = pow(state.penetration_input_this_frame, penetration_response_curve)
	var general_response: float = pow(min(state.arousal_input_this_frame, 1.0), general_response_curve)
	
	var total_stim: float = 0.0
	total_stim += general_response * general_mod
	total_stim += pen_response * penetration_arousal_factor * general_mod
	total_stim += clit_response * clit_arousal_factor * clit_mod
	
	# Apply edge resistance if at edge
	var build_modifier: float = 1.0
	if state.is_edging:
		build_modifier = 1.0 - (state.edge_resistance * edge_resistance_strength)
		build_modifier = maxf(build_modifier, 0.05)
	
	# Apply refractory faster decay
	var current_decay: float = arousal_decay_rate
	if state.is_in_refractory:
		current_decay *= refractory_arousal_decay_multiplier
	
	if total_stim > 0.0:
		state.accumulated_arousal += total_stim * arousal_build_rate * build_modifier * delta
	else:
		state.accumulated_arousal -= current_decay * delta
	
	state.accumulated_arousal = clampf(state.accumulated_arousal, 0.0, 1.0)
	state.current_penetration = state.penetration_input_this_frame
	state.current_clit_stim = state.clit_stim_input_this_frame


# ============================================================
# EDGING SYSTEM
# ============================================================

func _update_edging(delta: float) -> void:
	if not enable_edging or state.is_orgasming:
		state.is_edging = false
		state.edge_resistance = lerpf(state.edge_resistance, 0.0, delta * 2.0)
		return
	
	# Are we in the edge zone?
	if state.accumulated_arousal >= edge_threshold and state.accumulated_arousal < 1.0:
		state.is_edging = true
		# Build resistance over time (makes it harder to push through)
		state.edge_resistance += edge_resistance_build_rate * delta
		state.edge_resistance = clampf(state.edge_resistance, 0.0, 1.0)
		
		# Clamp arousal at the threshold unless stimulation is intense enough
		var current_stim_intensity: float = max(
			state.clit_stim_input_this_frame * clit_arousal_factor,
			state.penetration_input_this_frame * penetration_arousal_factor
		)
		# Need very high stimulation to break the edge
		if current_stim_intensity < edge_break_threshold:
			state.accumulated_arousal = minf(state.accumulated_arousal, edge_threshold + 0.05)
	else:
		state.is_edging = false
		# Resistance fades when not at edge
		state.edge_resistance = lerpf(state.edge_resistance, 0.0, delta * 0.5)


# ============================================================
# GAPE
# ============================================================

func _update_gape(delta: float) -> void:
	if state.current_penetration > gape_buildup_threshold:
		var intensity: float = (state.current_penetration - gape_buildup_threshold) / (1.0 - gape_buildup_threshold)
		state.accumulated_gape += intensity * gape_buildup_rate * delta
	else:
		state.accumulated_gape -= gape_recovery_rate * delta
	state.accumulated_gape = clampf(state.accumulated_gape, 0.0, 1.0)


# ============================================================
# WETNESS
# ============================================================

func _update_wetness(delta: float) -> void:
	if not enable_wetness:
		state.accumulated_wetness = 0.0
		return
	
	var has_stimulation: bool = (
		state.arousal_input_this_frame > 0.0 or
		state.penetration_input_this_frame > 0.0 or
		state.clit_stim_input_this_frame > 0.0
	)
	
	if state.accumulated_arousal > 0.2 or has_stimulation:
		var build: float = wetness_build_rate * (0.3 + state.accumulated_arousal * 0.7) * delta
		state.accumulated_wetness += build
	else:
		# Wetness decays slower during refractory (lingering wetness from orgasm)
		var current_decay: float = wetness_decay_rate
		if state.is_in_refractory:
			current_decay *= refractory_wetness_persistence
		state.accumulated_wetness -= current_decay * delta
	
	if state.is_orgasming and state.orgasm_intensity > 0.5:
		state.accumulated_wetness += orgasm_wetness_boost * delta
	
	state.accumulated_wetness = clampf(state.accumulated_wetness, 0.0, max_wetness)

# ============================================================
# ORGASM
# ============================================================

func _update_orgasm(delta: float) -> void:
	if not state.is_orgasming:
		state.orgasm_intensity = lerpf(state.orgasm_intensity, 0.0, delta * 3.0)
		return
	
	state.orgasm_time += delta
	var t: float = state.orgasm_time / orgasm_duration
	
	if t < 0.15:
		state.orgasm_intensity = t / 0.15
	elif t < 0.7:
		state.orgasm_intensity = 1.0
	else:
		state.orgasm_intensity = 1.0 - ((t - 0.7) / 0.3)
	
	state.orgasm_intensity = clampf(state.orgasm_intensity, 0.0, 1.0)
	state.accumulated_arousal = maxf(state.accumulated_arousal, 0.85)
	
	if state.orgasm_time >= orgasm_duration:
		state.is_orgasming = false
		state.orgasm_intensity = 0.0
		# Post-orgasm: slight arousal drop
		state.accumulated_arousal *= 0.6
		
		# ENTER REFRACTORY PERIOD
		if enable_refractory:
			_enter_refractory()
			
		print("[VaginaController] Orgasm complete. 
		Total Orgasms: ", state.orgasm_count)
		
# ============================================================
# REFRACTORY PERIOD (NEW)
# ============================================================

func _enter_refractory() -> void:
	state.is_in_refractory = true
	state.refractory_time = 0.0
	state.refractory_duration = refractory_duration
	state.refractory_progress = 0.0
	
	var type_name: String = ""
	match refractory_type:
		CharacterProfile.RefractoryType.OVERSENSITIVE:
			type_name = "OVERSENSITIVE (clit hyper-sensitive)"
		CharacterProfile.RefractoryType.MULTI_ORGASMIC:
			type_name = "MULTI_ORGASMIC (chain orgasms possible)"
		CharacterProfile.RefractoryType.EXHAUSTED:
			type_name = "EXHAUSTED (all sensitivity reduced)"
	
	print("[VaginaController] Entered refractory period: ", type_name, " for ", refractory_duration, "s")


func _update_refractory(delta: float) -> void:
	if not state.is_in_refractory:
		return
	
	state.refractory_time += delta
	state.refractory_progress = clampf(state.refractory_time / state.refractory_duration, 0.0, 1.0)
	
	# Exit refractory when complete
	if state.refractory_progress >= 1.0:
		state.is_in_refractory = false
		state.refractory_time = 0.0
		state.refractory_progress = 0.0
		print("[VaginaController] Refractory period ended. Sensitivity restored.")


## Get the current sensitivity modifier for clit stimulation
## Returns 1.0 normally, varies during refractory based on type
func _get_refractory_clit_modifier() -> float:
	if not state.is_in_refractory:
		return 1.0
	
	# Effect fades as refractory progresses (1.0 at start, back to 1.0 at end)
	var fade: float = 1.0 - state.refractory_progress
	
	match refractory_type:
		CharacterProfile.RefractoryType.OVERSENSITIVE:
			# Clit becomes hyper-sensitive (more reactive but uncomfortable)
			return lerpf(1.0, refractory_clit_sensitivity, fade)
		CharacterProfile.RefractoryType.MULTI_ORGASMIC:
			# Slightly reduced but still very functional
			return lerpf(1.0, 0.85, fade)
		CharacterProfile.RefractoryType.EXHAUSTED:
			# Numb feeling
			return lerpf(1.0, 0.3, fade)
	return 1.0


## Get the current sensitivity modifier for general/penetration stimulation
func _get_refractory_general_modifier() -> float:
	if not state.is_in_refractory:
		return 1.0
	
	var fade: float = 1.0 - state.refractory_progress
	
	match refractory_type:
		CharacterProfile.RefractoryType.OVERSENSITIVE:
			return lerpf(1.0, refractory_general_sensitivity, fade)
		CharacterProfile.RefractoryType.MULTI_ORGASMIC:
			return lerpf(1.0, 0.9, fade)
		CharacterProfile.RefractoryType.EXHAUSTED:
			return lerpf(1.0, 0.2, fade)
	return 1.0


## Public: check if currently in refractory period
func is_in_refractory() -> bool:
	return state.is_in_refractory


## Public: get refractory progress (0 = just orgasmed, 1 = recovered)
func get_refractory_progress() -> float:
	return state.refractory_progress


## Public: get total orgasm count
func get_orgasm_count() -> int:
	return state.orgasm_count


# ============================================================
# PULSE PHASES
# ============================================================

func _update_pulse_phases(delta: float) -> void:
	var current_heartbeat_speed: float = heartbeat_speed * (1.0 + state.accumulated_arousal * 0.6)
	state.heartbeat_phase += delta * current_heartbeat_speed * TAU
	state.pulse_phase += delta * 1.5 * TAU
	
	if state.heartbeat_phase > TAU * 100.0:
		state.heartbeat_phase = fmod(state.heartbeat_phase, TAU)
	if state.pulse_phase > TAU * 100.0:
		state.pulse_phase = fmod(state.pulse_phase, TAU)


# ============================================================
# MORPH UPDATE
# ============================================================

func _update_morphs(delta: float) -> void:
	var a: float = state.accumulated_arousal
	var p: float = state.current_penetration
	var g: float = state.accumulated_gape
	var cs: float = state.current_clit_stim
	var orgasm: float = state.orgasm_intensity
	
	var heartbeat_pulse: float = 0.0
	var orgasm_pulse: float = 0.0
	
	if enable_pulsing:
		var hb: float = (sin(state.heartbeat_phase) + 1.0) * 0.5
		heartbeat_pulse = pow(hb, 3.0) * a
	
	if orgasm > 0.0:
		orgasm_pulse = sin(state.orgasm_time * orgasm_contraction_speed * TAU) * orgasm
	
	# OPEN/CLOSE
	var open_target: float = 0.0
	open_target += a * arousal_opens_amount
	open_target += p * penetration_opens_amount
	open_target += g * gape_opens_amount
	open_target += heartbeat_pulse * opening_pulse_amount
	open_target -= orgasm_pulse * orgasm_contraction_strength
	var final_open: float = remap(open_target, 0.0, 1.0, base_open_close, 1.0)
	final_open = clampf(final_open, -1.0, 1.0)
	if invert_open_close:
		final_open = -final_open
	_smooth_open = _lerp_toward(_smooth_open, final_open, SMOOTH_SPEED, delta)
	_set_shape_key(sk_open_close, _smooth_open)
	
	# LABIA MINORA
	var minora_length: float = base_labia_minora_length + (a * 0.15)
	_set_shape_key(sk_labia_minora_length, clampf(minora_length, -1.0, 1.0))
	_set_shape_key(sk_labia_minora_shape, base_labia_minora_shape)
	_set_shape_key(sk_labia_minora_symmetry, base_labia_symmetry)
	
	# MAJORA PUFF
	var majora_target: float = base_majora_puff + (a * a * arousal_swells_majora)
	majora_target += heartbeat_pulse * majora_pulse_amount
	majora_target += orgasm_pulse * 0.1
	_smooth_majora = _lerp_toward(_smooth_majora, majora_target, SMOOTH_SPEED, delta)
	_set_shape_key(sk_labia_majora_puff, clampf(_smooth_majora, -1.0, 1.0))
	
	# CLIT SIZE
	var clit_target: float = base_clit_size
	clit_target += a * arousal_swells_clit
	clit_target += cs * stim_swells_clit
	clit_target += heartbeat_pulse * clit_pulse_amount
	clit_target += orgasm_pulse * 0.15
	_smooth_clit_size = _lerp_toward(_smooth_clit_size, clit_target, SMOOTH_SPEED, delta)
	_set_shape_key(sk_clit_size, clampf(_smooth_clit_size, -1.0, 1.0))
	
	# CLIT HOOD
	var hood_target: float = base_clit_hood
	hood_target -= a * arousal_retracts_hood
	hood_target -= cs * stim_retracts_hood
	hood_target -= orgasm * 0.3
	_smooth_hood = _lerp_toward(_smooth_hood, hood_target, SMOOTH_SPEED, delta)
	_set_shape_key(sk_clit_hood_scale, clampf(_smooth_hood, -1.0, 1.0))


# ============================================================
# SHADER SETUP & UPDATE
# ============================================================

func _setup_wetness_shader() -> void:
	if not enable_wetness and not enable_color_reaction:
		return
	
	if not wetness_shader:
		push_warning("[VaginaController] No wetness_shader assigned. Wetness/color visual effects disabled.")
		return
	
	if not mesh_instance or not mesh_instance.mesh:
		return
	
	# Try to extract textures from existing material
	var existing_albedo: Texture2D = albedo_texture_override
	var existing_normal: Texture2D = normal_texture_override
	var existing_roughness: Texture2D = roughness_texture_override
	
	if auto_extract_textures:
		var existing_mat: Material = mesh_instance.get_active_material(0)
		if existing_mat is StandardMaterial3D:
			var sm: StandardMaterial3D = existing_mat as StandardMaterial3D
			if not existing_albedo and sm.albedo_texture:
				existing_albedo = sm.albedo_texture
			if not existing_normal and sm.normal_texture:
				existing_normal = sm.normal_texture
			if not existing_roughness and sm.roughness_texture:
				existing_roughness = sm.roughness_texture
			print("[VaginaController] Extracted textures from existing StandardMaterial3D.")
	
	# Build the shader material
	_wetness_material = ShaderMaterial.new()
	_wetness_material.shader = wetness_shader
	
	if existing_albedo:
		_wetness_material.set_shader_parameter("albedo_texture", existing_albedo)
		_wetness_material.set_shader_parameter("use_albedo_texture", true)
	else:
		_wetness_material.set_shader_parameter("use_albedo_texture", false)
	
	if existing_normal:
		_wetness_material.set_shader_parameter("normal_texture", existing_normal)
		_wetness_material.set_shader_parameter("use_normal_texture", true)
	else:
		_wetness_material.set_shader_parameter("use_normal_texture", false)
	
	if existing_roughness:
		_wetness_material.set_shader_parameter("roughness_texture", existing_roughness)
		_wetness_material.set_shader_parameter("use_roughness_texture", true)
	else:
		_wetness_material.set_shader_parameter("use_roughness_texture", false)
	
	# Apply the material to the mesh (override slot 0)
	mesh_instance.set_surface_override_material(0, _wetness_material)
	_has_shader = true
	print("[VaginaController] Wetness shader applied successfully.")


func _update_shader_uniforms() -> void:
	if not _has_shader or not _wetness_material:
		return
	
	# Wetness
	if enable_wetness:
		_wetness_material.set_shader_parameter("wetness", state.accumulated_wetness)
	else:
		_wetness_material.set_shader_parameter("wetness", 0.0)
	
	# Color reaction
	if enable_color_reaction:
		_wetness_material.set_shader_parameter("arousal_color_shift", state.accumulated_arousal)
		_wetness_material.set_shader_parameter("arousal_color", Vector3(arousal_color.r, arousal_color.g, arousal_color.b))
		_wetness_material.set_shader_parameter("arousal_color_strength", color_shift_strength)
		_wetness_material.set_shader_parameter("emission_strength", arousal_emission_strength * state.accumulated_arousal)
	else:
		_wetness_material.set_shader_parameter("arousal_color_shift", 0.0)
		_wetness_material.set_shader_parameter("emission_strength", 0.0)


# ============================================================
# SHAPE KEY HELPERS
# ============================================================

func _set_shape_key(key_name: String, value: float) -> void:
	if key_name in _shape_key_indices:
		mesh_instance.set_blend_shape_value(_shape_key_indices[key_name], value)


func _cache_shape_key_indices() -> void:
	_shape_key_indices.clear()
	if not mesh_instance or not mesh_instance.mesh:
		return
	var mesh: Mesh = mesh_instance.mesh
	var count: int = mesh.get_blend_shape_count()
	print("[VaginaController] Mesh has ", count, " blend shapes:")
	var all_names: Array[String] = []
	for i in range(count):
		var n: String = mesh.get_blend_shape_name(i)
		all_names.append(n)
		print("  [", i, "] = '", n, "'")
	var configured: Array[String] = [
		sk_open_close, sk_labia_minora_length, sk_labia_minora_shape,
		sk_labia_minora_symmetry, sk_labia_majora_puff, sk_clit_size, sk_clit_hood_scale
	]
	for cn in configured:
		var found: bool = false
		for i in range(count):
			if all_names[i] == cn:
				_shape_key_indices[cn] = i
				found = true
				break
		if not found:
			push_warning("[VaginaController] Shape key '", cn, "' NOT FOUND!")


func _validate_setup() -> bool:
	_is_valid = false
	if not mesh_instance:
		push_error("[VaginaController] No MeshInstance3D assigned!")
		return false
	if not mesh_instance.mesh:
		push_error("[VaginaController] MeshInstance3D has no mesh!")
		return false
	if mesh_instance.mesh.get_blend_shape_count() == 0:
		push_error("[VaginaController] Mesh has 0 blend shapes!")
		return false
	_is_valid = true
	return true


func _lerp_toward(current: float, target: float, speed: float, delta: float) -> float:
	return current + (target - current) * clampf(speed * delta, 0.0, 1.0)


func _print_debug_info() -> void:
	print("--- State ---")
	print("  Arousal: ", snappedf(state.accumulated_arousal, 0.01), 
		" | Edging: ", state.is_edging, 
		" | Resistance: ", snappedf(state.edge_resistance, 0.01))
	print("  Wetness: ", snappedf(state.accumulated_wetness, 0.01))
	print("  Gape: ", snappedf(state.accumulated_gape, 0.01))
	print("  Orgasm: ", state.is_orgasming, " intensity: ", snappedf(state.orgasm_intensity, 0.01))


# ============================================================
# AUDIO VOICE LOADING (PHASE 4C)
# ============================================================

## Load a voice profile from a CharacterProfile into the audio controller
func apply_voice_profile(profile: CharacterProfile) -> void:
	var audio_ctrl: VaginaAudioController = _find_audio_controller()
	if not audio_ctrl:
		return
	
	audio_ctrl.breathing_light = profile.voice_breathing_light
	audio_ctrl.breathing_medium = profile.voice_breathing_medium
	audio_ctrl.breathing_heavy = profile.voice_breathing_heavy
	audio_ctrl.stimulation_penetration = profile.voice_penetration_sound
	audio_ctrl.stimulation_clit = profile.voice_clit_stim_sound
	audio_ctrl.orgasm_buildup = profile.voice_orgasm_buildup
	audio_ctrl.orgasm_climax = profile.voice_orgasm_climax
	audio_ctrl.orgasm_post_pant = profile.voice_orgasm_pant
	audio_ctrl.refractory_breath = profile.voice_refractory_breath
	
	# Setup milestones from available moans
	audio_ctrl.milestone_sounds.clear()
	if profile.voice_soft_moan:
		audio_ctrl.add_milestone(0.3, profile.voice_soft_moan, true)
	if profile.voice_medium_moan:
		audio_ctrl.add_milestone(0.6, profile.voice_medium_moan, true)
	if profile.voice_loud_moan:
		audio_ctrl.add_milestone(0.85, profile.voice_loud_moan, true)
	if profile.voice_whimper:
		audio_ctrl.add_milestone(0.92, profile.voice_whimper, true)
	
	# Re-initialize audio players with new streams
	audio_ctrl._create_audio_players()
	audio_ctrl._current_breathing_state = -1
	
	print("[VaginaController] Voice profile '", profile.voice_id, "' applied to audio controller.")


func _find_audio_controller() -> VaginaAudioController:
	# Check siblings and children
	var parent: Node = get_parent()
	if parent:
		for child in parent.get_children():
			if child is VaginaAudioController:
				return child
	# Check own children
	for child in get_children():
		if child is VaginaAudioController:
			return child
	push_warning("[VaginaController] No VaginaAudioController found as sibling or child.")
	return null
	
# ============================================================
# PARTICLE PROFILE LOADING (PHASE 4D)
# ============================================================

func apply_particle_profile(profile: CharacterProfile) -> void:
	var particle_ctrl: VaginaParticleController = _find_particle_controller()
	if not particle_ctrl:
		return
	
	particle_ctrl.enable_squirt = profile.can_squirt
	particle_ctrl.droplet_max_rate = 8.0 * profile.droplet_intensity
	particle_ctrl.sweat_max_rate = 5.0 * profile.sweat_intensity
	particle_ctrl.orgasm_burst_count = int(30 * profile.orgasm_burst_intensity)
	particle_ctrl.squirt_count = int(80 * profile.orgasm_burst_intensity)
	
	print("[VaginaController] Particle profile applied. Squirt: ", profile.can_squirt)


func _find_particle_controller() -> VaginaParticleController:
	var parent: Node = get_parent()
	if parent:
		for child in parent.get_children():
			if child is VaginaParticleController:
				return child
	for child in get_children():
		if child is VaginaParticleController:
			return child
	return null
	
# ============================================================
# SPRAY CONTROLLER INTEGRATION (PHASE 4D-Spray)
# ============================================================

func _find_spray_controller() -> OrgasmSprayController:
	var parent = get_parent()
	if parent:
		for child in parent.get_children():
			if child is OrgasmSprayController:
				return child
	for child in get_children():
		if child is OrgasmSprayController:
			return child
	return null


func apply_spray_profile(profile: CharacterProfile) -> void:
	var spray_ctrl = _find_spray_controller()
	if not spray_ctrl:
		return
	spray_ctrl.apply_profile_settings(profile)
	
# ============================================================
# CREAM CONTROLLER INTEGRATION (PHASE 4D-Cream)
# ============================================================

func _find_cream_controller() -> CreamController:
	var parent = get_parent()
	if parent:
		for child in parent.get_children():
			if child is CreamController:
				return child
	for child in get_children():
		if child is CreamController:
			return child
	return null


func apply_cream_profile(profile: CharacterProfile) -> void:
	var cream_ctrl = _find_cream_controller()
	if not cream_ctrl:
		return
	cream_ctrl.apply_profile_settings(profile)
	
# ============================================================
# DEBUG UI
# ============================================================

var _debug_canvas: CanvasLayer
var _debug_value_labels: Dictionary = {}
var _holding_arousal_stim: bool = false
var _holding_clit_stim: bool = false
var _penetration_slider_value: float = 0.0


func _enter_tree() -> void:
	if show_debug_ui:
		call_deferred("_create_debug_ui")


func _physics_process(delta: float) -> void:
	if _holding_arousal_stim:
		apply_arousal_stimulation(1.0)
	if _holding_clit_stim:
		apply_clit_stimulation(1.0)
	if _penetration_slider_value > 0.0:
		set_penetration(_penetration_slider_value)


func _create_debug_ui() -> void:
	_debug_canvas = CanvasLayer.new()
	_debug_canvas.layer = 100
	add_child(_debug_canvas)
	
	var panel: PanelContainer = PanelContainer.new()
	panel.position = Vector2(10, 10)
	panel.size = Vector2(380, 0)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 0.75)
	style.set_corner_radius_all(8)
	style.set_content_margin_all(10)
	panel.add_theme_stylebox_override("panel", style)
	_debug_canvas.add_child(panel)
	
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(360, 650)
	panel.add_child(scroll)
	
	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)
	
	_add_title(vbox, "=== PHASE 3 SYSTEM ===")
	vbox.add_child(HSeparator.new())
	
	_add_title(vbox, "LIVE STATE")
	_add_value_display(vbox, "arousal_display", "Arousal")
	_add_value_display(vbox, "wetness_display", "Wetness")
	_add_value_display(vbox, "gape_display", "Gape")
	_add_value_display(vbox, "edge_display", "At Edge?")
	_add_value_display(vbox, "orgasm_display", "Orgasm")
	_add_value_display(vbox, "refractory_display", "Refractory")    # NEW
	_add_value_display(vbox, "orgasm_count_display", "Total Orgasms")  # NEW
	
	
	vbox.add_child(HSeparator.new())
	_add_title(vbox, "STIMULATION")
	_add_hold_button(vbox, "Stimulate Arousal", "_holding_arousal_stim")
	_add_hold_button(vbox, "Stimulate Clit", "_holding_clit_stim")
	_add_penetration_slider(vbox)
	
	vbox.add_child(HSeparator.new())
	_add_title(vbox, "ACTIONS")
	_add_action_button(vbox, "Trigger Orgasm", trigger_orgasm)
	_add_action_button(vbox, "Reset All", reset)
	
	vbox.add_child(HSeparator.new())
	_add_title(vbox, "PROFILES")
	_add_action_button(vbox, "Save Current as 'custom.tres'", _debug_save_profile)
	_add_action_button(vbox, "Load 'custom.tres'", _debug_load_profile)
	_add_action_button(vbox, "Load 'sensitive.tres'", _debug_load_sensitive)
	_add_action_button(vbox, "Load 'tight.tres'", _debug_load_tight)
	_add_action_button(vbox, "Load 'default.tres'", _debug_load_default)
	
	vbox.add_child(HSeparator.new())
	_add_title(vbox, "BASE ANATOMY")
	_add_param_slider(vbox, "base_open_close", -1.0, 1.0)
	_add_param_slider(vbox, "base_labia_minora_length", -1.0, 1.0)
	_add_param_slider(vbox, "base_labia_minora_shape", -1.0, 1.0)
	_add_param_slider(vbox, "base_labia_symmetry", -1.0, 1.0)
	_add_param_slider(vbox, "base_majora_puff", -1.0, 1.0)
	_add_param_slider(vbox, "base_clit_size", -1.0, 1.0)
	_add_param_slider(vbox, "base_clit_hood", -1.0, 1.0)
	
	# Update timer
	var timer: Timer = Timer.new()
	timer.wait_time = 0.05
	timer.autostart = true
	timer.timeout.connect(_process_ui_updates)
	add_child(timer)


func _process_ui_updates() -> void:
	if not state:
		return
	if "arousal_display" in _debug_value_labels:
		_debug_value_labels["arousal_display"].text = str(snappedf(state.accumulated_arousal, 0.01))
	if "wetness_display" in _debug_value_labels:
		_debug_value_labels["wetness_display"].text = str(snappedf(state.accumulated_wetness, 0.01))
	if "gape_display" in _debug_value_labels:
		_debug_value_labels["gape_display"].text = str(snappedf(state.accumulated_gape, 0.01))
	if "edge_display" in _debug_value_labels:
		_debug_value_labels["edge_display"].text = "YES" if state.is_edging else "no"
		_debug_value_labels["edge_display"].add_theme_color_override(
			"font_color", 
			Color.RED if state.is_edging else Color.YELLOW
		)
	if "orgasm_display" in _debug_value_labels:
		_debug_value_labels["orgasm_display"].text = str(snappedf(state.orgasm_intensity, 0.01))
	if "refractory_display" in _debug_value_labels:
		if state.is_in_refractory:
			var pct: int = int(state.refractory_progress * 100)
			_debug_value_labels["refractory_display"].text = str(pct) + "% recovered"
			_debug_value_labels["refractory_display"].add_theme_color_override("font_color", Color.ORANGE)
		else:
			_debug_value_labels["refractory_display"].text = "ready"
			_debug_value_labels["refractory_display"].add_theme_color_override("font_color", Color.YELLOW)
	if "orgasm_count_display" in _debug_value_labels:
		_debug_value_labels["orgasm_count_display"].text = str(state.orgasm_count)	


func _add_title(parent: Control, text: String) -> void:
	var label: Label = Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(label)


func _add_value_display(parent: Control, key: String, label_text: String) -> void:
	var hbox: HBoxContainer = HBoxContainer.new()
	parent.add_child(hbox)
	var label: Label = Label.new()
	label.text = label_text
	label.custom_minimum_size = Vector2(150, 0)
	hbox.add_child(label)
	var value: Label = Label.new()
	value.text = "0.00"
	value.add_theme_color_override("font_color", Color.YELLOW)
	hbox.add_child(value)
	_debug_value_labels[key] = value


func _add_hold_button(parent: Control, label_text: String, var_name: String) -> void:
	var btn: Button = Button.new()
	btn.text = label_text
	btn.custom_minimum_size = Vector2(0, 40)
	parent.add_child(btn)
	btn.button_down.connect(func(): set(var_name, true))
	btn.button_up.connect(func(): set(var_name, false))


func _add_penetration_slider(parent: Control) -> void:
	var hbox: HBoxContainer = HBoxContainer.new()
	parent.add_child(hbox)
	var label: Label = Label.new()
	label.text = "Penetration"
	label.custom_minimum_size = Vector2(100, 0)
	hbox.add_child(label)
	var slider: HSlider = HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.01
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.custom_minimum_size = Vector2(150, 30)
	hbox.add_child(slider)
	slider.value_changed.connect(func(v): _penetration_slider_value = v)


func _add_action_button(parent: Control, label_text: String, callback: Callable) -> void:
	var btn: Button = Button.new()
	btn.text = label_text
	btn.custom_minimum_size = Vector2(0, 40)
	parent.add_child(btn)
	btn.pressed.connect(callback)


func _add_param_slider(parent: Control, param_name: String, min_val: float, max_val: float) -> void:
	var hbox: HBoxContainer = HBoxContainer.new()
	parent.add_child(hbox)
	var label: Label = Label.new()
	label.text = param_name.replace("_", " ").capitalize()
	label.custom_minimum_size = Vector2(150, 0)
	label.add_theme_font_size_override("font_size", 11)
	hbox.add_child(label)
	var slider: HSlider = HSlider.new()
	slider.min_value = min_val
	slider.max_value = max_val
	slider.step = 0.01
	slider.value = get(param_name)
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.custom_minimum_size = Vector2(120, 25)
	hbox.add_child(slider)
	var value_label: Label = Label.new()
	value_label.text = str(snappedf(slider.value, 0.01))
	value_label.custom_minimum_size = Vector2(40, 0)
	hbox.add_child(value_label)
	slider.value_changed.connect(func(v):
		set(param_name, v)
		value_label.text = str(snappedf(v, 0.01))
)

# ============================================================
# DEBUG PROFILE HELPERS
# ============================================================

func _debug_save_profile() -> void:
	var path: String = "res://profiles/custom.tres"
	save_current_as_profile("Custom Profile", path)

func _debug_load_profile() -> void:
	load_and_apply_profile("res://profiles/custom.tres")

func _debug_load_sensitive() -> void:
	load_and_apply_profile("res://profiles/sensitive.tres")

func _debug_load_tight() -> void:
	load_and_apply_profile("res://profiles/tight.tres")

func _debug_load_default() -> void:
	load_and_apply_profile("res://profiles/default.tres")
	
