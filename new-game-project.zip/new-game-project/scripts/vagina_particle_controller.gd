class_name VaginaParticleController
extends Node3D

# ============================================================
# VAGINA PARTICLE CONTROLLER - PHASE 4D
# Spawns and manages all particle effects:
# - Wetness droplets (continuous when wet)
# - Sweat sheen (high arousal ambient)
# - Orgasm burst (climax event)
# - Squirt (intense orgasm fluid)
# - Penetration splash (rhythm-based)
# Mobile-Optimized GPU Particles
# ============================================================

## The VaginaController to read state from
@export var controller: VaginaController

## Where particles spawn from (typically your model's MeshInstance3D)
@export var spawn_target: Node3D

# --- WETNESS DROPLETS ---
@export_group("Wetness Droplets")
@export var enable_droplets: bool = true
## Wetness level required before droplets start spawning
@export_range(0.0, 1.0, 0.05) var droplet_wetness_threshold: float = 0.4
## Max droplets per second at full wetness
@export_range(0.0, 30.0, 0.5) var droplet_max_rate: float = 8.0
## Droplet color (slightly translucent white/clear)
@export var droplet_color: Color = Color(1.0, 0.95, 0.92, 0.6)
## Droplet size in world units
@export_range(0.001, 0.05, 0.001) var droplet_size: float = 0.008
## How fast droplets fall (gravity strength)
@export_range(0.5, 20.0, 0.5) var droplet_gravity: float = 4.0
## How long each droplet exists
@export_range(0.5, 5.0, 0.1) var droplet_lifetime: float = 1.5
## Spawn area radius (small = focused area)
@export_range(0.001, 0.1, 0.001) var droplet_spawn_radius: float = 0.015

# --- SWEAT/HEAT SHEEN ---
@export_group("Sweat Sheen")
@export var enable_sweat: bool = true
## Arousal level required before sweat shimmer appears
@export_range(0.0, 1.0, 0.05) var sweat_arousal_threshold: float = 0.7
@export_range(0.0, 20.0, 0.5) var sweat_max_rate: float = 5.0
@export var sweat_color: Color = Color(1.0, 0.98, 0.95, 0.3)
@export_range(0.001, 0.02, 0.001) var sweat_size: float = 0.004
@export_range(0.5, 5.0, 0.1) var sweat_lifetime: float = 2.0
@export_range(0.01, 0.15, 0.01) var sweat_spawn_radius: float = 0.04

# --- ORGASM BURST ---
@export_group("Orgasm Burst")
@export var enable_orgasm_burst: bool = true
## Number of particles in the climax burst
@export_range(5, 100, 1) var orgasm_burst_count: int = 30
@export var orgasm_burst_color: Color = Color(1.0, 0.95, 0.95, 0.85)
@export_range(0.005, 0.05, 0.001) var orgasm_burst_size: float = 0.012
@export_range(0.5, 5.0, 0.1) var orgasm_burst_lifetime: float = 2.0
## Initial velocity of burst particles
@export_range(0.5, 10.0, 0.1) var orgasm_burst_velocity: float = 2.5
## Spread angle of the burst (degrees)
@export_range(5.0, 90.0, 1.0) var orgasm_burst_spread: float = 35.0

# --- SQUIRT (Optional Intense Orgasm) ---
@export_group("Squirt Effect")
@export var enable_squirt: bool = false
## Toggle this per-character for those who can squirt
@export_range(20, 200, 5) var squirt_count: int = 80
@export var squirt_color: Color = Color(0.95, 0.97, 1.0, 0.7)
@export_range(0.005, 0.04, 0.001) var squirt_size: float = 0.01
@export_range(1.0, 5.0, 0.1) var squirt_lifetime: float = 3.0
@export_range(2.0, 15.0, 0.5) var squirt_velocity: float = 6.0
@export_range(5.0, 40.0, 1.0) var squirt_spread: float = 15.0
## Duration of squirt emission in seconds
@export_range(0.2, 2.0, 0.1) var squirt_duration: float = 0.8

# --- PENETRATION SPLASH ---
@export_group("Penetration Splash")
@export var enable_penetration_splash: bool = true
## Wetness required for splash to occur
@export_range(0.0, 1.0, 0.05) var splash_wetness_threshold: float = 0.5
## How much penetration change triggers a splash
@export_range(0.05, 0.5, 0.01) var splash_change_threshold: float = 0.15
@export_range(2, 20, 1) var splash_count: int = 6
@export var splash_color: Color = Color(1.0, 0.97, 0.95, 0.7)
@export_range(0.003, 0.02, 0.001) var splash_size: float = 0.006
@export_range(0.3, 1.5, 0.1) var splash_lifetime: float = 0.6

# --- DEBUG ---
@export_group("Debug")
@export var debug_log_particles: bool = false

# --- INTERNAL ---
var _droplet_emitter: GPUParticles3D
var _sweat_emitter: GPUParticles3D
var _orgasm_burst_emitter: GPUParticles3D
var _squirt_emitter: GPUParticles3D
var _splash_emitter: GPUParticles3D

var _was_orgasming: bool = false
var _previous_orgasm_intensity: float = 0.0
var _previous_penetration: float = 0.0
var _squirt_active_time: float = 0.0
var _squirt_emitted_this_orgasm: bool = false


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	if not spawn_target and controller and controller.mesh_instance:
		spawn_target = controller.mesh_instance
	
	_create_emitters()
	print("[VaginaParticleController] Initialized.")


func _process(delta: float) -> void:
	if not controller or not controller.state:
		return
	
	# Position emitters at spawn target each frame
	if spawn_target:
		global_position = spawn_target.global_position
	
	_update_droplets(delta)
	_update_sweat(delta)
	_update_orgasm(delta)
	_update_squirt(delta)
	_update_splash(delta)
	
	_previous_orgasm_intensity = controller.state.orgasm_intensity
	_previous_penetration = controller.state.current_penetration


# ============================================================
# EMITTER CREATION
# ============================================================

func _create_emitters() -> void:
	_droplet_emitter = _make_emitter("DropletEmitter", droplet_color, droplet_size, droplet_lifetime, droplet_gravity, droplet_spawn_radius, false)
	_sweat_emitter = _make_emitter("SweatEmitter", sweat_color, sweat_size, sweat_lifetime, 0.5, sweat_spawn_radius, false)
	_orgasm_burst_emitter = _make_emitter("OrgasmBurstEmitter", orgasm_burst_color, orgasm_burst_size, orgasm_burst_lifetime, droplet_gravity, droplet_spawn_radius, true)
	_squirt_emitter = _make_emitter("SquirtEmitter", squirt_color, squirt_size, squirt_lifetime, droplet_gravity * 0.7, droplet_spawn_radius, false)
	_splash_emitter = _make_emitter("SplashEmitter", splash_color, splash_size, splash_lifetime, droplet_gravity, droplet_spawn_radius * 1.5, true)
	
	# Configure orgasm burst with directional velocity
	_configure_burst_emitter(_orgasm_burst_emitter, orgasm_burst_velocity, orgasm_burst_spread, orgasm_burst_count)
	# Configure squirt with stronger directional velocity
	_configure_burst_emitter(_squirt_emitter, squirt_velocity, squirt_spread, squirt_count)
	# Configure splash with omnidirectional velocity
	_configure_burst_emitter(_splash_emitter, 1.5, 60.0, splash_count)


func _make_emitter(emitter_name: String, color: Color, size: float, lifetime: float, gravity: float, radius: float, one_shot: bool) -> GPUParticles3D:
	var emitter: GPUParticles3D = GPUParticles3D.new()
	emitter.name = emitter_name
	emitter.amount = 50
	emitter.lifetime = lifetime
	emitter.one_shot = one_shot
	emitter.emitting = false
	emitter.explosiveness = 0.0
	emitter.local_coords = false
	add_child(emitter)
	
	# Create the process material
	var process_mat: ParticleProcessMaterial = ParticleProcessMaterial.new()
	process_mat.gravity = Vector3(0, -gravity, 0)
	process_mat.initial_velocity_min = 0.1
	process_mat.initial_velocity_max = 0.3
	process_mat.scale_min = 1.0
	process_mat.scale_max = 1.5
	process_mat.color = color
	
	# Spawn from a small spherical area
	process_mat.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	process_mat.emission_sphere_radius = radius
	
	# Subtle randomness
	process_mat.angle_min = -180.0
	process_mat.angle_max = 180.0
	process_mat.scale_curve = _make_droplet_scale_curve()
	
	# Fade out at end of life
	var alpha_curve: CurveTexture = _make_alpha_curve()
	process_mat.alpha_curve = alpha_curve
	
	emitter.process_material = process_mat
	
	# Mesh - use a small sphere for droplets
	var mesh: SphereMesh = SphereMesh.new()
	mesh.radius = size
	mesh.height = size * 2.0
	mesh.radial_segments = 6  # Low poly for performance
	mesh.rings = 4
	
	# Material for the mesh
	var draw_mat: StandardMaterial3D = StandardMaterial3D.new()
	draw_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	draw_mat.albedo_color = color
	draw_mat.metallic = 0.3
	draw_mat.roughness = 0.1
	draw_mat.refraction_enabled = false  # Disabled for mobile performance
	draw_mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	mesh.material = draw_mat
	
	emitter.draw_pass_1 = mesh
	
	return emitter


func _configure_burst_emitter(emitter: GPUParticles3D, velocity: float, spread_degrees: float, count: int) -> void:
	emitter.amount = count
	var process_mat: ParticleProcessMaterial = emitter.process_material as ParticleProcessMaterial
	if process_mat:
		process_mat.initial_velocity_min = velocity * 0.7
		process_mat.initial_velocity_max = velocity
		# Direction with spread
		process_mat.direction = Vector3(0, -1, 0.3).normalized()  # Mostly down, slightly forward
		process_mat.spread = spread_degrees


func _make_droplet_scale_curve() -> CurveTexture:
	var curve: Curve = Curve.new()
	curve.add_point(Vector2(0.0, 0.3))   # Start small
	curve.add_point(Vector2(0.2, 1.0))   # Grow quickly
	curve.add_point(Vector2(1.0, 0.8))   # Slight shrink at end
	var tex: CurveTexture = CurveTexture.new()
	tex.curve = curve
	return tex


func _make_alpha_curve() -> CurveTexture:
	var curve: Curve = Curve.new()
	curve.add_point(Vector2(0.0, 0.0))    # Fade in
	curve.add_point(Vector2(0.15, 1.0))   # Full opacity
	curve.add_point(Vector2(0.7, 1.0))    # Hold opacity
	curve.add_point(Vector2(1.0, 0.0))    # Fade out
	var tex: CurveTexture = CurveTexture.new()
	tex.curve = curve
	return tex


# ============================================================
# DROPLETS
# ============================================================

func _update_droplets(_delta: float) -> void:
	if not enable_droplets or not _droplet_emitter:
		return
	
	var wetness: float = controller.get_wetness()
	
	if wetness > droplet_wetness_threshold:
		# Calculate emission rate based on wetness above threshold
		var t: float = (wetness - droplet_wetness_threshold) / (1.0 - droplet_wetness_threshold)
		var rate: int = int(droplet_max_rate * t)
		
		_droplet_emitter.amount = maxi(rate * int(droplet_lifetime) + 1, 5)
		_droplet_emitter.emitting = true
	else:
		_droplet_emitter.emitting = false


# ============================================================
# SWEAT SHEEN
# ============================================================

func _update_sweat(_delta: float) -> void:
	if not enable_sweat or not _sweat_emitter:
		return
	
	var arousal: float = controller.get_arousal()
	
	if arousal > sweat_arousal_threshold:
		var t: float = (arousal - sweat_arousal_threshold) / (1.0 - sweat_arousal_threshold)
		var rate: int = int(sweat_max_rate * t)
		_sweat_emitter.amount = maxi(rate * int(sweat_lifetime) + 1, 3)
		_sweat_emitter.emitting = true
	else:
		_sweat_emitter.emitting = false


# ============================================================
# ORGASM BURST
# ============================================================

func _update_orgasm(_delta: float) -> void:
	if not enable_orgasm_burst or not _orgasm_burst_emitter:
		return
	
	var is_orgasming: bool = controller.state.is_orgasming
	var intensity: float = controller.state.orgasm_intensity
	
	# Trigger burst when orgasm intensity hits peak (crosses 0.9)
	if is_orgasming and intensity >= 0.9 and _previous_orgasm_intensity < 0.9:
		_trigger_orgasm_burst()
	
	# Reset flag when orgasm ends
	if _was_orgasming and not is_orgasming:
		_squirt_emitted_this_orgasm = false
	
	_was_orgasming = is_orgasming


func _trigger_orgasm_burst() -> void:
	_orgasm_burst_emitter.restart()
	_orgasm_burst_emitter.emitting = true
	
	if debug_log_particles:
		print("[Particles] Orgasm burst triggered")


# ============================================================
# SQUIRT
# ============================================================

func _update_squirt(delta: float) -> void:
	if not enable_squirt or not _squirt_emitter:
		return
	
	var is_orgasming: bool = controller.state.is_orgasming
	var intensity: float = controller.state.orgasm_intensity
	
	# Trigger squirt at peak orgasm (only once per orgasm)
	if is_orgasming and intensity >= 0.9 and not _squirt_emitted_this_orgasm:
		_squirt_emitter.restart()
		_squirt_emitter.emitting = true
		_squirt_active_time = squirt_duration
		_squirt_emitted_this_orgasm = true
		
		if debug_log_particles:
			print("[Particles] Squirt emission started")
	
	# Disable after duration
	if _squirt_active_time > 0.0:
		_squirt_active_time -= delta
		if _squirt_active_time <= 0.0:
			_squirt_emitter.emitting = false


# ============================================================
# PENETRATION SPLASH
# ============================================================

func _update_splash(_delta: float) -> void:
	if not enable_penetration_splash or not _splash_emitter:
		return
	
	var wetness: float = controller.get_wetness()
	if wetness < splash_wetness_threshold:
		return
	
	var current_pen: float = controller.state.current_penetration
	var change: float = absf(current_pen - _previous_penetration)
	
	if change >= splash_change_threshold and current_pen > 0.3:
		_splash_emitter.restart()
		_splash_emitter.emitting = true
		
		if debug_log_particles:
			print("[Particles] Splash triggered (change: ", snappedf(change, 0.01), ")")


# ============================================================
# PUBLIC API
# ============================================================

## Manually trigger a squirt event
func trigger_squirt() -> void:
	if not _squirt_emitter:
		return
	_squirt_emitter.restart()
	_squirt_emitter.emitting = true
	_squirt_active_time = squirt_duration

## Manually trigger an orgasm burst (without orgasm event)
func trigger_burst() -> void:
	if not _orgasm_burst_emitter:
		return
	_orgasm_burst_emitter.restart()
	_orgasm_burst_emitter.emitting = true

## Stop all particle emissions
func stop_all_particles() -> void:
	if _droplet_emitter: _droplet_emitter.emitting = false
	if _sweat_emitter: _sweat_emitter.emitting = false
	if _orgasm_burst_emitter: _orgasm_burst_emitter.emitting = false
	if _squirt_emitter: _squirt_emitter.emitting = false
	if _splash_emitter: _splash_emitter.emitting = false

## Enable/disable squirt for current character
func set_squirt_enabled(enabled: bool) -> void:
	enable_squirt = enabled
