class_name CharacterProfile
extends Resource

# ============================================================
# REFRACTORY TYPE ENUM
# ============================================================
enum RefractoryType {
	OVERSENSITIVE,    # Clit hyper-sensitive, general arousal suppressed
	MULTI_ORGASMIC,   # Short refractory, can chain orgasms
	EXHAUSTED,        # All sensitivity reduced, slow recovery
}

# ============================================================
# CHARACTER PROFILE - PHASE 4A
# Saveable resource holding all customization for a character.
# Save/load as .tres files in res://profiles/
# ============================================================

@export_group("Profile Identity")
@export var profile_name: String = "Unnamed"
@export var profile_description: String = ""

# --- BASE ANATOMY ---
@export_group("Base Anatomy")
@export_range(-1.0, 1.0, 0.01) var base_open_close: float = -0.3
@export_range(-1.0, 1.0, 0.01) var base_labia_minora_length: float = 0.0
@export_range(-1.0, 1.0, 0.01) var base_labia_minora_shape: float = 0.0
@export_range(-1.0, 1.0, 0.01) var base_labia_symmetry: float = -0.05
@export_range(-1.0, 1.0, 0.01) var base_majora_puff: float = 0.0
@export_range(-1.0, 1.0, 0.01) var base_clit_size: float = 0.0
@export_range(-1.0, 1.0, 0.01) var base_clit_hood: float = 0.3

# --- SENSITIVITY ---
@export_group("Sensitivity & Arousal")
@export_range(0.0, 2.0, 0.01) var arousal_build_rate: float = 0.25
@export_range(0.0, 1.0, 0.01) var arousal_decay_rate: float = 0.08
@export_range(0.0, 2.0, 0.01) var penetration_arousal_factor: float = 0.7
@export_range(0.0, 2.0, 0.01) var clit_arousal_factor: float = 1.2
@export_range(0.3, 3.0, 0.1) var clit_response_curve: float = 0.6
@export_range(0.3, 3.0, 0.1) var penetration_response_curve: float = 1.3
@export_range(0.3, 3.0, 0.1) var general_response_curve: float = 1.0

# --- WETNESS ---
@export_group("Wetness Behavior")
@export_range(0.0, 1.0, 0.01) var wetness_build_rate: float = 0.15
@export_range(0.0, 0.5, 0.01) var wetness_decay_rate: float = 0.03
@export_range(0.0, 1.0, 0.01) var max_wetness: float = 0.9

# --- EDGING ---
@export_group("Edging Behavior")
@export var enable_edging: bool = true
@export_range(0.5, 0.99, 0.01) var edge_threshold: float = 0.85
@export_range(0.0, 1.0, 0.01) var edge_resistance_strength: float = 0.7
@export_range(0.0, 2.0, 0.01) var edge_resistance_build_rate: float = 0.5
@export_range(0.5, 1.5, 0.01) var edge_break_threshold: float = 0.95

# --- ORGASM BEHAVIOR ---
@export_group("Orgasm Behavior")
@export_range(1.0, 8.0, 0.1) var orgasm_duration: float = 4.0
@export_range(2.0, 8.0, 0.1) var orgasm_contraction_speed: float = 4.5
@export_range(0.0, 1.0, 0.01) var orgasm_contraction_strength: float = 0.5
@export_range(0.5, 1.0, 0.01) var orgasm_required_arousal: float = 0.95

# --- GAPE BEHAVIOR ---
@export_group("Gape Behavior")
@export_range(0.0, 1.0, 0.01) var gape_buildup_threshold: float = 0.6
@export_range(0.0, 1.0, 0.01) var gape_buildup_rate: float = 0.15
@export_range(0.0, 1.0, 0.01) var gape_recovery_rate: float = 0.05

# --- COLOR REACTION ---
@export_group("Color Reaction")
@export var arousal_color: Color = Color(1.15, 0.78, 0.82)
@export_range(0.0, 1.0, 0.01) var color_shift_strength: float = 0.35
@export_range(0.0, 0.3, 0.01) var arousal_emission_strength: float = 0.05


# ============================================================
# UTILITY METHODS
# ============================================================

## Save this profile to a .tres file
func save_to_disk(file_path: String) -> bool:
	var result: int = ResourceSaver.save(self, file_path)
	if result == OK:
		print("[CharacterProfile] Saved '", profile_name, "' to ", file_path)
		return true
	else:
		push_error("[CharacterProfile] Failed to save to ", file_path)
		return false


## Load a profile from disk (static method)
static func load_from_disk(file_path: String) -> CharacterProfile:
	if not ResourceLoader.exists(file_path):
		push_warning("[CharacterProfile] File not found: ", file_path)
		return null
	
	var resource = ResourceLoader.load(file_path)
	if resource is CharacterProfile:
		print("[CharacterProfile] Loaded '", resource.profile_name, "' from ", file_path)
		return resource
	else:
		push_error("[CharacterProfile] File is not a CharacterProfile: ", file_path)
		return null


## Create a deep copy of this profile (for runtime modification without affecting the saved file)
func duplicate_profile() -> CharacterProfile:
	return self.duplicate(true) as CharacterProfile
	
# --- REFRACTORY PERIOD (NEW) ---
@export_group("Refractory Period")
## What kind of recovery this character has
@export var refractory_type: RefractoryType = RefractoryType.OVERSENSITIVE
## Total duration of refractory period in seconds
@export_range(0.0, 60.0, 0.5) var refractory_duration: float = 8.0
## How fast arousal decays during refractory (multiplier on normal decay)
@export_range(1.0, 10.0, 0.1) var refractory_arousal_decay_multiplier: float = 3.0
## Sensitivity multiplier for clit during refractory (>1 = oversensitive, <1 = numb)
@export_range(0.0, 3.0, 0.05) var refractory_clit_sensitivity: float = 2.5
## Sensitivity multiplier for general/penetration during refractory
@export_range(0.0, 2.0, 0.05) var refractory_general_sensitivity: float = 0.4
## Wetness persists longer during refractory (multiplier on decay rate, lower = persists more)
@export_range(0.1, 2.0, 0.05) var refractory_wetness_persistence: float = 0.3

# --- AUDIO VOICE PROFILE (NEW) ---
@export_group("Audio Voice Profile")
## Unique identifier for this voice set (e.g. "yuki", "default")
@export var voice_id: String = "default"
## Audio streams for breathing
@export var voice_breathing_light: AudioStream
@export var voice_breathing_medium: AudioStream
@export var voice_breathing_heavy: AudioStream
## Audio streams for moans
@export var voice_soft_moan: AudioStream
@export var voice_medium_moan: AudioStream
@export var voice_loud_moan: AudioStream
@export var voice_whimper: AudioStream
## Audio streams for orgasm
@export var voice_orgasm_buildup: AudioStream
@export var voice_orgasm_climax: AudioStream
@export var voice_orgasm_pant: AudioStream
## Audio streams for stimulation
@export var voice_penetration_sound: AudioStream
@export var voice_clit_stim_sound: AudioStream
## Audio streams for refractory
@export var voice_refractory_breath: AudioStream

# --- PARTICLE BEHAVIOR (NEW) ---
@export_group("Particle Behavior")
## Does this character squirt during orgasm?
@export var can_squirt: bool = false
## Multiplier on droplet rate (some characters get wetter visibly)
@export_range(0.0, 3.0, 0.1) var droplet_intensity: float = 1.0
## Multiplier on sweat (athletic chars sweat more, etc.)
@export_range(0.0, 3.0, 0.1) var sweat_intensity: float = 1.0
## Multiplier on orgasm burst size
@export_range(0.0, 3.0, 0.1) var orgasm_burst_intensity: float = 1.0

# --- ORGASM SPRAY (NEW) ---
@export_group("Orgasm Spray Behavior")
## Does this character have realistic squirting/spraying during orgasm?
@export var can_spray_realistic: bool = false
## Intensity of the initial burst spurt
@export_range(0.0, 3.0, 0.1) var spray_burst_intensity: float = 1.0
## Intensity of the sustained jet that follows
@export_range(0.0, 3.0, 0.1) var spray_jet_intensity: float = 1.0
## Duration of the sustained jet phase in seconds
@export_range(0.2, 3.0, 0.1) var spray_jet_duration: float = 1.0
## Number of pulse spurts after the main jet (rhythm with orgasm contractions)
@export_range(0, 8, 1) var spray_pulse_count: int = 4
## Speed of spray particles (higher = farther jet)
@export_range(1.0, 15.0, 0.5) var spray_velocity: float = 6.0
## Spread cone angle in degrees (lower = focused stream, higher = wide spray)
@export_range(2.0, 40.0, 1.0) var spray_spread: float = 8.0
## Color tint of spray particles (default = clear water)
@export var spray_color: Color = Color(0.92, 0.96, 1.0, 0.75)

# --- CREAM BEHAVIOR (NEW) ---
@export_group("Cream Behavior")
## Does this character produce cream?
@export var produces_cream: bool = false
## Amount of cream produced per orgasm (1.0 = normal)
@export_range(0.1, 5.0, 0.1) var cream_amount: float = 1.0
## Viscosity affects how slowly cream falls and stretches
@export_range(0.3, 3.0, 0.1) var cream_viscosity: float = 1.0
## Color of cream (white default, can tint slightly)
@export var cream_color: Color = Color(0.96, 0.94, 0.88, 0.95)
## Duration of cream emission in seconds
@export_range(0.5, 8.0, 0.1) var cream_emission_duration: float = 2.5
## Should cream accumulate across multiple orgasms (more cream each time)
@export var cream_accumulates: bool = true
## Maximum accumulation multiplier
@export_range(1.0, 5.0, 0.1) var cream_max_accumulation: float = 3.0
