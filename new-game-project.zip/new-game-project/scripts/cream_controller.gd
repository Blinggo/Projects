@tool
class_name CreamController
extends Node3D

# ============================================================
# CREAM CONTROLLER - REFACTORED
# Position this Node3D directly in the scene where cream should drip from.
# Rotate so -Z points in drip direction (typically slightly forward + down).
# Includes debug always-emit toggle.
# ============================================================

# --- REFERENCES ---
@export_group("References")
@export var controller: VaginaController

# --- DEBUG ALWAYS EMIT ---
@export_group("Debug Always Emit")
## When true, ignores orgasm triggers and emits continuously
@export var debug_always_emit: bool = false:
	set(value):
		debug_always_emit = value
		if Engine.is_editor_hint():
			return
		if value:
			_start_cream_emission()
		else:
			stop_cream()
@export var debug_loop_emission: bool = true

# --- PUDDLE SYSTEM ---
@export_group("Puddle System")
@export var cream_puddle_scene: PackedScene
@export var spawns_puddles: bool = true
@export var puddle_merge_distance: float = 0.15

# --- STREAM PHASE ---
@export_group("Initial Stream")
@export_range(5, 80, 1) var stream_count: int = 25
@export_range(0.2, 2.0, 0.1) var stream_duration: float = 1.0
@export_range(0.3, 5.0, 0.1) var stream_velocity: float = 1.5
@export_range(2.0, 30.0, 0.5) var stream_spread: float = 6.0
@export_range(1.0, 5.0, 0.1) var stream_lifetime: float = 2.5

# --- DRIP PHASE ---
@export_group("Drip Phase")
@export_range(0, 30, 1) var drip_count: int = 8
@export_range(0.1, 1.0, 0.05) var drip_interval: float = 0.3
@export_range(0.1, 2.0, 0.05) var drip_velocity: float = 0.4
@export_range(1.0, 15.0, 0.5) var drip_spread: float = 4.0
@export_range(1.0, 6.0, 0.1) var drip_lifetime: float = 3.0

# --- APPEARANCE ---
@export_group("Particle Appearance")
@export var cream_color: Color = Color(0.96, 0.94, 0.88, 0.95)
@export_range(0.005, 0.04, 0.001) var particle_size: float = 0.012
@export_range(1.0, 8.0, 0.1) var particle_stretch: float = 2.5
@export_range(0.5, 10.0, 0.1) var gravity_strength: float = 3.5
@export_range(0.0, 5.0, 0.1) var particle_damping: float = 1.5

# --- ACCUMULATION ---
@export_group("Accumulation")
@export var enable_accumulation: bool = true

# --- IMPACT ---
@export_group("Impact Detection")
@export var enable_impact_puddles: bool = true
@export_range(1, 15, 1) var puddle_samples_per_emission: int = 4

# --- DEBUG ---
@export_group("Debug")
@export var debug_log: bool = false

# --- INTERNAL ---
var _stream_emitter: GPUParticles3D
var _drip_emitter: GPUParticles3D

var _cream_active: bool = false
var _cream_time: float = 0.0
var _current_drip_index: int = 0
var _last_orgasm_count_processed: int = 0
var _can_produce_cream: bool = false
var _profile_cream_amount: float = 1.0
var _profile_cream_viscosity: float = 1.0
var _profile_cream_emission_duration: float = 2.5
var _accumulation_count: int = 0
var _max_accumulation: float = 3.0


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	if Engine.is_editor_hint():
		return
	
	if not controller:
		push_warning("[CreamController] No VaginaController assigned!")
	
	_create_emitters()
	
	if debug_always_emit:
		_start_cream_emission()
	
	if debug_log:
		print("[CreamController] Initialized. Position: ", global_position)


func _process(delta: float) -> void:
	if Engine.is_editor_hint():
		return
	
	if not controller or not controller.state:
		if debug_always_emit and _cream_active:
			_update_cream_sequence(delta)
		return
	
	if not SweatGlobal.cream_enabled():
		return
	
	if debug_always_emit:
		if _cream_active:
			_update_cream_sequence(delta)
		elif debug_loop_emission:
			_start_cream_emission()
		return
	
	_check_orgasm_trigger()
	
	if _cream_active:
		_update_cream_sequence(delta)


# ============================================================
# EMITTER CREATION
# ============================================================

func _create_emitters() -> void:
	_stream_emitter = _make_cream_emitter("StreamEmitter", stream_lifetime, false)
	_drip_emitter = _make_cream_emitter("DripEmitter", drip_lifetime, true)
	
	_configure_emitter(_stream_emitter, stream_velocity, stream_spread, stream_count)
	_configure_emitter(_drip_emitter, drip_velocity, drip_spread, 5)


func _make_cream_emitter(emitter_name: String, lifetime: float, one_shot: bool) -> GPUParticles3D:
	var emitter = GPUParticles3D.new()
	emitter.name = emitter_name
	emitter.amount = 25
	emitter.lifetime = lifetime
	emitter.one_shot = one_shot
	emitter.emitting = false
	emitter.explosiveness = 0.0
	emitter.local_coords = false
	add_child(emitter)
	
	var pm = ParticleProcessMaterial.new()
	pm.gravity = Vector3(0, -gravity_strength, 0)
	pm.color = cream_color
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 0.005
	pm.scale_curve = _make_cream_scale_curve()
	pm.scale_min = 0.9
	pm.scale_max = 1.4
	pm.alpha_curve = _make_cream_alpha_curve()
	pm.damping_min = particle_damping * 0.7
	pm.damping_max = particle_damping
	
	emitter.process_material = pm
	emitter.draw_pass_1 = _make_cream_mesh()
	
	return emitter


func _make_cream_mesh() -> Mesh:
	var mesh = QuadMesh.new()
	mesh.size = Vector2(particle_size * 2.0, particle_size * particle_stretch)
	
	var mat = StandardMaterial3D.new()
	mat.albedo_color = cream_color
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.metallic = 0.0
	mat.roughness = 0.15
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mat.billboard_keep_scale = true
	mat.disable_receive_shadows = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat.emission_enabled = true
	mat.emission = Color(0.4, 0.38, 0.35)
	mat.emission_energy_multiplier = 0.1
	mesh.material = mat
	
	return mesh


func _configure_emitter(emitter: GPUParticles3D, velocity: float, spread_degrees: float, count: int) -> void:
	emitter.amount = maxi(count, 3)
	var pm = emitter.process_material as ParticleProcessMaterial
	if pm:
		pm.initial_velocity_min = velocity * 0.7
		pm.initial_velocity_max = velocity * 1.2
		pm.direction = Vector3(0, 0, -1)
		pm.spread = spread_degrees


func _make_cream_scale_curve() -> CurveTexture:
	var curve = Curve.new()
	curve.add_point(Vector2(0.0, 0.8))
	curve.add_point(Vector2(0.3, 1.0))
	curve.add_point(Vector2(0.7, 1.2))
	curve.add_point(Vector2(1.0, 0.9))
	var tex = CurveTexture.new()
	tex.curve = curve
	return tex


func _make_cream_alpha_curve() -> CurveTexture:
	var curve = Curve.new()
	curve.add_point(Vector2(0.0, 0.0))
	curve.add_point(Vector2(0.1, 1.0))
	curve.add_point(Vector2(0.85, 1.0))
	curve.add_point(Vector2(1.0, 0.0))
	var tex = CurveTexture.new()
	tex.curve = curve
	return tex


# ============================================================
# ORGASM TRIGGER
# ============================================================

func _check_orgasm_trigger() -> void:
	if not _can_produce_cream:
		return
	
	var current_count = controller.state.orgasm_count
	if current_count > _last_orgasm_count_processed and not controller.state.is_orgasming:
		_last_orgasm_count_processed = current_count
		
		if enable_accumulation:
			_accumulation_count = mini(_accumulation_count + 1, int(_max_accumulation))
		
		_start_cream_emission()


# ============================================================
# CREAM SEQUENCE
# ============================================================

func _start_cream_emission() -> void:
	if not _stream_emitter:
		return
	
	_cream_active = true
	_cream_time = 0.0
	_current_drip_index = 0
	
	var accumulation_mult = 1.0
	if enable_accumulation and not debug_always_emit:
		accumulation_mult = maxf(float(_accumulation_count), 1.0)
	
	var total_mult = _profile_cream_amount * accumulation_mult * SweatGlobal.get_cream_count_multiplier()
	if debug_always_emit:
		total_mult = 1.0  # Ignore profile mult during debug
	
	var stream_actual_count = int(stream_count * total_mult)
	_stream_emitter.amount = maxi(stream_actual_count, 5)
	var stream_pm = _stream_emitter.process_material as ParticleProcessMaterial
	if stream_pm:
		var visc_factor = 1.0 / maxf(_profile_cream_viscosity, 0.1)
		stream_pm.initial_velocity_min = stream_velocity * 0.7 * visc_factor
		stream_pm.initial_velocity_max = stream_velocity * 1.2 * visc_factor
		stream_pm.gravity = Vector3(0, -gravity_strength * visc_factor, 0)
	
	_stream_emitter.restart()
	_stream_emitter.emitting = true
	
	if enable_impact_puddles and not debug_always_emit:
		_spawn_impact_puddles(stream_count, stream_velocity, stream_spread)
	
	if debug_log:
		print("[Cream] Emission started at position: ", global_position)


func _update_cream_sequence(delta: float) -> void:
	_cream_time += delta
	
	var total_stream_time = stream_duration * _profile_cream_emission_duration
	if debug_always_emit:
		total_stream_time = stream_duration
	
	if _cream_time >= total_stream_time and _stream_emitter.emitting:
		_stream_emitter.emitting = false
	
	if _cream_time >= total_stream_time and _current_drip_index < drip_count:
		var time_since_stream = _cream_time - total_stream_time
		var expected_drip_time = _current_drip_index * drip_interval
		
		if time_since_stream >= expected_drip_time:
			_emit_drip(_current_drip_index)
			_current_drip_index += 1
	
	var total_duration = total_stream_time + (drip_count * drip_interval) + 1.5
	if _cream_time >= total_duration:
		_cream_active = false


func _emit_drip(drip_index: int) -> void:
	var intensity_falloff = 1.0 - (float(drip_index) / float(drip_count)) * 0.4
	var visc_factor = 1.0 / maxf(_profile_cream_viscosity, 0.1)
	
	_drip_emitter.amount = 3
	var pm = _drip_emitter.process_material as ParticleProcessMaterial
	if pm:
		pm.initial_velocity_min = drip_velocity * 0.5 * intensity_falloff * visc_factor
		pm.initial_velocity_max = drip_velocity * intensity_falloff * visc_factor
	
	_drip_emitter.restart()
	_drip_emitter.emitting = true
	
	if enable_impact_puddles and drip_index % 2 == 0 and not debug_always_emit:
		_spawn_impact_puddles(2, drip_velocity * intensity_falloff, drip_spread)


# ============================================================
# IMPACT PUDDLES
# ============================================================

func _spawn_impact_puddles(particle_count: int, velocity: float, spread_deg: float) -> void:
	if not spawns_puddles or not cream_puddle_scene:
		return
	
	var samples = mini(puddle_samples_per_emission, particle_count)
	var space_state = get_world_3d().direct_space_state
	
	var forward = -global_transform.basis.z.normalized()
	var right = global_transform.basis.x.normalized()
	var up = global_transform.basis.y.normalized()
	
	for i in range(samples):
		var spread_rad = deg_to_rad(spread_deg)
		var rand_x = randf_range(-spread_rad, spread_rad)
		var rand_y = randf_range(-spread_rad, spread_rad)
		
		var dir = forward
		dir = dir.rotated(right, rand_y)
		dir = dir.rotated(up, rand_x)
		dir = dir.normalized()
		
		var start = global_position
		_predict_landing_and_puddle(start, dir * velocity, space_state)


func _predict_landing_and_puddle(start: Vector3, initial_velocity: Vector3, space_state: PhysicsDirectSpaceState3D) -> void:
	const SEGMENTS = 12
	const TIME_STEP = 0.2
	
	var pos = start
	var vel = initial_velocity
	var visc_factor = 1.0 / maxf(_profile_cream_viscosity, 0.1)
	var gravity = Vector3(0, -gravity_strength * visc_factor, 0)
	
	for i in range(SEGMENTS):
		var next_vel = vel + gravity * TIME_STEP
		var next_pos = pos + vel * TIME_STEP
		
		var query = PhysicsRayQueryParameters3D.create(pos, next_pos)
		var result = space_state.intersect_ray(query)
		
		if result:
			if result.collider and result.collider.is_in_group("stain_receiver"):
				_spawn_or_grow_puddle(result.position)
			return
		
		pos = next_pos
		vel = next_vel


func _spawn_or_grow_puddle(world_pos: Vector3) -> void:
	var nearby_puddle = _find_nearby_puddle(world_pos)
	
	if nearby_puddle:
		nearby_puddle.absorb_cream()
		return
	
	if not cream_puddle_scene:
		return
	
	var puddle = cream_puddle_scene.instantiate()
	if not puddle:
		return
	
	get_tree().current_scene.add_child(puddle)
	puddle.global_position = world_pos + Vector3(0, 0.005, 0)
	
	if puddle.has_method("set"):
		puddle.set("cream_color", cream_color)
	
	SweatGlobal.register_cream_puddle(puddle)


func _find_nearby_puddle(world_pos: Vector3) -> CreamPuddleDecal:
	for puddle in SweatGlobal._active_cream_puddles:
		if not is_instance_valid(puddle):
			continue
		if puddle is CreamPuddleDecal:
			if puddle.global_position.distance_to(world_pos) < puddle_merge_distance:
				return puddle
	return null


# ============================================================
# PUBLIC API
# ============================================================

func trigger_cream() -> void:
	_start_cream_emission()


func stop_cream() -> void:
	_cream_active = false
	if _stream_emitter: _stream_emitter.emitting = false
	if _drip_emitter: _drip_emitter.emitting = false


func reset_accumulation() -> void:
	_accumulation_count = 0


func get_accumulation_level() -> int:
	return _accumulation_count


func apply_profile_settings(profile: CharacterProfile) -> void:
	_can_produce_cream = profile.produces_cream
	_profile_cream_amount = profile.cream_amount
	_profile_cream_viscosity = profile.cream_viscosity
	_profile_cream_emission_duration = profile.cream_emission_duration
	_max_accumulation = profile.cream_max_accumulation
	cream_color = profile.cream_color
	
	if _stream_emitter:
		var pm = _stream_emitter.process_material as ParticleProcessMaterial
		if pm:
			pm.color = cream_color
		_update_mesh_color(_stream_emitter)
	
	if _drip_emitter:
		var pm = _drip_emitter.process_material as ParticleProcessMaterial
		if pm:
			pm.color = cream_color
		_update_mesh_color(_drip_emitter)
	
	if not profile.cream_accumulates:
		_accumulation_count = 0
		enable_accumulation = false
	else:
		enable_accumulation = true
	
	if debug_log:
		print("[CreamController] Profile applied - produces_cream: ", _can_produce_cream)


func _update_mesh_color(emitter: GPUParticles3D) -> void:
	var mesh = emitter.draw_pass_1
	if mesh and mesh.material:
		var mat = mesh.material as StandardMaterial3D
		if mat:
			mat.albedo_color = cream_color
