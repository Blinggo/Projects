
class_name OrgasmSprayController
extends Node3D

# ============================================================
# ORGASM SPRAY CONTROLLER - REFACTORED
# Position this Node3D directly in the scene where spray should emit from.
# Rotate it so -Z points in the direction of the spray.
# Includes debug always-emit toggle for testing.
# ============================================================

# --- REFERENCES ---
@export_group("References")
@export var controller: VaginaController

# --- DEBUG ALWAYS EMIT ---
@export_group("Debug Always Emit")
## When true, ignores orgasm triggers and emits continuously for testing
@export var debug_always_emit: bool = false:
	set(value):
		debug_always_emit = value
		if not _burst_emitter:
			return
		if value:
			_start_spray_sequence()
		else:
			stop_spray()
## Auto-restart emission when sequence ends (continuous loop)
@export var debug_loop_emission: bool = true
## Show direction gizmo in editor (helps see -Z direction)
@export var show_direction_gizmo: bool = true

# --- WET STAIN SYSTEM ---
@export_group("Wet Stain System")
@export var wet_stain_scene: PackedScene
@export var spray_creates_stains: bool = true
@export var spray_stain_size: Vector3 = Vector3(0.15, 0.15, 0.15)

# --- BURST PHASE ---
@export_group("Burst Phase")
@export_range(10, 200, 5) var burst_count: int = 60
@export_range(2.0, 15.0, 0.5) var burst_velocity: float = 8.0
@export_range(3.0, 30.0, 0.5) var burst_spread: float = 12.0
@export_range(0.3, 3.0, 0.1) var burst_lifetime: float = 1.5

# --- JET PHASE ---
@export_group("Jet Phase")
@export_range(5, 100, 5) var jet_count_per_pulse: int = 25
@export_range(0.2, 3.0, 0.1) var jet_duration: float = 1.0
@export_range(2.0, 15.0, 0.5) var jet_velocity: float = 6.0
@export_range(2.0, 20.0, 0.5) var jet_spread: float = 6.0
@export_range(0.3, 3.0, 0.1) var jet_lifetime: float = 1.8

# --- PULSE PHASE ---
@export_group("Pulse Phase")
@export_range(0, 8, 1) var pulse_count: int = 4
@export_range(0.1, 1.0, 0.05) var pulse_interval: float = 0.3
@export_range(5, 50, 1) var pulse_count_per_spurt: int = 15

# --- APPEARANCE ---
@export_group("Particle Appearance")
@export var spray_color: Color = Color(0.92, 0.96, 1.0, 0.75)
@export_range(0.002, 0.03, 0.001) var particle_size: float = 0.006
@export_range(1.0, 10.0, 0.1) var particle_stretch: float = 3.5
@export_range(0.5, 20.0, 0.5) var gravity_strength: float = 9.8

# --- STAIN IMPACT ---
@export_group("Stain Impact")
@export var enable_impact_stains: bool = true
@export_range(1, 20, 1) var stain_samples_per_pulse: int = 5

# --- DEBUG ---
@export_group("Debug")
@export var debug_log: bool = false

# --- INTERNAL ---
var _burst_emitter: GPUParticles3D
var _jet_emitter: GPUParticles3D
var _pulse_emitter: GPUParticles3D

var _spray_active: bool = false
var _spray_time: float = 0.0
var _current_pulse_index: int = 0
var _was_orgasming: bool = false
var _spray_triggered_this_orgasm: bool = false
var _can_spray: bool = false


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:	
	if not controller:
		push_warning("[OrgasmSprayController] No VaginaController assigned!")
	
	_create_emitters()
	
	# Start debug emission if enabled
	if debug_always_emit:
		_start_spray_sequence()
	
	if debug_log:
		print("[OrgasmSprayController] Initialized. Position: ", global_position)


func _process(delta: float) -> void:
	if not controller or not controller.state:
		# Even without controller, debug emit can still work
		if debug_always_emit and _spray_active:
			_update_spray_sequence(delta)
		return
	
	if not SweatGlobal.uses_realistic_spray():
		return
	
	# Debug always emit mode
	if debug_always_emit:
		if _spray_active:
			_update_spray_sequence(delta)
		elif debug_loop_emission:
			# Restart emission when sequence ends
			_start_spray_sequence()
		return
	
	# Normal orgasm-triggered mode
	_check_orgasm_trigger()
	
	if _spray_active:
		_update_spray_sequence(delta)
	
	_was_orgasming = controller.state.is_orgasming


# ============================================================
# EMITTER CREATION
# ============================================================

func _create_emitters() -> void:
	_burst_emitter = _make_spray_emitter("BurstEmitter", burst_lifetime, true)
	_jet_emitter = _make_spray_emitter("JetEmitter", jet_lifetime, false)
	_pulse_emitter = _make_spray_emitter("PulseEmitter", jet_lifetime * 0.8, true)
	
	_configure_emitter(_burst_emitter, burst_velocity, burst_spread, burst_count)
	_configure_emitter(_jet_emitter, jet_velocity, jet_spread, jet_count_per_pulse)
	_configure_emitter(_pulse_emitter, jet_velocity * 1.2, jet_spread * 1.5, pulse_count_per_spurt)


func _make_spray_emitter(emitter_name: String, lifetime: float, one_shot: bool) -> GPUParticles3D:
	var emitter = GPUParticles3D.new()
	emitter.name = emitter_name
	emitter.amount = 50
	emitter.lifetime = lifetime
	emitter.one_shot = one_shot
	emitter.emitting = false
	emitter.explosiveness = 1.0 if one_shot else 0.0
	emitter.local_coords = false
	add_child(emitter)
	
	var pm = ParticleProcessMaterial.new()
	pm.gravity = Vector3(0, -gravity_strength, 0)
	pm.color = spray_color
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 0.003
	#pm.scale_curve = _make_spray_scale_curve()
	pm.scale_min = 0.8
	pm.scale_max = 1.4
	#pm.alpha_curve = _make_spray_alpha_curve()
	pm.damping_min = 0.3
	pm.damping_max = 0.8
	
	emitter.process_material = pm
	emitter.draw_pass_1 = _make_spray_mesh()
	
	return emitter


func _make_spray_mesh() -> Mesh:
	var mesh = QuadMesh.new()
	mesh.size = Vector2(particle_size * 2.0, particle_size * particle_stretch)
	
	var mat = StandardMaterial3D.new()
	mat.albedo_color = spray_color
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.metallic = 0.2
	mat.roughness = 0.05
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mat.billboard_keep_scale = true
	mat.disable_receive_shadows = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mesh.material = mat
	
	return mesh


func _configure_emitter(emitter: GPUParticles3D, velocity: float, spread_degrees: float, count: int) -> void:
	emitter.amount = maxi(count, 5)
	var pm = emitter.process_material as ParticleProcessMaterial
	if pm:
		pm.initial_velocity_min = velocity * 0.85
		pm.initial_velocity_max = velocity * 1.15
		pm.direction = Vector3(0, 0, -1)  # Local -Z direction of THIS node
		pm.spread = spread_degrees


# ============================================================
# ORGASM TRIGGER
# ============================================================

func _check_orgasm_trigger() -> void:
	if not controller.state.is_orgasming:
		_spray_triggered_this_orgasm = false
		return
	
	if not _can_spray:
		return
	
	if controller.state.orgasm_intensity >= 0.9 and not _spray_triggered_this_orgasm:
		_start_spray_sequence()
		_spray_triggered_this_orgasm = true


# ============================================================
# SPRAY SEQUENCE
# ============================================================

func _start_spray_sequence() -> void:
	if not _burst_emitter or not _jet_emitter:
		return
	
	_spray_active = true
	_spray_time = 0.0
	_current_pulse_index = 0
	
	_emit_burst()
	
	_jet_emitter.amount = jet_count_per_pulse
	_jet_emitter.emitting = true
	
	if debug_log:
		print("[Spray] Sequence started at position: ", global_position)


func _update_spray_sequence(delta: float) -> void:
	_spray_time += delta
	
	if _spray_time >= jet_duration and _jet_emitter.emitting:
		_jet_emitter.emitting = false
		if debug_log:
			print("[Spray] Jet phase ended")
	
	if _spray_time >= jet_duration and _current_pulse_index < pulse_count:
		var time_since_jet = _spray_time - jet_duration
		var expected_pulse_time = _current_pulse_index * pulse_interval
		
		if time_since_jet >= expected_pulse_time:
			_emit_pulse(_current_pulse_index)
			_current_pulse_index += 1
	
	var total_duration = jet_duration + (pulse_count * pulse_interval) + 1.0
	if _spray_time >= total_duration:
		_spray_active = false


func _emit_burst() -> void:
	_burst_emitter.amount = burst_count
	_burst_emitter.restart()
	_burst_emitter.emitting = true
	
	if enable_impact_stains:
		_spawn_impact_stains(burst_count, burst_velocity, burst_spread)
	
	if debug_log:
		print("[Spray] Burst emitted")


func _emit_pulse(pulse_index: int) -> void:
	var intensity_falloff = 1.0 - (float(pulse_index) / float(pulse_count)) * 0.6
	var count = int(pulse_count_per_spurt * intensity_falloff)
	count = maxi(count, 5)
	
	_pulse_emitter.amount = count
	var pm = _pulse_emitter.process_material as ParticleProcessMaterial
	if pm:
		pm.initial_velocity_min = jet_velocity * 1.2 * intensity_falloff
		pm.initial_velocity_max = jet_velocity * 1.4 * intensity_falloff
	
	_pulse_emitter.restart()
	_pulse_emitter.emitting = true
	
	if enable_impact_stains:
		_spawn_impact_stains(count, jet_velocity * intensity_falloff, jet_spread)


# ============================================================
# IMPACT STAINS
# ============================================================

func _spawn_impact_stains(particle_count: int, velocity: float, spread_deg: float) -> void:
	if not spray_creates_stains or not wet_stain_scene:
		return
	
	var samples = mini(stain_samples_per_pulse, particle_count)
	var space_state = get_world_3d().direct_space_state
	
	var forward = -global_transform.basis.z.normalized()
	var right = global_transform.basis.x.normalized()
	var up = global_transform.basis.y.normalized()
	
	for i in range(samples):
		var spread_rad = deg_to_rad(spread_deg)
		var rand_x = randf_range(-spread_rad, spread_rad)
		var rand_y = randf_range(-spread_rad, spread_rad)
		
		var dir = forward
		dir = dir.rotated(right, rand_y)
		dir = dir.rotated(up, rand_x)
		dir = dir.normalized()
		
		var start = global_position
		_predict_landing_and_stain(start, dir * velocity, space_state)


func _predict_landing_and_stain(start: Vector3, initial_velocity: Vector3, space_state: PhysicsDirectSpaceState3D) -> void:
	const SEGMENTS = 8
	const TIME_STEP = 0.15
	
	var pos = start
	var vel = initial_velocity
	var gravity = Vector3(0, -gravity_strength, 0)
	
	for i in range(SEGMENTS):
		var next_vel = vel + gravity * TIME_STEP
		var next_pos = pos + vel * TIME_STEP
		
		var query = PhysicsRayQueryParameters3D.create(pos, next_pos)
		var result = space_state.intersect_ray(query)
		
		if result:
			if result.collider and result.collider.is_in_group("stain_receiver"):
				_spawn_stain_at(result.position, result.normal)
			return
		
		pos = next_pos
		vel = next_vel


func _spawn_stain_at(world_pos: Vector3, _normal: Vector3) -> void:
	if not wet_stain_scene:
		return
	
	var stain = wet_stain_scene.instantiate()
	if not stain:
		return
	
	get_tree().current_scene.add_child(stain)
	stain.global_position = world_pos + Vector3(0, 0.005, 0)
	
	if stain.has_method("set"):
		stain.set("initial_size", spray_stain_size)
		stain.size = spray_stain_size
	
	SweatGlobal.register_stain(stain)

# ============================================================
# PUBLIC API
# ============================================================

func trigger_spray() -> void:
	_start_spray_sequence()


func stop_spray() -> void:
	_spray_active = false
	if _burst_emitter: _burst_emitter.emitting = false
	if _jet_emitter: _jet_emitter.emitting = false
	if _pulse_emitter: _pulse_emitter.emitting = false


func set_spray_enabled(enabled: bool) -> void:
	_can_spray = enabled


func apply_profile_settings(profile: CharacterProfile) -> void:
	_can_spray = profile.can_spray_realistic
	
	burst_count = int(60 * profile.spray_burst_intensity)
	jet_count_per_pulse = int(25 * profile.spray_jet_intensity)
	jet_duration = profile.spray_jet_duration
	pulse_count = profile.spray_pulse_count
	burst_velocity = profile.spray_velocity * 1.2
	jet_velocity = profile.spray_velocity
	burst_spread = profile.spray_spread * 1.4
	jet_spread = profile.spray_spread
	spray_color = profile.spray_color
	
	if _burst_emitter:
		_configure_emitter(_burst_emitter, burst_velocity, burst_spread, burst_count)
	if _jet_emitter:
		_configure_emitter(_jet_emitter, jet_velocity, jet_spread, jet_count_per_pulse)
	if _pulse_emitter:
		_configure_emitter(_pulse_emitter, jet_velocity * 1.2, jet_spread * 1.5, pulse_count_per_spurt)
	
	if debug_log:
		print("[OrgasmSprayController] Profile applied - can_spray: ", _can_spray)
