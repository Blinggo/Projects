class_name VaginaState
extends RefCounted

# ============================================================
# VAGINA STATE - PHASE 4B
# ============================================================

# --- ACCUMULATED VALUES ---
var accumulated_arousal: float = 0.0
var accumulated_gape: float = 0.0
var accumulated_wetness: float = 0.0
var current_penetration: float = 0.0
var current_clit_stim: float = 0.0

# --- STIMULATION INPUT (per-frame) ---
var arousal_input_this_frame: float = 0.0
var penetration_input_this_frame: float = 0.0
var clit_stim_input_this_frame: float = 0.0

# --- ORGASM STATE ---
var is_orgasming: bool = false
var orgasm_time: float = 0.0
var orgasm_duration: float = 4.0
var orgasm_intensity: float = 0.0
var orgasm_count: int = 0                 # NEW: total orgasms in this session

# --- INTERNAL TIMING ---
var pulse_phase: float = 0.0
var heartbeat_phase: float = 0.0

# --- EDGING STATE ---
var is_edging: bool = false
var edge_resistance: float = 0.0

# --- REFRACTORY PERIOD (NEW) ---
var is_in_refractory: bool = false        # True during recovery
var refractory_time: float = 0.0          # Time elapsed in refractory
var refractory_duration: float = 0.0      # Total duration of current refractory
var refractory_progress: float = 0.0      # 0 = just orgasmed, 1 = fully recovered


func reset_frame_inputs() -> void:
	arousal_input_this_frame = 0.0
	penetration_input_this_frame = 0.0
	clit_stim_input_this_frame = 0.0


func reset_all() -> void:
	accumulated_arousal = 0.0
	accumulated_gape = 0.0
	accumulated_wetness = 0.0
	current_penetration = 0.0
	current_clit_stim = 0.0
	is_orgasming = false
	orgasm_time = 0.0
	orgasm_intensity = 0.0
	orgasm_count = 0
	pulse_phase = 0.0
	heartbeat_phase = 0.0
	is_edging = false
	edge_resistance = 0.0
	is_in_refractory = false
	refractory_time = 0.0
	refractory_duration = 0.0
	refractory_progress = 0.0
	reset_frame_inputs()
