class_name MobilePenetratorController
extends Node

# ============================================================
# MOBILE PENETRATOR CONTROLLER - PHASE 4E
# Provides on-screen touch controls to move the test penetrator.
# Includes: joystick, depth slider, auto-thrust mode, debug overlay.
# Attach to the TestPenetrator scene root.
# ============================================================

# --- REFERENCES ---
@export_group("References")
## The penetrator node to control (defaults to parent if null)
@export var penetrator_target: Node3D
## The penetrable zone to align with (auto-finds first one if null)
@export var target_zone: PenetrableZone
## The detector for reading debug values
@export var detector: PenetrationDetector

# --- MOVEMENT SETTINGS ---
@export_group("Movement")
## Movement speed of the joystick (units per second at full deflection)
@export_range(0.1, 5.0, 0.1) var move_speed: float = 1.0
## How much depth slider can push penetrator forward (in world units)
@export_range(0.05, 1.0, 0.01) var max_depth_push: float = 0.3
## Position to reset to (relative to zone)
@export var reset_offset: Vector3 = Vector3(0, 0, 0.2)
## NEW: Auto-align mode - if false, respects your manual positioning
@export var auto_align_to_zone: bool = false

# --- AUTO THRUST ---
@export_group("Auto Thrust")
@export_range(0.5, 5.0, 0.1) var auto_thrust_speed_default: float = 2.0
@export_range(0.1, 1.0, 0.05) var auto_thrust_depth_min: float = 0.2
@export_range(0.1, 1.0, 0.05) var auto_thrust_depth_max: float = 0.95

# --- INTERNAL ---
var _canvas: CanvasLayer
var _joystick_active: bool = false
var _joystick_center: Vector2
var _joystick_current: Vector2
var _joystick_max_distance: float = 80.0

var _depth_slider_value: float = 0.0
var _auto_thrust_enabled: bool = false
var _auto_thrust_time: float = 0.0
var _auto_thrust_speed: float = 2.0

var _zone_origin: Vector3
var _zone_basis: Basis
var _zone_initialized: bool = false

# Debug labels
var _label_depth: Label
var _label_speed: Label
var _label_rhythm: Label
var _label_penetrating: Label
var _label_arousal: Label

var _saved_start_position: Vector3 = Vector3.ZERO
var _has_saved_start_position: bool = false

# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	# Auto-find references
	if not penetrator_target:
		penetrator_target = get_parent() as Node3D
	
	if not target_zone:
		target_zone = _find_first_zone()
	
	if not detector:
		detector = _find_detector()
	
	# Initialize position relative to zone
	if target_zone and penetrator_target:
		_zone_origin = target_zone.global_position
		_zone_basis = target_zone.global_transform.basis
		_zone_initialized = true
		_reset_position()
		
	if penetrator_target:
		_saved_start_position = penetrator_target.global_position
		_has_saved_start_position = true
	
	# Build UI
	call_deferred("_create_ui")
	
	print("[MobilePenetratorController] Initialized.")
	print("  Penetrator: ", penetrator_target)
	print("  Zone: ", target_zone)
	print("  Detector: ", detector)


func _process(delta: float) -> void:
	if not penetrator_target:
		return
	
	_handle_joystick_movement(delta)
	_handle_depth_slider()
	_handle_auto_thrust(delta)
	_update_debug_display()


# ============================================================
# MOVEMENT HANDLING
# ============================================================

func _handle_joystick_movement(delta: float) -> void:
	if not _joystick_active:
		return
	
	# Calculate joystick deflection (-1 to 1 on each axis)
	var offset = _joystick_current - _joystick_center
	var clamped_offset = offset.limit_length(_joystick_max_distance)
	var deflection = clamped_offset / _joystick_max_distance
	
	# Apply movement in zone's local space (X = strafe, Y = vertical)
	if _zone_initialized:
		var right = _zone_basis.x
		var up = _zone_basis.y
		var move_vector = (right * deflection.x + up * -deflection.y) * move_speed * delta
		penetrator_target.global_position += move_vector


func _handle_depth_slider() -> void:
	if not _zone_initialized or _auto_thrust_enabled:
		return
	
	# Position penetrator at depth based on slider
	_apply_depth(_depth_slider_value)


func _handle_auto_thrust(delta: float) -> void:
	if not _auto_thrust_enabled or not _zone_initialized:
		return
	
	_auto_thrust_time += delta * _auto_thrust_speed
	
	# Sinusoidal back-and-forth motion
	var t = (sin(_auto_thrust_time) + 1.0) * 0.5  # 0 to 1
	var depth = lerpf(auto_thrust_depth_min, auto_thrust_depth_max, t)
	
	_apply_depth(depth)


func _apply_depth(depth_normalized: float) -> void:
	if not target_zone:
		return
	
	if auto_align_to_zone:
		# ORIGINAL BEHAVIOR: Snap penetrator to zone, aligned automatically
		_apply_depth_auto_align(depth_normalized)
	else:
		# NEW BEHAVIOR: Only move along penetrator's own forward axis
		_apply_depth_manual_position(depth_normalized)


func _apply_depth_auto_align(depth_normalized: float) -> void:
	# Position penetrator INSIDE the zone at given depth (original behavior)
	var into_direction = -target_zone.global_transform.basis.z.normalized()
	var tip_target_position = target_zone.global_position + into_direction * (target_zone.max_depth * depth_normalized)
	
	var pen_comp = _find_penetrator_component(penetrator_target)
	if not pen_comp:
		return
	
	var pen_forward = -pen_comp.forward_direction.normalized()
	var pen_root_position = tip_target_position + pen_forward * pen_comp.tip_distance
	
	penetrator_target.global_position = pen_root_position
	
	var look_at_point = penetrator_target.global_position + into_direction
	penetrator_target.look_at(look_at_point, Vector3.UP)


func _apply_depth_manual_position(depth_normalized: float) -> void:
	# Keep penetrator's rotation as-is, only slide it forward/back along ITS own axis
	# This lets you position it manually in the scene and use the slider like a "thrust" control
	
	var pen_comp = _find_penetrator_component(penetrator_target)
	if not pen_comp:
		return
	
	# Get penetrator's current forward direction (in world space)
	var pen_forward = penetrator_target.global_transform.basis * pen_comp.forward_direction.normalized()
	
	# Calculate how far to push forward from _saved_start_position
	if not _has_saved_start_position:
		return  # Need reset first
	
	# depth_normalized = 0 means at start position (fully retracted)
	# depth_normalized = 1 means pushed forward by max_depth_push
	var push_distance = max_depth_push * depth_normalized
	var new_position = _saved_start_position + pen_forward * push_distance
	
	penetrator_target.global_position = new_position


func _reset_position() -> void:
	if not penetrator_target:
		return
	
	if auto_align_to_zone and _zone_initialized:
		# Original auto-align reset
		_depth_slider_value = 0.0
		_apply_depth_auto_align(0.0)
		var into_direction = -target_zone.global_transform.basis.z.normalized()
		penetrator_target.global_position -= into_direction * reset_offset.z
	
	# Save current position as the "start" for manual mode
	_saved_start_position = penetrator_target.global_position
	_has_saved_start_position = true
	_depth_slider_value = 0.0
	
	print("[MobilePenetratorController] Reset position saved: ", _saved_start_position)

# ============================================================
# UTILITY
# ============================================================

func _find_first_zone() -> PenetrableZone:
	var root = get_tree().current_scene
	return _find_zone_recursive(root)


func _find_zone_recursive(node: Node) -> PenetrableZone:
	if node is PenetrableZone:
		return node
	for child in node.get_children():
		var result = _find_zone_recursive(child)
		if result:
			return result
	return null


func _find_detector() -> PenetrationDetector:
	var root = get_tree().current_scene
	return _find_detector_recursive(root)


func _find_detector_recursive(node: Node) -> PenetrationDetector:
	if node is PenetrationDetector:
		return node
	for child in node.get_children():
		var result = _find_detector_recursive(child)
		if result:
			return result
	return null


func _find_penetrator_component(node: Node) -> PenetratorComponent:
	if node is PenetratorComponent:
		return node
	for child in node.get_children():
		var result = _find_penetrator_component(child)
		if result:
			return result
	return null


# ============================================================
# UI CREATION
# ============================================================

func _create_ui() -> void:
	_canvas = CanvasLayer.new()
	_canvas.layer = 110  # Above other debug UIs
	add_child(_canvas)
	
	# Get screen width to position panel on the right
	var screen_size = get_viewport().get_visible_rect().size
	
	# Right side panel for controls
	var panel = PanelContainer.new()
	panel.position = Vector2(screen_size.x - 320, 10)
	panel.size = Vector2(310, 0)  # Height auto-sizes
	
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 0.8)
	style.set_corner_radius_all(8)
	style.set_content_margin_all(10)
	panel.add_theme_stylebox_override("panel", style)
	_canvas.add_child(panel)
	
	# Scroll container in case content is too tall
	var scroll = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(290, 600)
	panel.add_child(scroll)
	
	var vbox = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.add_theme_constant_override("separation", 8)
	scroll.add_child(vbox)
	
	# Title
	var title = Label.new()
	title.text = "=== PENETRATOR ==="
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	
	# Debug values display
	vbox.add_child(HSeparator.new())
	var debug_title = Label.new()
	debug_title.text = "LIVE STATE"
	debug_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(debug_title)
	
	_label_penetrating = _create_value_label(vbox, "Active:")
	_label_depth = _create_value_label(vbox, "Depth:")
	_label_speed = _create_value_label(vbox, "Speed:")
	_label_rhythm = _create_value_label(vbox, "Rhythm:")
	_label_arousal = _create_value_label(vbox, "Arousal:")
	
	vbox.add_child(HSeparator.new())
	
	# Depth slider
	var depth_title = Label.new()
	depth_title.text = "DEPTH (manual)"
	depth_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(depth_title)
	
	var depth_slider = HSlider.new()
	depth_slider.min_value = 0.0
	depth_slider.max_value = 1.0
	depth_slider.step = 0.01
	depth_slider.value = 0.0
	depth_slider.custom_minimum_size = Vector2(0, 50)
	vbox.add_child(depth_slider)
	depth_slider.value_changed.connect(func(v): _depth_slider_value = v)
	
	vbox.add_child(HSeparator.new())
	
	# Auto thrust controls
	var thrust_title = Label.new()
	thrust_title.text = "AUTO THRUST"
	thrust_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(thrust_title)
	
	var thrust_toggle = CheckBox.new()
	thrust_toggle.text = "Enable Auto Thrust"
	vbox.add_child(thrust_toggle)
	thrust_toggle.toggled.connect(func(pressed): _auto_thrust_enabled = pressed)
	
	# Auto thrust speed
	var speed_label = Label.new()
	speed_label.text = "Thrust Speed:"
	vbox.add_child(speed_label)
	
	var speed_slider = HSlider.new()
	speed_slider.min_value = 0.3
	speed_slider.max_value = 6.0
	speed_slider.step = 0.1
	speed_slider.value = auto_thrust_speed_default
	speed_slider.custom_minimum_size = Vector2(0, 40)
	vbox.add_child(speed_slider)
	_auto_thrust_speed = auto_thrust_speed_default
	speed_slider.value_changed.connect(func(v): _auto_thrust_speed = v)
	
	vbox.add_child(HSeparator.new())
	
	# Reset button
	var reset_btn = Button.new()
	reset_btn.text = "Reset Position"
	reset_btn.custom_minimum_size = Vector2(0, 50)
	vbox.add_child(reset_btn)
	reset_btn.pressed.connect(_reset_position)
	
	# Pull out button
	var pullout_btn = Button.new()
	pullout_btn.text = "Pull Out"
	pullout_btn.custom_minimum_size = Vector2(0, 50)
	vbox.add_child(pullout_btn)
	pullout_btn.pressed.connect(func():
		_depth_slider_value = 0.0
		depth_slider.value = 0.0
	)
	
func _create_value_label(parent: Control, label_text: String) -> Label:
	var hbox = HBoxContainer.new()
	parent.add_child(hbox)
	
	var name_lbl = Label.new()
	name_lbl.text = label_text
	name_lbl.custom_minimum_size = Vector2(100, 0)
	hbox.add_child(name_lbl)
	
	var value_lbl = Label.new()
	value_lbl.text = "0.00"
	value_lbl.add_theme_color_override("font_color", Color.YELLOW)
	hbox.add_child(value_lbl)
	
	return value_lbl


func _update_debug_display() -> void:
	if not detector or not target_zone:
		return
	
	if _label_depth:
		var depth = detector.get_zone_depth(target_zone)
		_label_depth.text = str(snappedf(depth, 0.01))
	
	if _label_speed:
		var speed = detector.get_zone_speed(target_zone)
		_label_speed.text = str(snappedf(speed, 0.01))
	
	if _label_rhythm:
		var rhythm = detector.get_zone_rhythm(target_zone)
		_label_rhythm.text = str(snappedf(rhythm, 0.01))
		# Color it green when good rhythm
		if rhythm > 0.5:
			_label_rhythm.add_theme_color_override("font_color", Color.GREEN)
		else:
			_label_rhythm.add_theme_color_override("font_color", Color.YELLOW)
	
	if _label_penetrating:
		var is_pen = detector.is_zone_penetrated(target_zone)
		_label_penetrating.text = "YES" if is_pen else "no"
		if is_pen:
			_label_penetrating.add_theme_color_override("font_color", Color.GREEN)
		else:
			_label_penetrating.add_theme_color_override("font_color", Color.YELLOW)
	
	if _label_arousal and target_zone.vagina_controller:
		var arousal = target_zone.vagina_controller.get_arousal()
		_label_arousal.text = str(snappedf(arousal, 0.01))
