class_name PenetratorComponent
extends Node3D

# ============================================================
# PENETRATOR COMPONENT - PHASE 4E
# Attach as a child to any 3D object to mark it as a penetrator.
# The component defines:
# - The TIP point (where the object starts to penetrate)
# - The DIRECTION axis (which way it points forward)
# - The PHYSICAL length/girth for depth calculation
# ============================================================

# --- IDENTITY ---
@export_group("Identity")
## Type identifier - useful for filtering (e.g., "penis", "toy", "finger")
@export var penetrator_type: String = "penis"
## Optional tags for matching with specific zones
@export var tags: Array[String] = []

# --- GEOMETRY ---
@export_group("Geometry")
## How far from this node's origin the TIP is (along forward direction)
@export_range(0.0, 1.0, 0.001) var tip_distance: float = 0.1
## How long the penetrating section is from tip to base
@export_range(0.01, 0.5, 0.001) var penetrating_length: float = 0.15
## Width/girth (affects how much the opening must stretch)
@export_range(0.005, 0.1, 0.001) var girth: float = 0.025
## Direction the tip points (in local space). Default = forward (-Z)
@export var forward_direction: Vector3 = Vector3(0, 0, -1)

# --- STATE (read-only at runtime) ---
@export_group("Debug Visualization")
## Show a debug sphere at the tip position in-editor
@export var show_tip_gizmo: bool = true
@export var show_length_gizmo: bool = true

# --- RUNTIME STATE ---
var is_currently_penetrating: bool = false
var current_depth: float = 0.0
var current_zone: PenetrableZone = null


# ============================================================
# PUBLIC GETTERS
# ============================================================

## Get the world-space tip position
func get_tip_position() -> Vector3:
	var forward = forward_direction.normalized()
	var tip_local = forward * tip_distance
	return to_global(tip_local)


## Get the world-space base position (opposite end of penetrating section)
func get_base_position() -> Vector3:
	var forward = forward_direction.normalized()
	var base_local = forward * (tip_distance - penetrating_length)
	return to_global(base_local)


## Get the world-space forward direction
func get_forward_direction() -> Vector3:
	return (global_transform.basis * forward_direction).normalized()


## Check if this penetrator has a specific tag
func has_tag(tag: String) -> bool:
	return tag in tags
