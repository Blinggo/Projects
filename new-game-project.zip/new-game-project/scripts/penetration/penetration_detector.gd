class_name PenetrationDetector
extends Node

# ============================================================
# PENETRATION DETECTOR - PHASE 4E
# Monitors all PenetratorComponents and PenetrableZones in the scene.
# Calculates depth, alignment, speed, and rhythm.
# Drives the VaginaController automatically.
# ============================================================

# --- CONFIGURATION ---
@export_group("Configuration")
## How fast the system polls for penetration checks (Hz)
@export_range(10.0, 120.0, 1.0) var update_rate: float = 60.0
## Smoothing factor for depth changes (higher = less smoothing)
@export_range(0.0, 1.0, 0.05) var depth_smoothing: float = 0.7

# --- RHYTHM TRACKING ---
@export_group("Rhythm")
## Number of recent depth samples kept for rhythm analysis
@export_range(5, 60, 1) var rhythm_sample_count: int = 20
## How quickly arousal builds from consistent rhythm
@export_range(0.0, 2.0, 0.1) var rhythm_arousal_bonus: float = 0.5

# --- DEBUG ---
@export_group("Debug")
@export var debug_log: bool = false
@export var debug_print_interval: float = 1.0

# --- INTERNAL ---
var _penetrators: Array[PenetratorComponent] = []
var _zones: Array[PenetrableZone] = []
var _update_timer: float = 0.0
var _debug_timer: float = 0.0

# Per-zone tracking
class ZoneTracking:
	var zone: PenetrableZone
	var current_penetrator: PenetratorComponent
	var last_depth: float = 0.0
	var smoothed_depth: float = 0.0
	var depth_history: Array[float] = []
	var time_history: Array[float] = []
	var current_speed: float = 0.0
	var rhythm_score: float = 0.0
	var penetration_start_time: float = 0.0

var _tracking: Dictionary = {}  # zone -> ZoneTracking


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	_scan_for_components()
	
	if debug_log:
		print("[PenetrationDetector] Initialized. Found ",
			_penetrators.size(), " penetrators and ",
			_zones.size(), " zones.")


func _process(delta: float) -> void:
	_update_timer += delta
	_debug_timer += delta
	
	var update_interval = 1.0 / update_rate
	if _update_timer >= update_interval:
		_update_timer = 0.0
		_update_all_zones(update_interval)
	
	if debug_log and _debug_timer >= debug_print_interval:
		_debug_timer = 0.0
		_print_debug_state()


# ============================================================
# COMPONENT DISCOVERY
# ============================================================

func _scan_for_components() -> void:
	var root = get_tree().current_scene
	_penetrators.clear()
	_zones.clear()
	
	_scan_recursive(root)
	
	# Initialize tracking for each zone
	for zone in _zones:
		var tracking = ZoneTracking.new()
		tracking.zone = zone
		_tracking[zone] = tracking


func _scan_recursive(node: Node) -> void:
	if node is PenetratorComponent:
		_penetrators.append(node)
	elif node is PenetrableZone:
		_zones.append(node)
	
	for child in node.get_children():
		_scan_recursive(child)


## Manually re-scan if penetrators/zones were added at runtime
func rescan() -> void:
	_scan_for_components()


# ============================================================
# DETECTION & UPDATE
# ============================================================

func _update_all_zones(delta: float) -> void:
	for zone in _zones:
		_update_zone(zone, delta)


func _update_zone(zone: PenetrableZone, delta: float) -> void:
	var tracking: ZoneTracking = _tracking[zone]
	
	# Find best matching penetrator for this zone
	var best_penetrator = _find_best_penetrator_for_zone(zone)
	
	# Handle penetrator change
	if best_penetrator != tracking.current_penetrator:
		if tracking.current_penetrator:
			_on_penetration_ended(zone, tracking)
		if best_penetrator:
			_on_penetration_started(zone, best_penetrator, tracking)
		tracking.current_penetrator = best_penetrator
		zone.current_penetrator = best_penetrator
	
	# Update depth and speed
	if best_penetrator:
		var raw_depth = _calculate_depth(zone, best_penetrator)
		
		# Smooth the depth
		tracking.smoothed_depth = lerpf(
			tracking.smoothed_depth,
			raw_depth,
			depth_smoothing
		)
		
		# Speed = rate of change
		tracking.current_speed = absf(tracking.smoothed_depth - tracking.last_depth) / delta
		tracking.last_depth = tracking.smoothed_depth
		
		# Update zone state
		zone.current_depth_normalized = tracking.smoothed_depth
		zone.current_speed = tracking.current_speed
		
		# Track for rhythm
		_update_rhythm_tracking(tracking, delta)
		zone.rhythm_consistency = tracking.rhythm_score
		
		# Drive the VaginaController
		_drive_vagina_controller(zone, tracking)
	else:
		# No penetrator - decay values
		tracking.smoothed_depth = lerpf(tracking.smoothed_depth, 0.0, delta * 3.0)
		tracking.current_speed = lerpf(tracking.current_speed, 0.0, delta * 5.0)
		tracking.rhythm_score = lerpf(tracking.rhythm_score, 0.0, delta * 1.0)
		
		zone.current_depth_normalized = tracking.smoothed_depth
		zone.current_speed = tracking.current_speed
		zone.rhythm_consistency = tracking.rhythm_score
		
		# Still feed zero penetration to controller (so it knows nothing is there)
		if zone.vagina_controller:
			zone.vagina_controller.set_penetration(tracking.smoothed_depth)


# ============================================================
# PENETRATOR MATCHING
# ============================================================

func _find_best_penetrator_for_zone(zone: PenetrableZone) -> PenetratorComponent:
	var best: PenetratorComponent = null
	var best_score: float = -1.0
	
	for penetrator in _penetrators:
		if not penetrator or not is_instance_valid(penetrator):
			continue
		
		# Check tag compatibility
		if not zone.accepts_penetrator(penetrator):
			continue
		
		# Check if penetrator is close enough
		var entry_pos = zone.get_entry_position()
		var tip_pos = penetrator.get_tip_position()
		var distance = entry_pos.distance_to(tip_pos)
		
		if distance > zone.detection_radius:
			continue
		
		# Check alignment
		var alignment = _calculate_alignment(zone, penetrator)
		var alignment_threshold = cos(deg_to_rad(zone.alignment_tolerance))
		
		if alignment < alignment_threshold:
			continue
		
		# Score = how good this match is (closer + better aligned = higher)
		var distance_score = 1.0 - (distance / zone.detection_radius)
		var alignment_score = (alignment - alignment_threshold) / (1.0 - alignment_threshold)
		var total_score = distance_score * 0.5 + alignment_score * 0.5
		
		if total_score > best_score:
			best_score = total_score
			best = penetrator
	
	return best


func _calculate_alignment(zone: PenetrableZone, penetrator: PenetratorComponent) -> float:
	# Both forward directions should point in similar direction
	# (penetrator forward should match zone "into" direction)
	var zone_forward = zone.get_forward_direction()
	var pen_forward = penetrator.get_forward_direction()
	return zone_forward.dot(pen_forward)


# ============================================================
# DEPTH CALCULATION
# ============================================================

func _calculate_depth(zone: PenetrableZone, penetrator: PenetratorComponent) -> float:
	var entry_pos = zone.get_entry_position()
	var zone_forward = zone.get_forward_direction()
	var tip_pos = penetrator.get_tip_position()
	
	# Project tip position onto zone's forward axis
	var to_tip = tip_pos - entry_pos
	var depth_in_world_units = to_tip.dot(zone_forward)
	
	# Clamp to 0 (before entry) and max_depth (fully inserted)
	depth_in_world_units = clampf(depth_in_world_units, 0.0, zone.max_depth)
	
	# Normalize to 0-1
	return depth_in_world_units / zone.max_depth


# ============================================================
# RHYTHM TRACKING
# ============================================================

func _update_rhythm_tracking(tracking: ZoneTracking, _delta: float) -> void:
	# Add current sample
	tracking.depth_history.append(tracking.smoothed_depth)
	tracking.time_history.append(Time.get_ticks_msec() / 1000.0)
	
	# Trim to sample count
	while tracking.depth_history.size() > rhythm_sample_count:
		tracking.depth_history.pop_front()
		tracking.time_history.pop_front()
	
	if tracking.depth_history.size() < 5:
		tracking.rhythm_score = 0.0
		return
	
	# Calculate rhythm score: detect oscillation (thrusting pattern)
	# Look for changes in direction (peaks and troughs)
	var direction_changes = 0
	var last_direction = 0  # 1=increasing, -1=decreasing
	
	for i in range(1, tracking.depth_history.size()):
		var diff = tracking.depth_history[i] - tracking.depth_history[i - 1]
		var direction = 0
		if diff > 0.01:
			direction = 1
		elif diff < -0.01:
			direction = -1
		
		if direction != 0 and last_direction != 0 and direction != last_direction:
			direction_changes += 1
		if direction != 0:
			last_direction = direction
	
	# More direction changes = more rhythmic thrusting
	# Normalize to 0-1
	var max_expected_changes = float(tracking.depth_history.size()) / 3.0
	tracking.rhythm_score = clampf(float(direction_changes) / max_expected_changes, 0.0, 1.0)


# ============================================================
# DRIVE VAGINACONTROLLER
# ============================================================

func _drive_vagina_controller(zone: PenetrableZone, tracking: ZoneTracking) -> void:
	if not zone.vagina_controller:
		return
	
	# Feed penetration depth to the controller
	var depth = tracking.smoothed_depth * zone.opening_response_strength
	zone.vagina_controller.set_penetration(depth)
	
	# Apply arousal based on activity
	# Speed contributes to general arousal
	var speed_arousal = clampf(tracking.current_speed * 0.5, 0.0, 1.0)
	# Rhythm gives bonus arousal
	var rhythm_bonus = tracking.rhythm_score * rhythm_arousal_bonus
	# Combined input
	var total_arousal_input = speed_arousal + rhythm_bonus
	
	if total_arousal_input > 0.01:
		zone.vagina_controller.apply_arousal_stimulation(total_arousal_input)


# ============================================================
# PENETRATION EVENTS
# ============================================================

func _on_penetration_started(zone: PenetrableZone, penetrator: PenetratorComponent, tracking: ZoneTracking) -> void:
	penetrator.is_currently_penetrating = true
	penetrator.current_zone = zone
	tracking.penetration_start_time = Time.get_ticks_msec() / 1000.0
	
	if debug_log:
		print("[Penetration] Started: ", penetrator.penetrator_type, " into ", zone.zone_type)


func _on_penetration_ended(zone: PenetrableZone, tracking: ZoneTracking) -> void:
	if tracking.current_penetrator:
		tracking.current_penetrator.is_currently_penetrating = false
		tracking.current_penetrator.current_zone = null
		
		if debug_log:
			var duration = (Time.get_ticks_msec() / 1000.0) - tracking.penetration_start_time
			print("[Penetration] Ended: ", tracking.current_penetrator.penetrator_type, 
				" from ", zone.zone_type, " (duration: ", snappedf(duration, 0.01), "s)")
	
	# Clear history
	tracking.depth_history.clear()
	tracking.time_history.clear()
	tracking.rhythm_score = 0.0


# ============================================================
# DEBUG
# ============================================================

func _print_debug_state() -> void:
	print("--- Penetration Detector State ---")
	for zone in _zones:
		var tracking: ZoneTracking = _tracking[zone]
		var pen_name = "none"
		if tracking.current_penetrator:
			pen_name = tracking.current_penetrator.penetrator_type
		print("  Zone: ", zone.zone_type,
			" | Penetrator: ", pen_name,
			" | Depth: ", snappedf(tracking.smoothed_depth, 0.01),
			" | Speed: ", snappedf(tracking.current_speed, 0.01),
			" | Rhythm: ", snappedf(tracking.rhythm_score, 0.01))


# ============================================================
# PUBLIC API
# ============================================================

## Get the current depth of a specific zone (0-1)
func get_zone_depth(zone: PenetrableZone) -> float:
	if zone in _tracking:
		return (_tracking[zone] as ZoneTracking).smoothed_depth
	return 0.0


## Get the current speed for a specific zone
func get_zone_speed(zone: PenetrableZone) -> float:
	if zone in _tracking:
		return (_tracking[zone] as ZoneTracking).current_speed
	return 0.0


## Get the rhythm score (0-1) for a specific zone
func get_zone_rhythm(zone: PenetrableZone) -> float:
	if zone in _tracking:
		return (_tracking[zone] as ZoneTracking).rhythm_score
	return 0.0


## Is anything currently penetrating this zone?
func is_zone_penetrated(zone: PenetrableZone) -> bool:
	if zone in _tracking:
		return (_tracking[zone] as ZoneTracking).current_penetrator != null
	return false
