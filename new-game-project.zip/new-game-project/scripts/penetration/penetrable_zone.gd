class_name PenetrableZone
extends Node3D

# ============================================================
# PENETRABLE ZONE - PHASE 4E
# Defines an entry point and internal cavity on a body part.
# Place this on the model where penetration is possible.
# 
# Key positions:
# - Entry point: this node's own position (where opening is)
# - Depth point: forward along -Z by max_depth distance
# ============================================================

# --- IDENTITY ---
@export_group("Identity")
## Type of zone (e.g., "vagina", "mouth", "anus")
@export var zone_type: String = "vagina"
## Which penetrator tags are accepted (empty = accept all)
@export var accepted_tags: Array[String] = []

# --- GEOMETRY ---
@export_group("Geometry")
## Maximum depth the penetrator can go (in world units)
@export_range(0.05, 0.5, 0.001) var max_depth: float = 0.15
## Maximum diameter of the opening (girth tolerance)
@export_range(0.01, 0.1, 0.001) var opening_diameter: float = 0.04
## Acceptance angle in degrees (how aligned penetrator must be)
@export_range(10.0, 90.0, 1.0) var alignment_tolerance: float = 45.0
## Detection radius around entry point (how close penetrator must be)
@export_range(0.02, 0.3, 0.005) var detection_radius: float = 0.08

# --- VISUAL FEEDBACK ---
@export_group("Visual Feedback")
## VaginaController to drive (auto-finds in scene if null)
@export var vagina_controller: VaginaController
## How much penetration affects opening (0 to 1)
@export_range(0.0, 1.0, 0.01) var opening_response_strength: float = 1.0

# --- DEBUG ---
@export_group("Debug")
@export var debug_log: bool = false
## Show entry point and depth markers in editor
@export var show_gizmos: bool = true

# --- STATE ---
var current_penetrator: PenetratorComponent = null
var current_depth_normalized: float = 0.0
var current_speed: float = 0.0
var last_depth_normalized: float = 0.0
var rhythm_consistency: float = 0.0


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	if not vagina_controller:
		vagina_controller = _auto_find_vagina_controller()
	
	if debug_log:
		print("[PenetrableZone] '", zone_type, "' initialized at: ", global_position)


# ============================================================
# PUBLIC GETTERS
# ============================================================

## Get world-space entry point (this node's position)
func get_entry_position() -> Vector3:
	return global_position


## Get world-space deepest point (entry + forward by max_depth)
func get_depth_position() -> Vector3:
	var forward = -global_transform.basis.z.normalized()
	return global_position + forward * max_depth


## Get world-space forward direction (into the cavity)
func get_forward_direction() -> Vector3:
	return -global_transform.basis.z.normalized()


## Check if a penetrator's tags are accepted by this zone
func accepts_penetrator(penetrator: PenetratorComponent) -> bool:
	if accepted_tags.is_empty():
		return true
	for tag in accepted_tags:
		if penetrator.has_tag(tag):
			return true
	return false


# ============================================================
# UTILITY
# ============================================================

func _auto_find_vagina_controller() -> VaginaController:
	var root = get_tree().current_scene
	return _find_vagina_controller_recursive(root)


func _find_vagina_controller_recursive(node: Node) -> VaginaController:
	if node is VaginaController:
		return node
	for child in node.get_children():
		var result = _find_vagina_controller_recursive(child)
		if result:
			return result
	return null
