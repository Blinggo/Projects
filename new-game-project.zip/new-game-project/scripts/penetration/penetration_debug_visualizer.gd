@tool
class_name PenetrationDebugVisualizer
extends Node

# ============================================================
# PENETRATION DEBUG VISUALIZER - EDITOR + RUNTIME
# Shows 3D visual indicators for zones, penetrators, and state.
# Works BOTH in editor and at runtime.
# ============================================================

# --- REFERENCES ---
@export_group("References")
@export var detector: PenetrationDetector
## Toggle all visuals on/off (works in editor)
@export var enabled: bool = true:
	set(value):
		enabled = value
		if _initialized:
			_update_visibility()
		if Engine.is_editor_hint():
			_refresh_editor_visuals()

# --- EDITOR MODE ---
@export_group("Editor Mode")
## Force refresh of editor visuals (toggle to rebuild)
@export var refresh_editor_visuals: bool = false:
	set(value):
		if value and Engine.is_editor_hint():
			_refresh_editor_visuals()
		refresh_editor_visuals = false

# --- VISUAL OPTIONS ---
@export_group("Visual Options")
@export var show_detection_radius: bool = true:
	set(value):
		show_detection_radius = value
		if _initialized: _update_visibility()
@export var show_direction_arrow: bool = true:
	set(value):
		show_direction_arrow = value
		if _initialized: _update_visibility()
@export var show_depth_line: bool = true:
	set(value):
		show_depth_line = value
		if _initialized: _update_visibility()
@export var show_alignment_cone: bool = true:
	set(value):
		show_alignment_cone = value
		if _initialized: _update_visibility()
@export var show_penetrator_tip: bool = true:
	set(value):
		show_penetrator_tip = value
		if _initialized: _update_visibility()
@export var show_info_labels: bool = true:
	set(value):
		show_info_labels = value
		if _initialized: _update_visibility()

# --- COLORS ---
@export_group("Colors")
@export var color_idle: Color = Color(1.0, 0.3, 0.3, 0.15)
@export var color_near: Color = Color(1.0, 1.0, 0.2, 0.2)
@export var color_active: Color = Color(0.2, 1.0, 0.3, 0.25)
@export var color_direction: Color = Color(0.0, 0.5, 1.0, 0.8)
@export var color_depth_line: Color = Color(1.0, 0.0, 1.0, 0.9)
@export var color_tip: Color = Color(1.0, 1.0, 0.0, 0.9)

# --- INTERNAL ---
class ZoneVisuals:
	var radius_mesh: MeshInstance3D
	var direction_mesh: MeshInstance3D
	var depth_line_mesh: MeshInstance3D
	var cone_mesh: MeshInstance3D
	var entry_marker: MeshInstance3D
	var depth_marker: MeshInstance3D
	var label_3d: Label3D

class PenetratorVisuals:
	var tip_mesh: MeshInstance3D
	var base_mesh: MeshInstance3D
	var forward_mesh: MeshInstance3D

var _zone_visuals: Dictionary = {}
var _pen_visuals: Dictionary = {}
var _zones: Array = []
var _penetrators: Array = []
var _initialized: bool = false


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	# In editor mode, initialize immediately
	if Engine.is_editor_hint():
		call_deferred("_initialize_visuals")
		return
	
	# Runtime mode - find detector first
	if not detector:
		detector = _find_detector()
	
	call_deferred("_initialize_visuals")


func _process(_delta: float) -> void:
	if not enabled or not _initialized:
		return
	
	# Editor mode: update positions but skip runtime state colors
	if Engine.is_editor_hint():
		_update_zone_visuals_editor()
		_update_penetrator_visuals_editor()
		return
	
	# Runtime mode: full update
	_update_zone_visuals_runtime()
	_update_penetrator_visuals_runtime()


# ============================================================
# EDITOR REFRESH
# ============================================================

func _refresh_editor_visuals() -> void:
	# Clean up existing visuals
	_cleanup_visuals()
	# Re-initialize
	call_deferred("_initialize_visuals")


func _cleanup_visuals() -> void:
	for zone in _zone_visuals.values():
		var v = zone as ZoneVisuals
		if v.radius_mesh: v.radius_mesh.queue_free()
		if v.direction_mesh: v.direction_mesh.queue_free()
		if v.depth_line_mesh: v.depth_line_mesh.queue_free()
		if v.cone_mesh: v.cone_mesh.queue_free()
		if v.entry_marker: v.entry_marker.queue_free()
		if v.depth_marker: v.depth_marker.queue_free()
		if v.label_3d: v.label_3d.queue_free()
	
	for pen in _pen_visuals.values():
		var v = pen as PenetratorVisuals
		if v.tip_mesh: v.tip_mesh.queue_free()
		if v.base_mesh: v.base_mesh.queue_free()
		if v.forward_mesh: v.forward_mesh.queue_free()
	
	_zone_visuals.clear()
	_pen_visuals.clear()
	_zones.clear()
	_penetrators.clear()
	_initialized = false


# ============================================================
# INITIALIZATION
# ============================================================

func _initialize_visuals() -> void:
	if _initialized:
		return
	
	# Get the scene root - works in both editor and runtime
	var scene_root: Node = null
	if Engine.is_editor_hint():
		scene_root = get_tree().edited_scene_root
	else:
		scene_root = get_tree().current_scene
	
	if not scene_root:
		return
	
	# Find all zones and penetrators
	_scan_components(scene_root)
	
	# Create visuals for each zone
	for zone in _zones:
		var visuals = _create_zone_visuals(zone)
		_zone_visuals[zone] = visuals
	
	# Create visuals for each penetrator
	for pen in _penetrators:
		var visuals = _create_penetrator_visuals(pen)
		_pen_visuals[pen] = visuals
	
	_initialized = true
	
	if not Engine.is_editor_hint():
		print("[PenetrationDebugVisualizer] Created visuals for ", 
			_zones.size(), " zones and ", _penetrators.size(), " penetrators")


func _scan_components(node: Node) -> void:
	if node is PenetrableZone:
		_zones.append(node)
	elif node is PenetratorComponent:
		_penetrators.append(node)
	for child in node.get_children():
		_scan_components(child)


# ============================================================
# ZONE VISUALS CREATION
# ============================================================

func _create_zone_visuals(zone: PenetrableZone) -> ZoneVisuals:
	var v = ZoneVisuals.new()
	
	if show_detection_radius:
		v.radius_mesh = _make_sphere(zone.detection_radius, color_idle)
		add_child(v.radius_mesh)
	
	if show_direction_arrow:
		v.direction_mesh = _make_arrow(0.08, color_direction)
		add_child(v.direction_mesh)
	
	if show_depth_line:
		v.depth_line_mesh = _make_line(zone.max_depth, color_depth_line)
		add_child(v.depth_line_mesh)
		
		v.entry_marker = _make_sphere(0.005, Color.GREEN)
		add_child(v.entry_marker)
		
		v.depth_marker = _make_sphere(0.005, Color.RED)
		add_child(v.depth_marker)
	
	if show_alignment_cone:
		v.cone_mesh = _make_cone(zone.detection_radius * 0.8, zone.alignment_tolerance, color_idle)
		add_child(v.cone_mesh)
	
	if show_info_labels:
		v.label_3d = Label3D.new()
		v.label_3d.text = zone.zone_type
		v.label_3d.font_size = 32
		v.label_3d.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		v.label_3d.no_depth_test = true
		v.label_3d.modulate = Color.WHITE
		add_child(v.label_3d)
	
	return v


func _create_penetrator_visuals(pen: PenetratorComponent) -> PenetratorVisuals:
	var v = PenetratorVisuals.new()
	
	if show_penetrator_tip:
		v.tip_mesh = _make_sphere(0.006, color_tip)
		add_child(v.tip_mesh)
		
		v.base_mesh = _make_sphere(0.004, Color(1.0, 0.5, 0.0, 0.8))
		add_child(v.base_mesh)
		
		v.forward_mesh = _make_line(0.05, Color(0.0, 1.0, 1.0, 0.7))
		add_child(v.forward_mesh)
	
	return v


# ============================================================
# UPDATE - EDITOR MODE (position only, no runtime state)
# ============================================================

func _update_zone_visuals_editor() -> void:
	for zone in _zones:
		if not is_instance_valid(zone):
			continue
		if zone not in _zone_visuals:
			continue
		
		var v: ZoneVisuals = _zone_visuals[zone]
		var entry_pos = zone.get_entry_position()
		var depth_pos = zone.get_depth_position()
		var forward = zone.get_forward_direction()
		
		# Update sizes in case they changed in inspector
		_update_zone_sizes(v, zone)
		
		if v.radius_mesh:
			v.radius_mesh.global_position = entry_pos
			_update_mesh_color(v.radius_mesh, color_idle)
		
		if v.direction_mesh:
			v.direction_mesh.global_position = entry_pos
			v.direction_mesh.look_at(entry_pos + forward, Vector3.UP)
		
		if v.depth_line_mesh:
			v.depth_line_mesh.global_position = entry_pos
			v.depth_line_mesh.look_at(depth_pos, Vector3.UP)
		
		if v.entry_marker:
			v.entry_marker.global_position = entry_pos
		
		if v.depth_marker:
			v.depth_marker.global_position = depth_pos
		
		if v.cone_mesh:
			v.cone_mesh.global_position = entry_pos
			v.cone_mesh.look_at(entry_pos + forward, Vector3.UP)
			_update_mesh_color(v.cone_mesh, color_idle)
		
		if v.label_3d:
			v.label_3d.global_position = entry_pos + Vector3(0, 0.05, 0)
			v.label_3d.text = "%s\n[EDITOR PREVIEW]\nRadius: %.3f\nMax Depth: %.3f\nAlign Tol: %.0f°" % [
				zone.zone_type.to_upper(),
				zone.detection_radius,
				zone.max_depth,
				zone.alignment_tolerance
			]
			v.label_3d.modulate = Color(1, 1, 1, 0.9)


func _update_penetrator_visuals_editor() -> void:
	for pen in _penetrators:
		if not is_instance_valid(pen):
			continue
		if pen not in _pen_visuals:
			continue
		
		var v: PenetratorVisuals = _pen_visuals[pen]
		
		if v.tip_mesh:
			v.tip_mesh.global_position = pen.get_tip_position()
			_update_mesh_color(v.tip_mesh, color_tip)
		
		if v.base_mesh:
			v.base_mesh.global_position = pen.get_base_position()
		
		if v.forward_mesh:
			var tip_pos = pen.get_tip_position()
			var forward = pen.get_forward_direction()
			v.forward_mesh.global_position = tip_pos
			v.forward_mesh.look_at(tip_pos + forward, Vector3.UP)


# ============================================================
# UPDATE - RUNTIME MODE (with state colors)
# ============================================================

func _update_zone_visuals_runtime() -> void:
	for zone in _zones:
		if not is_instance_valid(zone):
			continue
		if zone not in _zone_visuals:
			continue
		
		var v: ZoneVisuals = _zone_visuals[zone]
		var entry_pos = zone.get_entry_position()
		var depth_pos = zone.get_depth_position()
		var forward = zone.get_forward_direction()
		
		# Determine state for coloring
		var is_penetrated = false
		var is_near = false
		
		if detector:
			is_penetrated = detector.is_zone_penetrated(zone)
			if not is_penetrated:
				for pen in _penetrators:
					if is_instance_valid(pen):
						var dist = entry_pos.distance_to(pen.get_tip_position())
						if dist < zone.detection_radius * 1.5:
							is_near = true
							break
		
		var current_color: Color
		if is_penetrated:
			current_color = color_active
		elif is_near:
			current_color = color_near
		else:
			current_color = color_idle
		
		if v.radius_mesh:
			v.radius_mesh.global_position = entry_pos
			_update_mesh_color(v.radius_mesh, current_color)
		
		if v.direction_mesh:
			v.direction_mesh.global_position = entry_pos
			v.direction_mesh.look_at(entry_pos + forward, Vector3.UP)
		
		if v.depth_line_mesh:
			v.depth_line_mesh.global_position = entry_pos
			v.depth_line_mesh.look_at(depth_pos, Vector3.UP)
		
		if v.entry_marker:
			v.entry_marker.global_position = entry_pos
		
		if v.depth_marker:
			v.depth_marker.global_position = depth_pos
		
		if v.cone_mesh:
			v.cone_mesh.global_position = entry_pos
			v.cone_mesh.look_at(entry_pos + forward, Vector3.UP)
			_update_mesh_color(v.cone_mesh, current_color)
		
		if v.label_3d:
			v.label_3d.global_position = entry_pos + Vector3(0, 0.05, 0)
			var depth = 0.0
			var speed = 0.0
			var rhythm = 0.0
			if detector:
				depth = detector.get_zone_depth(zone)
				speed = detector.get_zone_speed(zone)
				rhythm = detector.get_zone_rhythm(zone)
			
			var state_text = "IDLE"
			if is_penetrated:
				state_text = "PENETRATED"
				v.label_3d.modulate = Color.GREEN
			elif is_near:
				state_text = "NEAR"
				v.label_3d.modulate = Color.YELLOW
			else:
				v.label_3d.modulate = Color.WHITE
			
			v.label_3d.text = "%s [%s]\nDepth: %.2f\nSpeed: %.2f\nRhythm: %.2f" % [
				zone.zone_type.to_upper(),
				state_text,
				depth,
				speed,
				rhythm
			]


func _update_penetrator_visuals_runtime() -> void:
	for pen in _penetrators:
		if not is_instance_valid(pen):
			continue
		if pen not in _pen_visuals:
			continue
		
		var v: PenetratorVisuals = _pen_visuals[pen]
		
		if v.tip_mesh:
			v.tip_mesh.global_position = pen.get_tip_position()
			if pen.is_currently_penetrating:
				_update_mesh_color(v.tip_mesh, Color.GREEN)
			else:
				_update_mesh_color(v.tip_mesh, color_tip)
		
		if v.base_mesh:
			v.base_mesh.global_position = pen.get_base_position()
		
		if v.forward_mesh:
			var tip_pos = pen.get_tip_position()
			var forward = pen.get_forward_direction()
			v.forward_mesh.global_position = tip_pos
			v.forward_mesh.look_at(tip_pos + forward, Vector3.UP)


# ============================================================
# DYNAMIC SIZE UPDATES (for editor when inspector values change)
# ============================================================

func _update_zone_sizes(v: ZoneVisuals, zone: PenetrableZone) -> void:
	# Update sphere radius if it changed
	if v.radius_mesh and v.radius_mesh.mesh is SphereMesh:
		var sphere = v.radius_mesh.mesh as SphereMesh
		if abs(sphere.radius - zone.detection_radius) > 0.001:
			sphere.radius = zone.detection_radius
			sphere.height = zone.detection_radius * 2.0
	
	# Update depth line length if max_depth changed
	if v.depth_line_mesh and v.depth_line_mesh.mesh is CylinderMesh:
		var cyl = v.depth_line_mesh.mesh as CylinderMesh
		if abs(cyl.height - zone.max_depth) > 0.001:
			cyl.height = zone.max_depth
			v.depth_line_mesh.position.z = -zone.max_depth * 0.5


# ============================================================
# MESH BUILDERS
# ============================================================

func _make_sphere(radius: float, color: Color) -> MeshInstance3D:
	var mesh_inst = MeshInstance3D.new()
	var sphere = SphereMesh.new()
	sphere.radius = radius
	sphere.height = radius * 2.0
	sphere.radial_segments = 16
	sphere.rings = 8
	
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.no_depth_test = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	sphere.material = mat
	
	mesh_inst.mesh = sphere
	return mesh_inst


func _make_arrow(length: float, color: Color) -> MeshInstance3D:
	var mesh_inst = MeshInstance3D.new()
	var cylinder = CylinderMesh.new()
	cylinder.top_radius = 0.001
	cylinder.bottom_radius = 0.003
	cylinder.height = length
	cylinder.radial_segments = 8
	
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.no_depth_test = true
	cylinder.material = mat
	
	mesh_inst.mesh = cylinder
	mesh_inst.rotation.x = deg_to_rad(90)
	mesh_inst.position.z = -length * 0.5
	return mesh_inst


func _make_line(length: float, color: Color) -> MeshInstance3D:
	var mesh_inst = MeshInstance3D.new()
	var cylinder = CylinderMesh.new()
	cylinder.top_radius = 0.0015
	cylinder.bottom_radius = 0.0015
	cylinder.height = length
	cylinder.radial_segments = 6
	
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.no_depth_test = true
	cylinder.material = mat
	
	mesh_inst.mesh = cylinder
	mesh_inst.rotation.x = deg_to_rad(90)
	mesh_inst.position.z = -length * 0.5
	return mesh_inst


func _make_cone(length: float, angle_degrees: float, color: Color) -> MeshInstance3D:
	var radius = tan(deg_to_rad(angle_degrees)) * length
	
	var mesh_inst = MeshInstance3D.new()
	var cylinder = CylinderMesh.new()
	cylinder.top_radius = 0.001
	cylinder.bottom_radius = radius
	cylinder.height = length
	cylinder.radial_segments = 16
	
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.no_depth_test = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	cylinder.material = mat
	
	mesh_inst.mesh = cylinder
	mesh_inst.rotation.x = deg_to_rad(90)
	mesh_inst.position.z = -length * 0.5
	return mesh_inst


func _update_mesh_color(mesh_inst: MeshInstance3D, color: Color) -> void:
	if mesh_inst and mesh_inst.mesh and mesh_inst.mesh.material:
		var mat = mesh_inst.mesh.material as StandardMaterial3D
		if mat:
			mat.albedo_color = color


# ============================================================
# VISIBILITY
# ============================================================

func _update_visibility() -> void:
	for zone in _zone_visuals.values():
		var v = zone as ZoneVisuals
		if v.radius_mesh: v.radius_mesh.visible = enabled and show_detection_radius
		if v.direction_mesh: v.direction_mesh.visible = enabled and show_direction_arrow
		if v.depth_line_mesh: v.depth_line_mesh.visible = enabled and show_depth_line
		if v.entry_marker: v.entry_marker.visible = enabled and show_depth_line
		if v.depth_marker: v.depth_marker.visible = enabled and show_depth_line
		if v.cone_mesh: v.cone_mesh.visible = enabled and show_alignment_cone
		if v.label_3d: v.label_3d.visible = enabled and show_info_labels
	
	for pen in _pen_visuals.values():
		var v = pen as PenetratorVisuals
		if v.tip_mesh: v.tip_mesh.visible = enabled and show_penetrator_tip
		if v.base_mesh: v.base_mesh.visible = enabled and show_penetrator_tip
		if v.forward_mesh: v.forward_mesh.visible = enabled and show_penetrator_tip


# ============================================================
# UTILITY
# ============================================================

func _find_detector() -> PenetrationDetector:
	var scene_root: Node = null
	if Engine.is_editor_hint():
		scene_root = get_tree().edited_scene_root
	else:
		scene_root = get_tree().current_scene
	
	if scene_root:
		return _find_recursive(scene_root)
	return null


func _find_recursive(node: Node) -> PenetrationDetector:
	if node is PenetrationDetector:
		return node
	for child in node.get_children():
		var found = _find_recursive(child)
		if found:
			return found
	return null
