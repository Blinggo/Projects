class_name VaginaAudioController
extends Node

# ============================================================
# VAGINA AUDIO CONTROLLER - PHASE 4C
# Handles all sound for the vagina system:
# - Arousal-based breathing
# - Milestone triggers
# - Stimulation sounds
# - Orgasm sequence
# - Refractory recovery
# Godot 4.6.1 - Mobile Renderer Compatible
# ============================================================

## The VaginaController to read state from
@export var controller: VaginaController

# --- BREATHING ---
@export_group("Breathing Audio")
@export var breathing_light: AudioStream
@export var breathing_medium: AudioStream
@export var breathing_heavy: AudioStream
@export var breathing_base_volume: float = 0.6
## Arousal level where breathing transitions from light to medium
@export_range(0.0, 1.0, 0.05) var breathing_light_threshold: float = 0.3
## Arousal level where breathing transitions from medium to heavy
@export_range(0.0, 1.0, 0.05) var breathing_heavy_threshold: float = 0.65
@export_range(0.1, 3.0, 0.1) var breathing_crossfade_speed: float = 1.5

# --- MOAN MILESTONES ---
@export_group("Milestone Sounds")
## Each entry: { arousal_threshold: float, audio: AudioStream, one_shot: bool }
@export var milestone_sounds: Array[MilestoneEntry] = []
## Minimum seconds between milestone triggers
@export_range(0.5, 5.0, 0.1) var milestone_cooldown: float = 2.0
## Base volume for milestone sounds
@export_range(0.0, 1.0, 0.05) var milestone_volume: float = 0.7

# --- STIMULATION ---
@export_group("Stimulation Sounds")
@export var stimulation_penetration: AudioStream
@export var stimulation_clit: AudioStream
@export_range(0.0, 1.0, 0.05) var stimulation_penetration_volume: float = 0.5
@export_range(0.0, 1.0, 0.05) var stimulation_clit_volume: float = 0.5
## How fast stimulation sounds fade in/out
@export_range(0.5, 5.0, 0.1) var stimulation_crossfade_speed: float = 2.0

# --- ORGASM ---
@export_group("Orgasm Audio")
@export var orgasm_buildup: AudioStream
@export var orgasm_climax: AudioStream
@export var orgasm_post_pant: AudioStream
@export_range(0.0, 1.0, 0.05) var orgasm_buildup_volume: float = 0.6
@export_range(0.0, 1.0, 0.05) var orgasm_climax_volume: float = 0.85
@export_range(0.0, 1.0, 0.05) var orgasm_pant_volume: float = 0.5

# --- REFRACTORY ---
@export_group("Refractory Audio")
@export var refractory_breath: AudioStream
@export_range(0.0, 1.0, 0.05) var refractory_volume: float = 0.4

# --- GENERAL ---
@export_group("General")
@export var auto_start_breathing: bool = true
@export var master_volume: float = 1.0
@export var debug_log_audio: bool = false

# --- MILESTONE ENTRY RESOURCE ---
class MilestoneEntry:
	extends Resource
	## Arousal level that triggers this sound (e.g. 0.3 = 30% arousal)
	@export_range(0.0, 1.0, 0.01) var arousal_threshold: float = 0.5
	## The sound to play
	@export var audio: AudioStream
	## Play only once when crossing the threshold, or play repeatedly
	@export var one_shot: bool = true

# --- INTERNAL ---
var _player_breathing_light: AudioStreamPlayer
var _player_breathing_medium: AudioStreamPlayer
var _player_breathing_heavy: AudioStreamPlayer
var _player_penetration: AudioStreamPlayer
var _player_clit: AudioStreamPlayer
var _player_milestone: AudioStreamPlayer
var _player_orgasm_buildup: AudioStreamPlayer
var _player_orgasm_climax: AudioStreamPlayer
var _player_orgasm_pant: AudioStreamPlayer
var _player_refractory: AudioStreamPlayer

var _current_breathing_state: int = -1  # 0=light, 1=medium, 2=heavy
var _milestone_cooldown_timer: float = 0.0
var _milestones_triggered: Dictionary = {}
var _was_orgasming: bool = false
var _was_in_refractory: bool = false
var _buildup_played_this_orgasm: bool = false


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	_create_audio_players()
	
	if auto_start_breathing:
		# Start with silence, breathing fades in as arousal changes
		pass
	
	print("[VaginaAudioController] Initialized with ", _count_streams(), " audio streams loaded.")


func _process(delta: float) -> void:
	if not controller or not controller.state:
		return
	
	_update_breathing(delta)
	_update_stimulation_sounds(delta)
	_update_milestones(delta)
	_update_orgasm_audio()
	_update_refractory_audio(delta)
	
	_milestone_cooldown_timer = maxf(_milestone_cooldown_timer - delta, 0.0)


# ============================================================
# AUDIO PLAYER CREATION
# ============================================================

func _create_audio_players() -> void:
	_player_breathing_light = _make_player("BreathingLight")
	_player_breathing_medium = _make_player("BreathingMedium")
	_player_breathing_heavy = _make_player("BreathingHeavy")
	_player_penetration = _make_player("PenetrationStim")
	_player_clit = _make_player("ClitStim")
	_player_milestone = _make_player("Milestone")
	_player_orgasm_buildup = _make_player("OrgasmBuildup")
	_player_orgasm_climax = _make_player("OrgasmClimax")
	_player_orgasm_pant = _make_player("OrgasmPant")
	_player_refractory = _make_player("Refractory")
	
	# Set streams
	_set_stream(_player_breathing_light, breathing_light, true)
	_set_stream(_player_breathing_medium, breathing_medium, true)
	_set_stream(_player_breathing_heavy, breathing_heavy, true)
	_set_stream(_player_penetration, stimulation_penetration, true)
	_set_stream(_player_clit, stimulation_clit, true)
	_set_stream(_player_orgasm_buildup, orgasm_buildup, false)
	_set_stream(_player_orgasm_climax, orgasm_climax, false)
	_set_stream(_player_orgasm_pant, orgasm_post_pant, false)
	_set_stream(_player_refractory, refractory_breath, true)


func _make_player(player_name: String) -> AudioStreamPlayer:
	var player: AudioStreamPlayer = AudioStreamPlayer.new()
	player.name = player_name
	player.bus = "Master"
	add_child(player)
	return player


func _set_stream(player: AudioStreamPlayer, stream: AudioStream, loop: bool) -> void:
	if stream:
		player.stream = stream
		if debug_log_audio:
			print("[Audio] Set stream for ", player.name)


func _count_streams() -> int:
	var count: int = 0
	for child in get_children():
		if child is AudioStreamPlayer and child.stream:
			count += 1
	return count


# ============================================================
# BREATHING SYSTEM
# ============================================================

func _update_breathing(delta: float) -> void:
	var arousal: float = controller.get_arousal()
	var new_state: int
	
	if arousal < breathing_light_threshold:
		new_state = 0  # light
	elif arousal < breathing_heavy_threshold:
		new_state = 1  # medium
	else:
		new_state = 2  # heavy
	
	# Only crossfade when state actually changes
	if new_state != _current_breathing_state:
		_crossfade_breathing(new_state, delta)
		_current_breathing_state = new_state
	
	# Scale breathing volume with arousal (barely audible when calm, prominent when aroused)
	var breath_vol: float = breathing_base_volume * (0.3 + arousal * 0.7)
	_adjust_all_breathing_volume(breath_vol)


func _crossfade_breathing(target_state: int, _delta: float) -> void:
	var target_player: AudioStreamPlayer
	var fade_time: float = breathing_crossfade_speed
	
	match target_state:
		0:
			target_player = _player_breathing_light
		1:
			target_player = _player_breathing_medium
		2:
			target_player = _player_breathing_heavy
		_:
			return
	
	# Fade out all breathing players
	_fade_player(_player_breathing_light, 0.0, fade_time)
	_fade_player(_player_breathing_medium, 0.0, fade_time)
	_fade_player(_player_breathing_heavy, 0.0, fade_time)
	
	# Fade in target
	if target_player.stream:
		target_player.play()
		_fade_player(target_player, breathing_base_volume, fade_time)
	
	if debug_log_audio:
		print("[Audio] Breathing state -> ", ["LIGHT", "MEDIUM", "HEAVY"][target_state])


func _adjust_all_breathing_volume(vol: float) -> void:
	# Only adjust volume of whichever breathing is currently active
	match _current_breathing_state:
		0:
			_player_breathing_light.volume_db = linear_to_db(maxf(vol, 0.001))
		1:
			_player_breathing_medium.volume_db = linear_to_db(maxf(vol, 0.001))
		2:
			_player_breathing_heavy.volume_db = linear_to_db(maxf(vol, 0.001))


# ============================================================
# MILESTONE SYSTEM
# ============================================================

func _update_milestones(_delta: float) -> void:
	var arousal: float = controller.get_arousal()
	
	if _milestone_cooldown_timer > 0.0:
		return
	
	for entry in milestone_sounds:
		if not entry or not entry.audio:
			continue
		
		var threshold: float = entry.arousal_threshold
		var key: float = threshold
		
		# One-shot: only trigger once per arousal crossing
		if entry.one_shot:
			var was_triggered: bool = _milestones_triggered.get(key, false)
			var is_above: bool = arousal >= threshold
			
			if is_above and not was_triggered:
				_play_milestone(entry.audio)
				_milestones_triggered[key] = true
				_milestone_cooldown_timer = milestone_cooldown
				break
			elif not is_above:
				_milestones_triggered[key] = false
		else:
			# Repeating: trigger every time arousal crosses the threshold
			var is_above: bool = arousal >= threshold
			if is_above:
				_play_milestone(entry.audio)
				_milestone_cooldown_timer = milestone_cooldown
				break


func _play_milestone(audio: AudioStream) -> void:
	if not audio:
		return
	_player_milestone.stream = audio
	_player_milestone.volume_db = linear_to_db(milestone_volume * master_volume)
	_player_milestone.play()
	
	if debug_log_audio:
		print("[Audio] Milestone triggered: ", audio.resource_path.get_file())


# ============================================================
# STIMULATION SOUNDS
# ============================================================

func _update_stimulation_sounds(delta: float) -> void:
	# Penetration sound
	var pen_input: float = controller.state.penetration_input_this_frame
	var pen_vol: float = pen_input * stimulation_penetration_volume * master_volume
	_fade_player(_player_penetration, pen_vol, stimulation_crossfade_speed)
	
	# Clit stimulation sound
	var clit_input: float = controller.state.clit_stim_input_this_frame
	var clit_vol: float = clit_input * stimulation_clit_volume * master_volume
	_fade_player(_player_clit, clit_vol, stimulation_crossfade_speed)


# ============================================================
# ORGASM AUDIO SEQUENCE
# ============================================================

func _update_orgasm_audio() -> void:
	var is_orgasming: bool = controller.state.is_orgasming
	var orgasm_intensity: float = controller.state.orgasm_intensity
	
	# BUILDUP - plays during orgasm buildup phase (first 15% of orgasm)
	if is_orgasming and not _was_orgasming:
		# Orgasm just started
		_buildup_played_this_orgasm = false
	
	if is_orgasming and orgasm_intensity < 0.9 and not _buildup_played_this_orgasm:
		if orgasm_buildup:
			_player_orgasm_buildup.stream = orgasm_buildup
			_player_orgasm_buildup.volume_db = linear_to_db(orgasm_buildup_volume * master_volume)
			_player_orgasm_buildup.play()
			_buildup_played_this_orgasm = true
			
			if debug_log_audio:
				print("[Audio] Orgasm buildup started")
	
	# CLIMAX - plays when orgasm intensity hits peak
	if is_orgasming and orgasm_intensity >= 0.9:
		if orgasm_climax and not _player_orgasm_climax.playing:
			_player_orgasm_climax.stream = orgasm_climax
			_player_orgasm_climax.volume_db = linear_to_db(orgasm_climax_volume * master_volume)
			_player_orgasm_climax.play()
			
			if debug_log_audio:
				print("[Audio] Orgasm climax!")
	
	# POST-ORGASM PANT - plays after orgasm ends
	if _was_orgasming and not is_orgasming:
		# Orgasm just ended
		if orgasm_post_pant:
			_player_orgasm_pant.stream = orgasm_post_pant
			_player_orgasm_pant.volume_db = linear_to_db(orgasm_pant_volume * master_volume)
			_player_orgasm_pant.play()
			
			if debug_log_audio:
				print("[Audio] Post-orgasm panting")
	
	_was_orgasming = is_orgasming


# ============================================================
# REFRACTORY AUDIO
# ============================================================

func _update_refractory_audio(delta: float) -> void:
	var in_refractory: bool = controller.is_in_refractory()
	
	if in_refractory and refractory_breath:
		var target_vol: float = refractory_volume * master_volume
		
		# Fade in refractory breathing
		if not _player_refractory.playing:
			_player_refractory.stream = refractory_breath
			_player_refractory.play()
		
		_current_vol_toward(_player_refractory, target_vol, delta * 2.0)
	else:
		# Fade out
		if _player_refractory.playing:
			_current_vol_toward(_player_refractory, 0.0, delta * 3.0)
	
	_was_in_refractory = in_refractory


# ============================================================
# AUDIO UTILITIES
# ============================================================

func _fade_player(player: AudioStreamPlayer, target_linear: float, speed: float) -> void:
	if not player:
		return
	var current_db: float = player.volume_db
	var current_linear: float = db_to_linear(current_db) if current_db > -80.0 else 0.0
	var new_linear: float = lerpf(current_linear, target_linear, speed * get_process_delta_time())
	new_linear = clampf(new_linear, 0.0, 1.0)
	player.volume_db = linear_to_db(maxf(new_linear, 0.001)) if new_linear > 0.001 else -80.0


func _current_vol_toward(player: AudioStreamPlayer, target_linear: float, delta: float) -> void:
	_fade_player(player, target_linear, 1.0 / maxf(delta, 0.001))


# ============================================================
# PUBLIC API
# ============================================================

## Set master volume (0.0 to 1.0)
func set_master_volume(vol: float) -> void:
	master_volume = clampf(vol, 0.0, 1.0)

## Stop all audio immediately
func stop_all() -> void:
	for child in get_children():
		if child is AudioStreamPlayer:
			child.stop()
	_current_breathing_state = -1
	_milestones_triggered.clear()
	_was_orgasming = false
	_was_in_refractory = false
	_buildup_played_this_orgasm = false

## Get which breathing level is currently active
func get_breathing_state() -> String:
	match _current_breathing_state:
		0: return "light"
		1: return "medium"
		2: return "heavy"
		_: return "none"

## Add a milestone entry at runtime
func add_milestone(threshold: float, audio: AudioStream, one_shot: bool = true) -> void:
	var entry: MilestoneEntry = MilestoneEntry.new()
	entry.arousal_threshold = threshold
	entry.audio = audio
	entry.one_shot = one_shot
	milestone_sounds.append(entry)

## Add milestone from external audio stream (convenience)
func setup_default_milestones() -> void:
	milestone_sounds.clear()
	# Milestones will be set up manually or from profile
