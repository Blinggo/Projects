class_name WetStainDecal
extends Decal

# ============================================================
# WET STAIN DECAL - PHASE 4D-Sweat
# A wet stain on a surface that fades over time.
# ============================================================

@export var fade_duration: float = 15.0
@export var initial_size: Vector3 = Vector3(0.08, 0.08, 0.08)
@export var stain_texture: Texture2D

var _age: float = 0.0


func _ready() -> void:
	if stain_texture:
		texture_albedo = stain_texture
	
	size = initial_size
	modulate = Color(0.7, 0.85, 1.0, 0.8)  # Bluish wet color
	
	# Decal projects downward by default; make sure normal mode works on common surfaces
	cull_mask = 0xFFFFF


func _process(delta: float) -> void:
	_age += delta
	var t = _age / fade_duration
	
	if t >= 1.0:
		SweatGlobal.unregister_stain(self)
		queue_free()
		return
	
	# Fade alpha
	modulate.a = (1.0 - t) * 0.8
