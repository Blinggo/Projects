class_name SweatSurfaceController
extends Node

# ============================================================
# SWEAT SURFACE CONTROLLER - PHASE 4D-Sweat
# Attach to any mesh to give it realistic surface droplets.
# REUSABLE - works on any MeshInstance3D.
# ============================================================

# --- TARGET ---
@export_group("Target")
## The mesh to apply sweat to. If null, tries to find a sibling MeshInstance3D.
@export var target_mesh: MeshInstance3D
## The sweat shader resource
@export var sweat_shader: Shader
## Surface index on the mesh to apply to (usually 0)
@export var surface_index: int = 0

# --- TEXTURE FORWARDING ---
@export_group("Base Material Forwarding")
## Auto-extract textures from existing material on _ready
@export var auto_extract_base_textures: bool = true
@export var base_albedo_override: Texture2D
@export var base_normal_override: Texture2D

# --- HEAT BUILDUP ---
@export_group("Heat Buildup")
## Source value that drives heat (0-1). For vagina: arousal level.
## Set this manually each frame from outside, or use auto_drive_from_controller
@export_range(0.0, 1.0, 0.01) var heat_input: float = 0.0
## Auto-pull heat_input from a VaginaController's arousal
@export var auto_drive_from_vagina: VaginaController
## Heat input must be above this for buildup to occur
@export_range(0.0, 1.0, 0.05) var heat_buildup_threshold: float = 0.6
## Seconds of sustained heat input above threshold before first droplets appear
## (gets divided by SweatGlobal.get_buildup_multiplier())
@export_range(5.0, 600.0, 5.0) var buildup_seconds: float = 120.0
## How fast heat dissipates when input drops (per second)
@export_range(0.01, 1.0, 0.01) var heat_dissipation_rate: float = 0.1

# --- DROPLET BEHAVIOR ---
@export_group("Droplet Behavior")
## Local override of max droplets. -1 = use SweatGlobal setting.
@export_range(-1, 128, 1) var max_droplets_override: int = -1
## Spawn rate per second when heat is at maximum
@export_range(0.1, 10.0, 0.1) var spawn_rate_at_max_heat: float = 1.5
## Initial size of new droplets (in UV space, 0-1)
@export_range(0.001, 0.05, 0.001) var initial_droplet_size: float = 0.008
## Maximum size a droplet can grow to before becoming unstable
@export_range(0.005, 0.1, 0.001) var max_droplet_size: float = 0.025
## How fast droplets grow when adjacent droplets merge
@export_range(0.0, 0.5, 0.01) var merge_growth_rate: float = 0.1
## Distance threshold for droplet merging (in UV space)
@export_range(0.001, 0.05, 0.001) var merge_distance: float = 0.012
## Droplets above this size start sliding down
@export_range(0.005, 0.05, 0.001) var slide_size_threshold: float = 0.015
## Slide speed in UV per second at max size
@export_range(0.001, 0.5, 0.001) var slide_speed: float = 0.03
## Lifetime in seconds before droplet starts drying
@export_range(5.0, 120.0, 1.0) var droplet_lifetime: float = 30.0
## Drying duration in seconds
@export_range(1.0, 30.0, 0.5) var drying_duration: float = 8.0

# --- DETACHMENT ---
@export_group("Detachment")
## Enable droplets to detach and become 3D physics objects
@export var enable_detachment: bool = true
## Droplet detachment script (assign DetachedDroplet3D.gd scene if you have one)
@export var detached_droplet_scene: PackedScene
## UV Y-coordinate beyond which droplets detach (assumes V increases downward)
@export_range(0.0, 1.0, 0.01) var detachment_uv_threshold: float = 0.95

# --- WIPE INTERACTION ---
@export_group("Wipe Interaction")
@export var enable_wipe: bool = true
## Radius of wipe effect in UV space
@export_range(0.01, 0.2, 0.01) var wipe_radius: float = 0.06
## How many droplets cleared per touch frame
@export_range(1, 20, 1) var wipe_strength: int = 4

# --- AIRFLOW ---
@export_group("Airflow")
@export var receives_airflow: bool = true

# --- DEBUG ---
@export_group("Debug")
@export var debug_log: bool = false
@export var show_droplet_count_label: bool = false

# --- INTERNAL ---
class Droplet:
	var uv: Vector2
	var size: float
	var age: float        # Time since spawning
	var life: float       # Visual life: 0..1..0 (fade in, hold, fade out)
	var sliding: bool
	var trail_uv: Vector2  # Where the trail starts

var _droplets: Array[Droplet] = []
var _shader_material: ShaderMaterial
var _heat_buildup: float = 0.0    # Accumulated time of high heat
var _current_heat: float = 0.0    # Current heat level 0-1
var _spawn_accumulator: float = 0.0
var _is_active: bool = false

# Wipe tracking
var _wipe_last_position: Vector2 = Vector2.ZERO
var _wipe_active: bool = false

# Airflow tracking
var _current_airflow: Vector3 = Vector3.ZERO
var _current_airflow_strength: float = 0.0
var _current_airflow_dry_boost: float = 1.0


# ============================================================
# LIFECYCLE
# ============================================================

func _ready() -> void:
	# Auto-find target mesh if not assigned
	if not target_mesh:
		_auto_find_target()
	
	if not target_mesh:
		push_error("[SweatSurfaceController] No target_mesh assigned and none found nearby!")
		return
	
	if not sweat_shader:
		push_error("[SweatSurfaceController] No sweat_shader assigned!")
		return
	
	_setup_shader_material()
	_is_active = true
	
	if debug_log:
		print("[SweatSurfaceController] Initialized on mesh: ", target_mesh.name)


func _process(delta: float) -> void:
	if not _is_active or not _shader_material:
		return
	
	# Skip if disabled globally
	if not SweatGlobal.uses_shader_system():
		_clear_all_droplets()
		_update_shader_uniforms()
		return
	
	# Pull heat from vagina controller if assigned
	if auto_drive_from_vagina:
		heat_input = auto_drive_from_vagina.get_arousal()
	
	_update_heat(delta)
	_update_spawning(delta)
	_update_droplets(delta)
	_handle_merging()
	_update_shader_uniforms()


func _input(event: InputEvent) -> void:
	if not enable_wipe:
		return
	
	# Mouse / touch input for wipe
	if event is InputEventMouseMotion:
		var mm = event as InputEventMouseMotion
		if mm.button_mask & MOUSE_BUTTON_MASK_LEFT:
			_try_wipe_at_screen_position(mm.position)
	
	if event is InputEventScreenDrag:
		var sd = event as InputEventScreenDrag
		_try_wipe_at_screen_position(sd.position)


# ============================================================
# SETUP
# ============================================================

func _auto_find_target() -> void:
	# Try sibling
	var parent = get_parent()
	if parent:
		for child in parent.get_children():
			if child is MeshInstance3D:
				target_mesh = child
				return
	# Try own children
	for child in get_children():
		if child is MeshInstance3D:
			target_mesh = child
			return


func _setup_shader_material() -> void:
	_shader_material = ShaderMaterial.new()
	_shader_material.shader = sweat_shader
	
	# Extract base textures from existing material
	var albedo: Texture2D = base_albedo_override
	var normal: Texture2D = base_normal_override
	
	if auto_extract_base_textures:
		var existing = target_mesh.get_active_material(surface_index)
		if existing is StandardMaterial3D:
			var sm = existing as StandardMaterial3D
			if not albedo and sm.albedo_texture:
				albedo = sm.albedo_texture
			if not normal and sm.normal_texture:
				normal = sm.normal_texture
		elif existing is ShaderMaterial:
			# If existing material is a ShaderMaterial (like our wetness shader),
			# try to pull from its uniforms
			var shader_mat = existing as ShaderMaterial
			var existing_albedo = shader_mat.get_shader_parameter("albedo_texture")
			var existing_normal = shader_mat.get_shader_parameter("normal_texture")
			if not albedo and existing_albedo:
				albedo = existing_albedo
			if not normal and existing_normal:
				normal = existing_normal
	
	if albedo:
		_shader_material.set_shader_parameter("base_albedo", albedo)
		_shader_material.set_shader_parameter("use_base_albedo", true)
	else:
		_shader_material.set_shader_parameter("use_base_albedo", false)
	
	if normal:
		_shader_material.set_shader_parameter("base_normal", normal)
		_shader_material.set_shader_parameter("use_base_normal", true)
	else:
		_shader_material.set_shader_parameter("use_base_normal", false)
	
	# Apply the material
	target_mesh.set_surface_override_material(surface_index, _shader_material)
	
	if debug_log:
		print("[SweatSurfaceController] Shader material applied. Albedo: ", albedo != null, " Normal: ", normal != null)


# ============================================================
# HEAT BUILDUP
# ============================================================

func _update_heat(delta: float) -> void:
	var buildup_mult = SweatGlobal.get_buildup_multiplier()
	
	if heat_input >= heat_buildup_threshold:
		_heat_buildup += delta * buildup_mult
	else:
		_heat_buildup -= delta * heat_dissipation_rate * buildup_mult
	
	_heat_buildup = clampf(_heat_buildup, 0.0, buildup_seconds * 1.5)
	
	# Current heat 0-1 based on buildup vs threshold time
	_current_heat = clampf(_heat_buildup / buildup_seconds, 0.0, 1.0)


# ============================================================
# DROPLET SPAWNING
# ============================================================

func _update_spawning(delta: float) -> void:
	if _current_heat <= 0.05:
		return
	
	var max_droplets = max_droplets_override
	if max_droplets < 0:
		max_droplets = SweatGlobal.get_max_droplets()
	
	if _droplets.size() >= max_droplets:
		return
	
	# Spawn rate scales with heat
	var rate = spawn_rate_at_max_heat * _current_heat
	_spawn_accumulator += rate * delta
	
	while _spawn_accumulator >= 1.0 and _droplets.size() < max_droplets:
		_spawn_accumulator -= 1.0
		_spawn_droplet()


func _spawn_droplet() -> void:
	var d = Droplet.new()
	# Random UV position (you could mask this with a spawn density texture later)
	d.uv = Vector2(randf(), randf() * 0.7)  # Spawn in upper 70% so they can slide down
	d.size = initial_droplet_size * randf_range(0.7, 1.3)
	d.age = 0.0
	d.life = 0.0
	d.sliding = false
	d.trail_uv = d.uv
	_droplets.append(d)
	
	if debug_log:
		print("[Sweat] Spawned droplet at UV: ", d.uv, " (total: ", _droplets.size(), ")")


# ============================================================
# DROPLET UPDATE (slide, dry, detach)
# ============================================================

func _update_droplets(delta: float) -> void:
	var dry_mult = _current_airflow_dry_boost
	
	# Iterate backwards so we can remove safely
	for i in range(_droplets.size() - 1, -1, -1):
		var d: Droplet = _droplets[i]
		d.age += delta
		
		# Life curve: fade in over 0.5s, hold until droplet_lifetime, fade out over drying_duration
		if d.age < 0.5:
			d.life = d.age / 0.5
		elif d.age < droplet_lifetime:
			d.life = 1.0
		elif d.age < droplet_lifetime + drying_duration:
			var dry_t = (d.age - droplet_lifetime) / drying_duration * dry_mult
			d.life = clampf(1.0 - dry_t, 0.0, 1.0)
		else:
			# Fully dried
			_droplets.remove_at(i)
			continue
		
		# Sliding
		if d.size > slide_size_threshold:
			d.sliding = true
			# Slide direction: down in UV space (assumes V increases downward on model)
			# Add airflow influence
			var slide_amount = slide_speed * (d.size / max_droplet_size) * delta
			d.uv.y += slide_amount
			
			# Airflow can push droplets sideways
			if receives_airflow and _current_airflow_strength > 0.0:
				# Convert world airflow to UV space (simplified - just use X component)
				d.uv.x += _current_airflow.x * _current_airflow_strength * delta * 0.1
		
		# Detachment check
		if enable_detachment and d.uv.y >= detachment_uv_threshold:
			_detach_droplet(d)
			_droplets.remove_at(i)
			continue
		
		# UV bounds clamp
		d.uv.x = clampf(d.uv.x, 0.0, 1.0)
		d.uv.y = clampf(d.uv.y, 0.0, 1.0)


# ============================================================
# DROPLET MERGING
# ============================================================

func _handle_merging() -> void:
	# Compare each pair (O(n²) but n <= 64 so it's fine)
	for i in range(_droplets.size() - 1, -1, -1):
		if i >= _droplets.size():
			continue
		var a: Droplet = _droplets[i]
		
		for j in range(i - 1, -1, -1):
			if j >= _droplets.size():
				continue
			var b: Droplet = _droplets[j]
			
			var dist = a.uv.distance_to(b.uv)
			if dist < merge_distance:
				# Merge: a absorbs b
				var combined_size = sqrt(a.size * a.size + b.size * b.size)
				a.size = min(combined_size, max_droplet_size)
				a.uv = (a.uv + b.uv) * 0.5
				# Average ages (keeps merged droplets from being too "young")
				a.age = (a.age + b.age) * 0.5
				_droplets.remove_at(j)
				
				if debug_log:
					print("[Sweat] Merged droplets, new size: ", a.size)
				break


# ============================================================
# DETACHMENT (drip off)
# ============================================================

func _detach_droplet(droplet: Droplet) -> void:
	if not detached_droplet_scene:
		return
	
	var detached = detached_droplet_scene.instantiate()
	if not detached:
		return
	
	# Spawn at world position below the mesh
	get_tree().current_scene.add_child(detached)
	
	# Try to position near the bottom of the mesh
	if target_mesh:
		var mesh_aabb = target_mesh.get_aabb()
		var bottom_offset = Vector3(
			(droplet.uv.x - 0.5) * mesh_aabb.size.x,
			mesh_aabb.position.y,
			0
		)
		detached.global_position = target_mesh.global_position + bottom_offset
	
	if detached.has_method("set_initial_size"):
		detached.set_initial_size(droplet.size)
	
	if debug_log:
		print("[Sweat] Droplet detached from UV: ", droplet.uv)


# ============================================================
# WIPE INTERACTION
# ============================================================

func _try_wipe_at_screen_position(screen_pos: Vector2) -> void:
	var camera = get_viewport().get_camera_3d()
	if not camera or not target_mesh:
		return
	
	# Raycast from screen position
	var from = camera.project_ray_origin(screen_pos)
	var to = from + camera.project_ray_normal(screen_pos) * 1000.0
	
	var space_state = target_mesh.get_world_3d().direct_space_state
	var query = PhysicsRayQueryParameters3D.create(from, to)
	var result = space_state.intersect_ray(query)
	
	if result and result.collider == _get_mesh_collider():
		# Get UV at hit point (requires the mesh to have proper UVs)
		var uv_hit = _world_to_uv(result.position)
		if uv_hit != Vector2.INF:
			_wipe_at_uv(uv_hit)


func _get_mesh_collider() -> Object:
	# Try to find a StaticBody3D or CollisionObject3D sibling
	var parent = target_mesh.get_parent()
	if parent:
		for child in parent.get_children():
			if child is CollisionObject3D:
				return child
	return null


func _world_to_uv(world_pos: Vector3) -> Vector2:
	# Simplified: approximate UV by mesh AABB
	# For more accuracy, you'd need to query the actual hit triangle
	if not target_mesh:
		return Vector2.INF
	
	var local_pos = target_mesh.to_local(world_pos)
	var aabb = target_mesh.get_aabb()
	var u = (local_pos.x - aabb.position.x) / aabb.size.x
	var v = 1.0 - (local_pos.y - aabb.position.y) / aabb.size.y  # Invert V
	return Vector2(clampf(u, 0.0, 1.0), clampf(v, 0.0, 1.0))


func _wipe_at_uv(uv: Vector2) -> void:
	var wiped_count = 0
	for i in range(_droplets.size() - 1, -1, -1):
		if wiped_count >= wipe_strength:
			break
		var d: Droplet = _droplets[i]
		if d.uv.distance_to(uv) < wipe_radius:
			_droplets.remove_at(i)
			wiped_count += 1
	
	if wiped_count > 0 and debug_log:
		print("[Sweat] Wiped ", wiped_count, " droplets at UV: ", uv)


# ============================================================
# AIRFLOW (called by AirflowZone3D)
# ============================================================

func apply_airflow(direction: Vector3, strength: float, dry_boost: float) -> void:
	if not receives_airflow:
		return
	_current_airflow = direction
	_current_airflow_strength = strength
	_current_airflow_dry_boost = dry_boost


func clear_airflow() -> void:
	_current_airflow = Vector3.ZERO
	_current_airflow_strength = 0.0
	_current_airflow_dry_boost = 1.0


# ============================================================
# SHADER UPLOAD
# ============================================================

func _update_shader_uniforms() -> void:
	if not _shader_material:
		return
	
	# Pack droplets into Vector4 array
	var packed: Array = []
	packed.resize(64)
	
	for i in range(64):
		if i < _droplets.size():
			var d: Droplet = _droplets[i]
			packed[i] = Vector4(d.uv.x, d.uv.y, d.size, d.life)
		else:
			packed[i] = Vector4.ZERO
	
	_shader_material.set_shader_parameter("droplets", packed)
	_shader_material.set_shader_parameter("active_droplet_count", _droplets.size())
	_shader_material.set_shader_parameter("heat_level", _current_heat)


func _clear_all_droplets() -> void:
	_droplets.clear()


# ============================================================
# PUBLIC API
# ============================================================

## Force trigger sweat at any heat level
func force_heat(value: float) -> void:
	_heat_buildup = value * buildup_seconds

## Get current droplet count
func get_droplet_count() -> int:
	return _droplets.size()

## Get current heat level 0-1
func get_heat_level() -> float:
	return _current_heat

## Clear all droplets immediately
func clear_sweat() -> void:
	_clear_all_droplets()
	_heat_buildup = 0.0
	_current_heat = 0.0

## Manually spawn a droplet at a UV position (for testing)
func spawn_droplet_at(uv: Vector2, size: float = -1.0) -> void:
	var d = Droplet.new()
	d.uv = uv
	d.size = size if size > 0.0 else initial_droplet_size
	d.age = 0.0
	d.life = 0.0
	d.sliding = false
	d.trail_uv = uv
	_droplets.append(d)
