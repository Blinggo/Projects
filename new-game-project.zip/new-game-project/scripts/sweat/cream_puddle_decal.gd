class_name CreamPuddleDecal
extends Decal

# ============================================================
# CREAM PUDDLE DECAL - PHASE 4D-Cream
# A creamy puddle on a surface that grows when more cream lands,
# then slowly dries over a long time.
# ============================================================

## Initial size of the puddle (will grow if more cream lands nearby)
@export var initial_size: Vector3 = Vector3(0.06, 0.06, 0.06)
## Maximum size the puddle can grow to
@export var max_size: Vector3 = Vector3(0.25, 0.25, 0.25)
## Total drying duration in seconds
@export var dry_duration: float = 60.0
## Texture for the puddle (reuse wet stain texture or use custom cream texture)
@export var puddle_texture: Texture2D
## Cream color
@export var cream_color: Color = Color(0.96, 0.94, 0.88, 0.95)
## How much each absorbed droplet grows the puddle
@export_range(0.001, 0.05, 0.001) var growth_per_absorption: float = 0.015

var _age: float = 0.0
var _current_size_multiplier: float = 1.0


func _ready() -> void:
	if puddle_texture:
		texture_albedo = puddle_texture
	
	size = initial_size
	modulate = cream_color
	
	# Cream is opaque and shiny
	albedo_mix = 1.0
	cull_mask = 0xFFFFF
	
	# Slight emission for the wet glossy look
	emission_energy = 0.05


func _process(delta: float) -> void:
	_age += delta
	
	var t = _age / dry_duration
	if t >= 1.0:
		SweatGlobal.unregister_cream_puddle(self)
		queue_free()
		return
	
	# Slow alpha fade over the drying period
	var alpha = clampf(1.0 - pow(t, 2.0), 0.0, 1.0)  # Quadratic falloff (stays opaque longer)
	modulate.a = cream_color.a * alpha


## Called when a new cream particle lands near this puddle (within merge distance)
func absorb_cream() -> void:
	_current_size_multiplier += growth_per_absorption
	var new_size = initial_size * _current_size_multiplier
	# Clamp to max
	new_size.x = minf(new_size.x, max_size.x)
	new_size.y = minf(new_size.y, max_size.y)
	new_size.z = minf(new_size.z, max_size.z)
	size = new_size
	
	# Slightly reset drying age (cream stays wet longer when more is added)
	_age = maxf(_age - 5.0, 0.0)
