class_name AirflowZone3D
extends Area3D

# ============================================================
# AIRFLOW ZONE - PHASE 4D-Sweat
# Place these in your scene as fans, open windows, etc.
# Any SweatSurfaceController inside will dry faster + droplets push in wind direction.
# ============================================================

@export var wind_direction: Vector3 = Vector3(1, 0, 0)
@export_range(0.0, 5.0, 0.1) var wind_strength: float = 1.0
## Multiplier on droplet drying speed (higher = dries faster)
@export_range(1.0, 10.0, 0.1) var dry_boost: float = 3.0

var _controllers_inside: Array[SweatSurfaceController] = []


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)
	area_entered.connect(_on_area_entered)
	area_exited.connect(_on_area_exited)


func _process(_delta: float) -> void:
	for ctrl in _controllers_inside:
		if is_instance_valid(ctrl):
			ctrl.apply_airflow(wind_direction.normalized(), wind_strength, dry_boost)


func _on_body_entered(body: Node) -> void:
	_check_for_controller(body)


func _on_body_exited(body: Node) -> void:
	_remove_controller_for(body)


func _on_area_entered(area: Node) -> void:
	_check_for_controller(area)


func _on_area_exited(area: Node) -> void:
	_remove_controller_for(area)


func _check_for_controller(node: Node) -> void:
	# Search the node and its parent for SweatSurfaceController
	var found = _find_controller_for_node(node)
	if found and not _controllers_inside.has(found):
		_controllers_inside.append(found)


func _remove_controller_for(node: Node) -> void:
	var found = _find_controller_for_node(node)
	if found:
		_controllers_inside.erase(found)
		found.clear_airflow()


func _find_controller_for_node(node: Node) -> SweatSurfaceController:
	# Check parent chain for a SweatSurfaceController sibling
	var search_node = node
	while search_node:
		var parent = search_node.get_parent()
		if parent:
			for child in parent.get_children():
				if child is SweatSurfaceController:
					return child
		search_node = parent
	return null