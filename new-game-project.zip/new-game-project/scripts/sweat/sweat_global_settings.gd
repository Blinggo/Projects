extends Node

# ============================================================
# SWEAT GLOBAL SETTINGS - AUTOLOAD
# Project-wide performance settings for the sweat system.
# Individual SweatSurfaceController nodes can override these.
# ============================================================

enum QualityPreset {
	OFF,           # No sweat at all
	LOW,           # Old particle-based system only
	MEDIUM,        # Shader system with reduced droplets (32)
	HIGH,          # Shader system with full droplets (64)
	ULTRA,         # Shader system with maximum droplets (128)
}

## Current quality level - change this to affect all sweat in the project
var quality: QualityPreset = QualityPreset.HIGH

## Multiplier on all heat buildup times (1.0 = realistic, lower = faster)
var time_scale: float = 1.0

## Fast buildup mode for testing (1 minute -> a few seconds)
var debug_fast_buildup: bool = false

## Master enable for wet stain decals on other surfaces
var enable_wet_stains: bool = true

## Maximum total wet stain decals across the whole project (mobile limit)
var max_stains_global: int = 30

## Tracking active stains for global limit enforcement
var _active_stains: Array = []


func get_max_droplets() -> int:
	match quality:
		QualityPreset.OFF: return 0
		QualityPreset.LOW: return 0  # Uses particle system instead
		QualityPreset.MEDIUM: return 32
		QualityPreset.HIGH: return 64
		QualityPreset.ULTRA: return 128
	return 64


func uses_shader_system() -> bool:
	return quality >= QualityPreset.MEDIUM


func uses_particle_system() -> bool:
	return quality == QualityPreset.LOW


func get_buildup_multiplier() -> float:
	if debug_fast_buildup:
		return 10.0  # 10x faster buildup for testing
	return 1.0 / time_scale


# --- Stain limit management ---
func register_stain(stain: Node) -> bool:
	if not enable_wet_stains:
		return false
	if _active_stains.size() >= max_stains_global:
		# Remove oldest stain
		var oldest = _active_stains.pop_front()
		if is_instance_valid(oldest):
			oldest.queue_free()
	_active_stains.append(stain)
	return true


func unregister_stain(stain: Node) -> void:
	_active_stains.erase(stain)
	
# --- ORGASM SPRAY SYSTEM ---
enum SprayQuality {
	OFF,           # No spray
	SIMPLE,        # Old GPU particle burst only
	REALISTIC,     # New water spray system
	BOTH,          # Both systems active (most dramatic)
}

## Which spray system to use globally
var spray_quality: SprayQuality = SprayQuality.REALISTIC

## Multiplier on total spray particle count (mobile scaling)
var spray_count_multiplier: float = 1.0


func uses_realistic_spray() -> bool:
	return spray_quality == SprayQuality.REALISTIC or spray_quality == SprayQuality.BOTH


func uses_simple_spray() -> bool:
	return spray_quality == SprayQuality.SIMPLE or spray_quality == SprayQuality.BOTH
	
# --- CREAM SYSTEM ---
enum CreamQuality {
	OFF,
	LOW,        # Reduced particle count
	NORMAL,     # Full particle count
	HIGH,       # Extra particles + longer-lasting puddles
}

## Cream visual quality
var cream_quality: CreamQuality = CreamQuality.NORMAL

## Master multiplier for cream particle count
var cream_count_multiplier: float = 1.0

## Maximum cream puddles allowed across the scene (mobile limit)
var max_cream_puddles: int = 20

var _active_cream_puddles: Array = []


func cream_enabled() -> bool:
	return cream_quality != CreamQuality.OFF


func get_cream_count_multiplier() -> float:
	match cream_quality:
		CreamQuality.OFF: return 0.0
		CreamQuality.LOW: return 0.5
		CreamQuality.NORMAL: return 1.0
		CreamQuality.HIGH: return 1.5
	return 1.0


# --- Cream puddle limit management ---
func register_cream_puddle(puddle: Node) -> bool:
	if not cream_enabled():
		return false
	if _active_cream_puddles.size() >= max_cream_puddles:
		var oldest = _active_cream_puddles.pop_front()
		if is_instance_valid(oldest):
			oldest.queue_free()
	_active_cream_puddles.append(puddle)
	return true


func unregister_cream_puddle(puddle: Node) -> void:
	_active_cream_puddles.erase(puddle)
	