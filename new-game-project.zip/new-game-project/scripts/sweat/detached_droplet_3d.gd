class_name DetachedDroplet3D
extends RigidBody3D

# ============================================================
# DETACHED DROPLET - PHASE 4D-Sweat
# A physics droplet that fell off a mesh.
# On impact with a marked surface, spawns a WetStainDecal.
# ============================================================

@export var stain_decal_scene: PackedScene
## Time before auto-removing if it never hits anything
@export var max_lifetime: float = 5.0
## Initial mesh size
@export var droplet_visual_size: float = 0.008

var _lifetime: float = 0.0
var _has_landed: bool = false


func _ready() -> void:
	# Configure physics
	gravity_scale = 1.0
	mass = 0.001  # Very light
	
	# Create visual sphere
	var mesh_inst = MeshInstance3D.new()
	var sphere = SphereMesh.new()
	sphere.radius = droplet_visual_size
	sphere.height = droplet_visual_size * 2.0
	sphere.radial_segments = 6
	sphere.rings = 4
	
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.85, 0.92, 1.0, 0.8)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.metallic = 0.3
	mat.roughness = 0.05
	sphere.material = mat
	
	mesh_inst.mesh = sphere
	add_child(mesh_inst)
	
	# Create tiny collider
	var col_shape = CollisionShape3D.new()
	var sphere_shape = SphereShape3D.new()
	sphere_shape.radius = droplet_visual_size
	col_shape.shape = sphere_shape
	add_child(col_shape)
	
	# Connect body entered for impact
	contact_monitor = true
	max_contacts_reported = 4
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_lifetime += delta
	if _lifetime >= max_lifetime:
		queue_free()


func set_initial_size(size: float) -> void:
	droplet_visual_size = size * 30.0  # Scale UV size to world size


func _on_body_entered(body: Node) -> void:
	if _has_landed:
		return
	
	# Check if body is a stain receiver
	if body.is_in_group("stain_receiver"):
		_has_landed = true
		_spawn_stain_at_impact(body)
		queue_free()
	else:
		# Just disappears on any other collision
		_has_landed = true
		queue_free()


func _spawn_stain_at_impact(body: Node) -> void:
	if not stain_decal_scene:
		return
	
	var stain = stain_decal_scene.instantiate()
	if not stain:
		return
	
	get_tree().current_scene.add_child(stain)
	stain.global_position = global_position + Vector3(0, 0.001, 0)  # Tiny offset to avoid z-fight
	
	# Register with global limit
	SweatGlobal.register_stain(stain)
