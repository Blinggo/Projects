@tool
class_name RigAnalyzer extends Node

@export var skeleton: Skeleton3D
@export var penis_mesh: MeshInstance3D

func _ready() -> void:
	if not skeleton:
		push_error("Assign the Skeleton3D")
		return
		
	print("\n=== BONE HIERARCHY ===")
	for i in skeleton.get_bone_count():
		var bone_name = skeleton.get_bone_name(i)
		var parent_idx = skeleton.get_bone_parent(i)
		var parent_name = skeleton.get_bone_name(parent_idx) if parent_idx != -1 else "ROOT"
		var depth = _get_bone_depth(skeleton, i)
		var indent = "    ".repeat(depth)
		print("%s%s (ID: %d) ← Parent: %s" % [indent, bone_name, i, parent_name])
	
	print("\n=== BLEND SHAPES (Morphs) ===")
	if penis_mesh and penis_mesh.mesh:
		var mesh = penis_mesh.mesh
		if mesh is ArrayMesh:
			for i in mesh.get_blend_shape_count():
				print("BlendShape %d: %s" % [i, mesh.get_blend_shape_name(i)])
		else:
			print("Not an ArrayMesh - can't read blend shapes easily")
	else:
		print("No mesh assigned or not ArrayMesh")


func _get_bone_depth(skel: Skeleton3D, bone_idx: int) -> int:
	var depth = 0
	var current = bone_idx
	while skel.get_bone_parent(current) != -1:
		depth += 1
		current = skel.get_bone_parent(current)
	return depth
