extends Control

@export var skeleton: Skeleton3D

var bone_names: Array[String] = []
var current_bone_index: int = 0
var current_axis: int = 0 # 0=X, 1=Y, 2=Z
var current_mode: int = 0 # 0=Rotation, 1=Scale

var rotation_value: float = 0.0
var scale_value: float = 1.0

var bone_label: Label
var axis_label: Label
var mode_label: Label
var value_label: Label
var info_label: Label
var rotation_slider: HSlider
var scale_slider: HSlider
var active_slider_container_rot: HBoxContainer
var active_slider_container_scl: HBoxContainer

var _stored_rotations: Dictionary = {}
var _stored_scales: Dictionary = {}


func _ready() -> void:
	if not skeleton:
		push_error("AxisTestUI: Assign the Skeleton3D node.")
		return

	for i in skeleton.get_bone_count():
		bone_names.append(skeleton.get_bone_name(i))

	for i in skeleton.get_bone_count():
		_stored_rotations[i] = skeleton.get_bone_pose_rotation(i)
		_stored_scales[i] = skeleton.get_bone_pose_scale(i)

	_build_ui()
	_update_display()


func _build_ui() -> void:
	var panel: PanelContainer = PanelContainer.new()
	panel.anchors_preset = Control.PRESET_BOTTOM_WIDE
	panel.anchor_top = 0.55
	panel.anchor_bottom = 1.0
	panel.anchor_left = 0.0
	panel.anchor_right = 1.0
	panel.offset_top = 0
	panel.offset_bottom = 0
	panel.offset_left = 0
	panel.offset_right = 0
	add_child(panel)

	var margin: MarginContainer = MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	panel.add_child(margin)

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)

	# Title
	var title: Label = Label.new()
	title.text = "AXIS DISCOVERY TOOL"
	title.add_theme_font_size_override("font_size", 18)
	vbox.add_child(title)

	vbox.add_child(HSeparator.new())

	# Bone navigation
	var bone_nav_label: Label = Label.new()
	bone_nav_label.text = "BONE SELECTION:"
	bone_nav_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(bone_nav_label)

	bone_label = Label.new()
	bone_label.text = "Bone: ---"
	bone_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(bone_label)

	var bone_nav: HBoxContainer = HBoxContainer.new()
	vbox.add_child(bone_nav)

	var btn_prev_bone: Button = Button.new()
	btn_prev_bone.text = "< Prev Bone"
	btn_prev_bone.custom_minimum_size = Vector2(0, 50)
	btn_prev_bone.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_prev_bone.pressed.connect(_prev_bone)
	bone_nav.add_child(btn_prev_bone)

	var btn_next_bone: Button = Button.new()
	btn_next_bone.text = "Next Bone >"
	btn_next_bone.custom_minimum_size = Vector2(0, 50)
	btn_next_bone.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_next_bone.pressed.connect(_next_bone)
	bone_nav.add_child(btn_next_bone)

	vbox.add_child(HSeparator.new())

	# Quick jump buttons for important bones
	var jump_label: Label = Label.new()
	jump_label.text = "QUICK JUMP:"
	jump_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(jump_label)

	var jump_row1: HBoxContainer = HBoxContainer.new()
	vbox.add_child(jump_row1)

	var quick_bones: Array[String] = [
		"penis_root", "penis swing", "DEF.Shaft",
	]
	for qb in quick_bones:
		var btn: Button = Button.new()
		btn.text = qb
		btn.custom_minimum_size = Vector2(0, 40)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.add_theme_font_size_override("font_size", 11)
		btn.pressed.connect(_jump_to_bone.bind(qb))
		jump_row1.add_child(btn)

	var jump_row2: HBoxContainer = HBoxContainer.new()
	vbox.add_child(jump_row2)

	var quick_bones2: Array[String] = [
		"DEF.Shaft.001", "DEF.Shaft.002", "DEF.Shaft.003",
	]
	for qb in quick_bones2:
		var btn: Button = Button.new()
		btn.text = qb
		btn.custom_minimum_size = Vector2(0, 40)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.add_theme_font_size_override("font_size", 11)
		btn.pressed.connect(_jump_to_bone.bind(qb))
		jump_row2.add_child(btn)

	var jump_row3: HBoxContainer = HBoxContainer.new()
	vbox.add_child(jump_row3)

	var quick_bones3: Array[String] = [
		"DEF.balls.L", "DEF.balls.R", "CTRL.foreskin",
	]
	for qb in quick_bones3:
		var btn: Button = Button.new()
		btn.text = qb
		btn.custom_minimum_size = Vector2(0, 40)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.add_theme_font_size_override("font_size", 11)
		btn.pressed.connect(_jump_to_bone.bind(qb))
		jump_row3.add_child(btn)

	vbox.add_child(HSeparator.new())

	# Axis selection
	axis_label = Label.new()
	axis_label.text = "Axis: X"
	axis_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(axis_label)

	var axis_nav: HBoxContainer = HBoxContainer.new()
	vbox.add_child(axis_nav)

	var btn_x: Button = Button.new()
	btn_x.text = "X Axis"
	btn_x.custom_minimum_size = Vector2(0, 50)
	btn_x.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_x.pressed.connect(_set_axis.bind(0))
	axis_nav.add_child(btn_x)

	var btn_y: Button = Button.new()
	btn_y.text = "Y Axis"
	btn_y.custom_minimum_size = Vector2(0, 50)
	btn_y.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_y.pressed.connect(_set_axis.bind(1))
	axis_nav.add_child(btn_y)

	var btn_z: Button = Button.new()
	btn_z.text = "Z Axis"
	btn_z.custom_minimum_size = Vector2(0, 50)
	btn_z.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_z.pressed.connect(_set_axis.bind(2))
	axis_nav.add_child(btn_z)

	vbox.add_child(HSeparator.new())

	# Mode selection
	mode_label = Label.new()
	mode_label.text = "Mode: ROTATION"
	mode_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(mode_label)

	var mode_nav: HBoxContainer = HBoxContainer.new()
	vbox.add_child(mode_nav)

	var btn_rot: Button = Button.new()
	btn_rot.text = "Rotation Mode"
	btn_rot.custom_minimum_size = Vector2(0, 50)
	btn_rot.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_rot.pressed.connect(_set_mode.bind(0))
	mode_nav.add_child(btn_rot)

	var btn_scl: Button = Button.new()
	btn_scl.text = "Scale Mode"
	btn_scl.custom_minimum_size = Vector2(0, 50)
	btn_scl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_scl.pressed.connect(_set_mode.bind(1))
	mode_nav.add_child(btn_scl)

	vbox.add_child(HSeparator.new())

	# Rotation slider
	var rot_label: Label = Label.new()
	rot_label.text = "ROTATION (degrees):"
	rot_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(rot_label)

	active_slider_container_rot = HBoxContainer.new()
	vbox.add_child(active_slider_container_rot)

	rotation_slider = HSlider.new()
	rotation_slider.min_value = -180.0
	rotation_slider.max_value = 180.0
	rotation_slider.step = 1.0
	rotation_slider.value = 0.0
	rotation_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rotation_slider.custom_minimum_size = Vector2(200, 40)
	rotation_slider.value_changed.connect(_on_rotation_changed)
	active_slider_container_rot.add_child(rotation_slider)

	vbox.add_child(HSeparator.new())

	# Scale slider
	var scl_label: Label = Label.new()
	scl_label.text = "SCALE:"
	scl_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(scl_label)

	active_slider_container_scl = HBoxContainer.new()
	vbox.add_child(active_slider_container_scl)

	scale_slider = HSlider.new()
	scale_slider.min_value = 0.1
	scale_slider.max_value = 3.0
	scale_slider.step = 0.01
	scale_slider.value = 1.0
	scale_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scale_slider.custom_minimum_size = Vector2(200, 40)
	scale_slider.value_changed.connect(_on_scale_changed)
	active_slider_container_scl.add_child(scale_slider)

	vbox.add_child(HSeparator.new())

	# Value display
	value_label = Label.new()
	value_label.text = "Value: 0"
	value_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(value_label)

	vbox.add_child(HSeparator.new())

	# Info display
	info_label = Label.new()
	info_label.text = ""
	info_label.add_theme_font_size_override("font_size", 12)
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(info_label)

	vbox.add_child(HSeparator.new())

	# Reset button
	var btn_reset: Button = Button.new()
	btn_reset.text = "RESET ALL BONES TO REST"
	btn_reset.custom_minimum_size = Vector2(0, 50)
	btn_reset.pressed.connect(_reset_all)
	vbox.add_child(btn_reset)

	# Reset current bone button
	var btn_reset_current: Button = Button.new()
	btn_reset_current.text = "RESET CURRENT BONE"
	btn_reset_current.custom_minimum_size = Vector2(0, 50)
	btn_reset_current.pressed.connect(_reset_current_bone)
	vbox.add_child(btn_reset_current)

	vbox.add_child(HSeparator.new())

	# Print report button
	var btn_report: Button = Button.new()
	btn_report.text = "PRINT AXIS REPORT TO CONSOLE"
	btn_report.custom_minimum_size = Vector2(0, 50)
	btn_report.pressed.connect(_print_axis_report)
	vbox.add_child(btn_report)


func _prev_bone() -> void:
	current_bone_index = wrapi(current_bone_index - 1, 0, bone_names.size())
	_reset_sliders()
	_update_display()


func _next_bone() -> void:
	current_bone_index = wrapi(current_bone_index + 1, 0, bone_names.size())
	_reset_sliders()
	_update_display()


func _jump_to_bone(bone_name: String) -> void:
	var idx: int = skeleton.find_bone(bone_name)
	if idx != -1:
		current_bone_index = idx
		_reset_sliders()
		_update_display()
	else:
		info_label.text = "Bone '%s' not found!" % bone_name


func _set_axis(axis: int) -> void:
	current_axis = axis
	_reset_sliders()
	_update_display()


func _set_mode(mode: int) -> void:
	current_mode = mode
	_reset_sliders()
	_update_display()


func _reset_sliders() -> void:
	rotation_slider.set_value_no_signal(0.0)
	scale_slider.set_value_no_signal(1.0)
	rotation_value = 0.0
	scale_value = 1.0

	var bone_idx: int = current_bone_index
	if _stored_rotations.has(bone_idx):
		skeleton.set_bone_pose_rotation(bone_idx, _stored_rotations[bone_idx])
	if _stored_scales.has(bone_idx):
		skeleton.set_bone_pose_scale(bone_idx, _stored_scales[bone_idx])


func _on_rotation_changed(value: float) -> void:
	rotation_value = value
	_apply_transform()
	_update_display()


func _on_scale_changed(value: float) -> void:
	scale_value = value
	_apply_transform()
	_update_display()


func _apply_transform() -> void:
	var bone_idx: int = current_bone_index
	if bone_idx < 0 or bone_idx >= skeleton.get_bone_count():
		return

	if current_mode == 0:
		# Rotation mode
		var rot_vec: Vector3 = Vector3.ZERO
		match current_axis:
			0: rot_vec.x = deg_to_rad(rotation_value)
			1: rot_vec.y = deg_to_rad(rotation_value)
			2: rot_vec.z = deg_to_rad(rotation_value)

		var base_rot: Quaternion = _stored_rotations.get(bone_idx, Quaternion.IDENTITY)
		var additional_rot: Quaternion = Quaternion.from_euler(rot_vec)
		skeleton.set_bone_pose_rotation(bone_idx, base_rot * additional_rot)

	elif current_mode == 1:
		# Scale mode
		var scl_vec: Vector3 = _stored_scales.get(bone_idx, Vector3.ONE)
		match current_axis:
			0: scl_vec.x = scale_value
			1: scl_vec.y = scale_value
			2: scl_vec.z = scale_value
		skeleton.set_bone_pose_scale(bone_idx, scl_vec)


func _reset_all() -> void:
	for i in skeleton.get_bone_count():
		if _stored_rotations.has(i):
			skeleton.set_bone_pose_rotation(i, _stored_rotations[i])
		if _stored_scales.has(i):
			skeleton.set_bone_pose_scale(i, _stored_scales[i])
	_reset_sliders()
	_update_display()
	info_label.text = "All bones reset to rest pose."


func _reset_current_bone() -> void:
	var bone_idx: int = current_bone_index
	if _stored_rotations.has(bone_idx):
		skeleton.set_bone_pose_rotation(bone_idx, _stored_rotations[bone_idx])
	if _stored_scales.has(bone_idx):
		skeleton.set_bone_pose_scale(bone_idx, _stored_scales[bone_idx])
	_reset_sliders()
	_update_display()
	info_label.text = "Bone '%s' reset." % bone_names[current_bone_index]


func _update_display() -> void:
	var bone_name: String = bone_names[current_bone_index] if current_bone_index < bone_names.size() else "NONE"
	var axis_name: String = ["X", "Y", "Z"][current_axis]
	var mode_name: String = ["ROTATION", "SCALE"][current_mode]

	bone_label.text = "Bone: %s (ID: %d / %d)" % [bone_name, current_bone_index, bone_names.size() - 1]
	axis_label.text = "Axis: %s" % axis_name
	mode_label.text = "Mode: %s" % mode_name

	if current_mode == 0:
		value_label.text = "Rotation: %.1f degrees on %s axis" % [rotation_value, axis_name]
	else:
		value_label.text = "Scale: %.2f on %s axis" % [scale_value, axis_name]

	var parent_idx: int = skeleton.get_bone_parent(current_bone_index)
	var parent_name: String = skeleton.get_bone_name(parent_idx) if parent_idx != -1 else "NONE (root)"
	var child_count: int = 0
	var children_names: String = ""
	for i in skeleton.get_bone_count():
		if skeleton.get_bone_parent(i) == current_bone_index:
			child_count += 1
			children_names += skeleton.get_bone_name(i) + ", "

	var current_rot: Quaternion = skeleton.get_bone_pose_rotation(current_bone_index)
	var current_euler: Vector3 = current_rot.get_euler()
	var current_scl: Vector3 = skeleton.get_bone_pose_scale(current_bone_index)

	info_label.text = "Parent: %s\nChildren (%d): %s\nCurrent Euler: (%.2f, %.2f, %.2f)\nCurrent Scale: (%.2f, %.2f, %.2f)" % [
		parent_name,
		child_count,
		children_names.rstrip(", ") if children_names != "" else "none",
		rad_to_deg(current_euler.x), rad_to_deg(current_euler.y), rad_to_deg(current_euler.z),
		current_scl.x, current_scl.y, current_scl.z
	]


func _print_axis_report() -> void:
	print("\n========================================")
	print("   AXIS DISCOVERY REPORT")
	print("========================================")
	print("Instructions: For each bone below, use")
	print("the tool to rotate on X, Y, Z and note")
	print("which axis causes which movement.")
	print("========================================")

	var test_bones: Array[String] = [
		"penis_root",
		"penis swing",
		"DEF.Shaft",
		"DEF.Shaft.001",
		"DEF.Shaft.002",
		"DEF.Shaft.003",
		"DEF.Shaft.004",
		"DEF.Shaft.005",
		"DEF.Shaft.006",
		"DEF.balls.L",
		"DEF.balls.R",
		"CTRL.foreskin",
		"CTRL.shaft_skin",
	]

	for bone_name in test_bones:
		var idx: int = skeleton.find_bone(bone_name)
		if idx == -1:
			print("\n%s: NOT FOUND" % bone_name)
			continue

		var rest_rot: Quaternion = _stored_rotations.get(idx, Quaternion.IDENTITY)
		var rest_euler: Vector3 = rest_rot.get_euler()
		var rest_scl: Vector3 = _stored_scales.get(idx, Vector3.ONE)

		print("\n--- %s (ID: %d) ---" % [bone_name, idx])
		print("  Rest Rotation (euler deg): (%.2f, %.2f, %.2f)" % [
			rad_to_deg(rest_euler.x), rad_to_deg(rest_euler.y), rad_to_deg(rest_euler.z)
		])
		print("  Rest Scale: (%.2f, %.2f, %.2f)" % [rest_scl.x, rest_scl.y, rest_scl.z])
		print("  X rotation = ?  (fill in: up/down, left/right, twist)")
		print("  Y rotation = ?  (fill in: up/down, left/right, twist)")
		print("  Z rotation = ?  (fill in: up/down, left/right, twist)")
		print("  X scale = ?     (fill in: girth, length, width)")
		print("  Y scale = ?     (fill in: girth, length, width)")
		print("  Z scale = ?     (fill in: girth, length, width)")

	print("\n========================================")
	print("Fill in the ?s above by testing each")
	print("bone with the sliders, then paste the")
	print("filled report back.")
	print("========================================\n")
