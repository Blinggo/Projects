class_name PenisConfig
extends Resource

@export_group("Bone Names")
@export var root_bone_name: String = "penis_root"
@export var swing_bone_name: String = "penis swing"
@export var shaft_bone_prefix: String = "DEF.Shaft"
@export var shaft_bone_count: int = 7
@export var ball_left_bone_name: String = "DEF.balls.L"
@export var ball_right_bone_name: String = "DEF.balls.R"
@export var foreskin_bone_name: String = "CTRL.foreskin"
@export var shaft_skin_bone_name: String = "CTRL.shaft_skin"

@export_group("Erection - Rotation")
## The X rotation in degrees applied to shaft bones when fully flaccid.
## Negative = droops down. The rest pose (0) is erect.
@export var flaccid_droop_degrees: float = -80.0
## How the droop distributes across the shaft chain.
## Higher = more droop concentrated at the base.
@export var droop_curve_power: float = 1.5
## When semi-erect, the tip may still droop slightly.
## This controls how much of the droop remains at the tip vs base.
@export var tip_droop_bias: float = 0.3

@export_group("Erection - Scale")
## Y scale of DEF.Shaft when fully flaccid (shrunken)
@export var flaccid_shaft_y_scale: float = 0.7
## Y scale of DEF.Shaft when fully erect (full size)
@export var erect_shaft_y_scale: float = 1.0
## X and Z scale for girth when flaccid
@export var flaccid_girth_scale: float = 0.85
## X and Z scale for girth when erect
@export var erect_girth_scale: float = 1.0

@export_group("Erection - Transition")
@export var erection_speed: float = 0.5
@export var default_erection_level: float = 0.0

@export_group("Balls")
## Y scale when balls are tightened (aroused/cold). Lower = tighter.
@export var balls_tight_y_scale: float = 0.7
## Y scale when balls hang loose (flaccid/warm). Higher = more hang.
@export var balls_hang_y_scale: float = 1.2
## How much ball tightness follows erection level (0-1).
## 1.0 = balls fully follow erection. 0.0 = balls independent.
@export var balls_erection_follow: float = 0.8

@export_group("Shaft Per-Bone Scale")
## Individual shaft bones (001-006) can have subtle Y scale changes
## to simulate blood engorgement along the length.
@export var per_bone_length_scale_flaccid: float = 0.95
@export var per_bone_length_scale_erect: float = 1.0
## Girth variation along shaft (thicker at base, thinner at tip)
@export var base_girth_bonus: float = 0.05
@export var tip_girth_reduction: float = 0.02

@export_group("Jiggle Physics")
@export var jiggle_stiffness: float = 15.0
@export var jiggle_damping: float = 0.5
@export var jiggle_stiffness_erect_multiplier: float = 10.0
@export var jiggle_damping_erect: float = 0.1
@export var jiggle_movement_influence: float = 50.0
@export var jiggle_max_displacement: float = 0.5

@export_group("Ball Physics")
@export var ball_stiffness: float = 8.0
@export var ball_damping: float = 0.4
@export var ball_gravity_influence: float = 0.03
@export var ball_movement_influence: float = 30.0
@export var ball_max_displacement: float = 0.3


func get_shaft_bone_name(index: int) -> String:
	if index == 0:
		return shaft_bone_prefix
	return "%s.%03d" % [shaft_bone_prefix, index]