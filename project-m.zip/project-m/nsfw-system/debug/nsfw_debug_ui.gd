class_name NSFWDebugUI
extends Control

@export var penis_controller: PenisController

var status_label: Label
var erection_slider: HSlider
var erection_value_label: Label
var erection_state_label: Label
var speed_slider: HSlider
var speed_value_label: Label
var mode_button: Button
var info_label: Label
var _direct_mode: bool = true


func _ready() -> void:
	_build_ui()

	if not penis_controller:
		status_label.text = "ERROR: No PenisController assigned"
		return

	if penis_controller.is_node_ready():
		_on_controller_ready()
	else:
		penis_controller.ready.connect(_on_controller_ready)


func _build_ui() -> void:
	# Main panel anchored to bottom of screen
	var panel: PanelContainer = PanelContainer.new()
	panel.anchor_top = 0.6
	panel.anchor_bottom = 1.0
	panel.anchor_left = 0.0
	panel.anchor_right = 1.0
	panel.offset_top = 0
	panel.offset_bottom = 0
	panel.offset_left = 0
	panel.offset_right = 0
	add_child(panel)

	var margin: MarginContainer = MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 6)
	margin.add_theme_constant_override("margin_bottom", 6)
	panel.add_child(margin)

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)

	var vbox: VBoxContainer = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(vbox)

	# Title
	var title: Label = Label.new()
	title.text = "Phase 2 - Erection System"
	title.add_theme_font_size_override("font_size", 16)
	vbox.add_child(title)

	# Status
	status_label = Label.new()
	status_label.text = "Waiting..."
	status_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(status_label)

	vbox.add_child(HSeparator.new())

	# State display
	erection_state_label = Label.new()
	erection_state_label.text = "State: Flaccid"
	erection_state_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(erection_state_label)

	# Erection slider row
	var slider_row: HBoxContainer = HBoxContainer.new()
	vbox.add_child(slider_row)

	var elabel: Label = Label.new()
	elabel.text = "Erection:"
	elabel.add_theme_font_size_override("font_size", 14)
	slider_row.add_child(elabel)

	erection_slider = HSlider.new()
	erection_slider.min_value = 0.0
	erection_slider.max_value = 1.0
	erection_slider.step = 0.01
	erection_slider.value = 0.0
	erection_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	erection_slider.custom_minimum_size = Vector2(150, 40)
	erection_slider.value_changed.connect(_on_erection_slider_changed)
	slider_row.add_child(erection_slider)

	erection_value_label = Label.new()
	erection_value_label.text = "0%"
	erection_value_label.custom_minimum_size = Vector2(50, 0)
	erection_value_label.add_theme_font_size_override("font_size", 14)
	slider_row.add_child(erection_value_label)

	# Speed slider row
	var speed_row: HBoxContainer = HBoxContainer.new()
	vbox.add_child(speed_row)

	var slabel: Label = Label.new()
	slabel.text = "Speed:"
	slabel.add_theme_font_size_override("font_size", 14)
	speed_row.add_child(slabel)

	speed_slider = HSlider.new()
	speed_slider.min_value = 0.05
	speed_slider.max_value = 3.0
	speed_slider.step = 0.05
	speed_slider.value = 0.5
	speed_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	speed_slider.custom_minimum_size = Vector2(150, 40)
	speed_slider.value_changed.connect(_on_speed_slider_changed)
	speed_row.add_child(speed_slider)

	speed_value_label = Label.new()
	speed_value_label.text = "0.50"
	speed_value_label.custom_minimum_size = Vector2(50, 0)
	speed_value_label.add_theme_font_size_override("font_size", 14)
	speed_row.add_child(speed_value_label)

	vbox.add_child(HSeparator.new())

	# Mode toggle
	mode_button = Button.new()
	mode_button.text = "Mode: Direct"
	mode_button.custom_minimum_size = Vector2(0, 40)
	mode_button.add_theme_font_size_override("font_size", 14)
	mode_button.pressed.connect(_on_mode_toggled)
	vbox.add_child(mode_button)

	# Preset buttons
	var preset_row: HBoxContainer = HBoxContainer.new()
	vbox.add_child(preset_row)

	var btn_flaccid: Button = Button.new()
	btn_flaccid.text = "Flaccid"
	btn_flaccid.custom_minimum_size = Vector2(0, 44)
	btn_flaccid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_flaccid.pressed.connect(_on_preset.bind(0.0))
	preset_row.add_child(btn_flaccid)

	var btn_quarter: Button = Button.new()
	btn_quarter.text = "25%"
	btn_quarter.custom_minimum_size = Vector2(0, 44)
	btn_quarter.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_quarter.pressed.connect(_on_preset.bind(0.25))
	preset_row.add_child(btn_quarter)

	var btn_semi: Button = Button.new()
	btn_semi.text = "Semi"
	btn_semi.custom_minimum_size = Vector2(0, 44)
	btn_semi.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_semi.pressed.connect(_on_preset.bind(0.5))
	preset_row.add_child(btn_semi)

	var btn_three_quarter: Button = Button.new()
	btn_three_quarter.text = "75%"
	btn_three_quarter.custom_minimum_size = Vector2(0, 44)
	btn_three_quarter.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_three_quarter.pressed.connect(_on_preset.bind(0.75))
	preset_row.add_child(btn_three_quarter)

	var btn_hard: Button = Button.new()
	btn_hard.text = "Hard"
	btn_hard.custom_minimum_size = Vector2(0, 44)
	btn_hard.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btn_hard.pressed.connect(_on_preset.bind(1.0))
	preset_row.add_child(btn_hard)

	vbox.add_child(HSeparator.new())

	# Info label for showing current values
	info_label = Label.new()
	info_label.text = ""
	info_label.add_theme_font_size_override("font_size", 11)
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(info_label)


func _on_controller_ready() -> void:
	if penis_controller.is_valid:
		status_label.text = "RIG VALID - Ready"
		penis_controller.erection_level_changed.connect(_on_erection_level_updated)
		penis_controller.erection_state_changed.connect(_on_erection_state_updated)
	else:
		status_label.text = "RIG INVALID - Check console"


func _process(_delta: float) -> void:
	if not penis_controller or not penis_controller.is_valid:
		return
	if not penis_controller.erection_manager:
		return

	var level: float = penis_controller.erection_manager.current_level
	erection_value_label.text = "%d%%" % int(level * 100.0)

	if not _direct_mode:
		erection_slider.set_value_no_signal(level)

	# Update info with live bone data
	_update_info_label(level)


func _update_info_label(level: float) -> void:
	var cfg: PenisConfig = penis_controller.config
	var inverted: float = 1.0 - level
	var droop: float = cfg.flaccid_droop_degrees * inverted
	var y_scale: float = lerpf(cfg.flaccid_shaft_y_scale, cfg.erect_shaft_y_scale, level)
	var girth: float = lerpf(cfg.flaccid_girth_scale, cfg.erect_girth_scale, level)
	var ball_y: float = lerpf(cfg.balls_hang_y_scale, cfg.balls_tight_y_scale, level * cfg.balls_erection_follow)

	info_label.text = "Droop: %.1f° | Shaft Y: %.2f | Girth: %.2f | Balls Y: %.2f" % [droop, y_scale, girth, ball_y]


func _on_erection_slider_changed(value: float) -> void:
	if not penis_controller or not penis_controller.is_valid:
		return

	if _direct_mode:
		penis_controller.set_erection_immediate(value)
	else:
		penis_controller.set_erection_target(value)

	erection_value_label.text = "%d%%" % int(value * 100.0)


func _on_speed_slider_changed(value: float) -> void:
	if not penis_controller or not penis_controller.is_valid:
		return

	penis_controller.set_erection_speed(value)
	speed_value_label.text = "%.2f" % value


func _on_mode_toggled() -> void:
	_direct_mode = not _direct_mode
	if _direct_mode:
		mode_button.text = "Mode: Direct"
	else:
		mode_button.text = "Mode: Animated"


func _on_preset(level: float) -> void:
	erection_slider.value = level
	_on_erection_slider_changed(level)


func _on_erection_level_updated(level: float) -> void:
	erection_value_label.text = "%d%%" % int(level * 100.0)


func _on_erection_state_updated(state: String) -> void:
	erection_state_label.text = "State: %s" % state
