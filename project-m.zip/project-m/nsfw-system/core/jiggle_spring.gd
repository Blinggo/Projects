class_name JiggleSpring
extends RefCounted

var displacement: Vector3 = Vector3.ZERO
var velocity: Vector3 = Vector3.ZERO
var stiffness: float = 15.0
var damping: float = 0.5
var max_displacement: float = 0.5


func _init(p_stiffness: float = 15.0, p_damping: float = 0.5, p_max: float = 0.5) -> void:
	stiffness = p_stiffness
	damping = p_damping
	max_displacement = p_max


func update(delta: float, external_force: Vector3 = Vector3.ZERO) -> Vector3:
	if delta <= 0.0:
		return displacement

	var spring_force: Vector3 = (-stiffness * displacement) - (damping * velocity)
	spring_force += external_force

	velocity += spring_force * delta
	displacement += velocity * delta

	displacement.x = clampf(displacement.x, -max_displacement, max_displacement)
	displacement.y = clampf(displacement.y, -max_displacement, max_displacement)
	displacement.z = clampf(displacement.z, -max_displacement, max_displacement)

	return displacement


func reset() -> void:
	displacement = Vector3.ZERO
	velocity = Vector3.ZERO


func set_parameters(p_stiffness: float, p_damping: float, p_max: float) -> void:
	stiffness = p_stiffness
	damping = p_damping
	max_displacement = p_max


func get_rotation_from_displacement() -> Quaternion:
	return Quaternion.from_euler(Vector3(displacement.y, displacement.x, displacement.z))