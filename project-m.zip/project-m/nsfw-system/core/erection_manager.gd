class_name ErectionManager
extends RefCounted

signal erection_changed(level: float)
signal erection_state_changed(state: String)

enum ErectionState {
	FLACCID,
	GETTING_HARD,
	SEMI,
	GETTING_FULLY_HARD,
	HARD,
	GETTING_SOFT,
}

var current_level: float = 0.0
var target_level: float = 0.0
var transition_speed: float = 0.5
var current_state: ErectionState = ErectionState.FLACCID
var _previous_state: ErectionState = ErectionState.FLACCID


func _init(p_speed: float = 0.5, p_default: float = 0.0) -> void:
	transition_speed = p_speed
	current_level = p_default
	target_level = p_default
	_update_state()


func update(delta: float) -> float:
	if delta <= 0.0:
		return current_level

	if not is_equal_approx(current_level, target_level):
		var direction: float = sign(target_level - current_level)
		current_level += direction * transition_speed * delta
		current_level = clampf(current_level, 0.0, 1.0)

		if absf(current_level - target_level) < 0.001:
			current_level = target_level

		_update_state()
		erection_changed.emit(current_level)

	return current_level


func set_target(level: float) -> void:
	target_level = clampf(level, 0.0, 1.0)
	_update_state()


func set_immediate(level: float) -> void:
	current_level = clampf(level, 0.0, 1.0)
	target_level = current_level
	_update_state()
	erection_changed.emit(current_level)


func set_speed(speed: float) -> void:
	transition_speed = maxf(speed, 0.01)


func _update_state() -> void:
	_previous_state = current_state

	if current_level < 0.05:
		current_state = ErectionState.FLACCID
	elif current_level > 0.95:
		current_state = ErectionState.HARD
	elif current_level >= 0.4 and current_level <= 0.6:
		if target_level > current_level:
			current_state = ErectionState.GETTING_FULLY_HARD
		elif target_level < current_level:
			current_state = ErectionState.GETTING_SOFT
		else:
			current_state = ErectionState.SEMI
	elif target_level > current_level:
		if current_level < 0.4:
			current_state = ErectionState.GETTING_HARD
		else:
			current_state = ErectionState.GETTING_FULLY_HARD
	elif target_level < current_level:
		current_state = ErectionState.GETTING_SOFT
	else:
		current_state = ErectionState.SEMI

	if current_state != _previous_state:
		erection_state_changed.emit(get_state_name())


func get_state_name() -> String:
	match current_state:
		ErectionState.FLACCID:
			return "Flaccid"
		ErectionState.GETTING_HARD:
			return "Getting Hard"
		ErectionState.SEMI:
			return "Semi"
		ErectionState.GETTING_FULLY_HARD:
			return "Getting Fully Hard"
		ErectionState.HARD:
			return "Hard"
		ErectionState.GETTING_SOFT:
			return "Getting Soft"
	return "Unknown"


func is_transitioning() -> bool:
	return not is_equal_approx(current_level, target_level)