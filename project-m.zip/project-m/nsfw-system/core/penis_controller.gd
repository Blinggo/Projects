class_name PenisController
extends Node

signal rig_validated(success: bool, message: String)
signal bone_map_complete(bone_map: Dictionary)
signal erection_level_changed(level: float)
signal erection_state_changed(state: String)

@export var skeleton: Skeleton3D
@export var config: PenisConfig

var bone_map: Dictionary = {}
var is_valid: bool = false
var validation_errors: Array[String] = []

var erection_manager: ErectionManager

# Stored rest poses so we always work relative to the original
var _rest_rotations: Dictionary = {}
var _rest_scales: Dictionary = {}


func _ready() -> void:
	if not skeleton:
		push_error("PenisController: No Skeleton3D assigned.")
		return
	if not config:
		push_error("PenisController: No PenisConfig assigned.")
		return

	_map_bones()
	_validate_rig()

	if is_valid:
		_store_rest_poses()
		_initialize_erection_manager()
		# Apply initial state
		_apply_erection_to_bones()


func _process(delta: float) -> void:
	if not is_valid:
		return

	erection_manager.update(delta)
	_apply_erection_to_bones()


# === BONE MAPPING ===

func _map_bones() -> void:
	bone_map.clear()

	bone_map["root"] = skeleton.find_bone(config.root_bone_name)
	bone_map["swing"] = skeleton.find_bone(config.swing_bone_name)
	bone_map["ball_l"] = skeleton.find_bone(config.ball_left_bone_name)
	bone_map["ball_r"] = skeleton.find_bone(config.ball_right_bone_name)
	bone_map["foreskin"] = skeleton.find_bone(config.foreskin_bone_name)
	bone_map["shaft_skin"] = skeleton.find_bone(config.shaft_skin_bone_name)

	bone_map["shaft_bones"] = []
	for i in range(config.shaft_bone_count):
		var bone_name: String = config.get_shaft_bone_name(i)
		var bone_idx: int = skeleton.find_bone(bone_name)
		bone_map["shaft_bones"].append({"name": bone_name, "index": bone_idx})

	bone_map_complete.emit(bone_map)


# === REST POSE STORAGE ===

func _store_rest_poses() -> void:
	# Store rest rotation and scale for every bone we will manipulate
	var all_bone_indices: Array[int] = []

	# Root and swing
	var root_idx: int = bone_map.get("root", -1)
	if root_idx != -1:
		all_bone_indices.append(root_idx)

	var swing_idx: int = bone_map.get("swing", -1)
	if swing_idx != -1:
		all_bone_indices.append(swing_idx)

	# Shaft chain
	var shaft_bones_array: Array = bone_map.get("shaft_bones", [])
	for entry in shaft_bones_array:
		if entry["index"] != -1:
			all_bone_indices.append(entry["index"])

	# Balls
	var ball_l: int = bone_map.get("ball_l", -1)
	if ball_l != -1:
		all_bone_indices.append(ball_l)

	var ball_r: int = bone_map.get("ball_r", -1)
	if ball_r != -1:
		all_bone_indices.append(ball_r)

	# Foreskin
	var foreskin: int = bone_map.get("foreskin", -1)
	if foreskin != -1:
		all_bone_indices.append(foreskin)

	for idx in all_bone_indices:
		_rest_rotations[idx] = skeleton.get_bone_pose_rotation(idx)
		_rest_scales[idx] = skeleton.get_bone_pose_scale(idx)


# === ERECTION SYSTEM ===

func _initialize_erection_manager() -> void:
	erection_manager = ErectionManager.new(config.erection_speed, config.default_erection_level)
	erection_manager.erection_changed.connect(_on_erection_changed)
	erection_manager.erection_state_changed.connect(_on_erection_state_changed)


func _apply_erection_to_bones() -> void:
	var level: float = erection_manager.current_level
	_apply_shaft_droop(level)
	_apply_shaft_base_scale(level)
	_apply_shaft_per_bone_scale(level)
	_apply_balls_scale(level)


func _apply_shaft_droop(level: float) -> void:
	# level 0.0 = fully flaccid = full droop (negative X rotation)
	# level 1.0 = fully erect = no droop (rest pose, 0 rotation)
	#
	# We distribute the droop across shaft bones 1-6 (not bone 0 which is the base scale bone)
	# The droop uses a curve so it looks natural - more bend at base, gradual straightening

	var shaft_bones_array: Array = bone_map.get("shaft_bones", [])
	var chain_count: int = shaft_bones_array.size()

	if chain_count <= 1:
		return

	# Total droop angle at current erection level
	# At level 0: full flaccid_droop_degrees (e.g., -80)
	# At level 1: 0 degrees (rest pose)
	var inverted_level: float = 1.0 - level
	var total_droop_deg: float = config.flaccid_droop_degrees * inverted_level

	# We skip bone index 0 (DEF.Shaft) as that is the scale-only bone
	# Droop is applied to bones 1 through 6
	var droop_bone_count: int = chain_count - 1

	for i in range(1, chain_count):
		var entry: Dictionary = shaft_bones_array[i]
		if entry["index"] == -1:
			continue

		var bone_idx: int = entry["index"]

		# Normalized position along the droop chain (0.0 = closest to base, 1.0 = tip)
		var normalized_pos: float = float(i - 1) / float(droop_bone_count - 1) if droop_bone_count > 1 else 0.0

		# Droop weight curve:
		# Using pow() to concentrate droop. Higher power = more at base.
		# We also add tip_droop_bias so the tip still droops somewhat when semi-erect.
		var base_weight: float = pow(1.0 - normalized_pos, config.droop_curve_power)
		var tip_weight: float = normalized_pos * config.tip_droop_bias
		var combined_weight: float = base_weight + tip_weight

		# Normalize so total doesn't exceed 1
		combined_weight = clampf(combined_weight, 0.0, 1.0)

		# Each bone gets a fraction of the total droop
		var bone_droop_deg: float = (total_droop_deg / float(droop_bone_count)) * combined_weight * float(droop_bone_count) * 0.5

		# Apply as X rotation (positive = up, negative = down)
		var droop_rad: float = deg_to_rad(bone_droop_deg)

		# Combine with rest rotation
		var rest_rot: Quaternion = _rest_rotations.get(bone_idx, Quaternion.IDENTITY)
		var droop_quat: Quaternion = Quaternion.from_euler(Vector3(droop_rad, 0.0, 0.0))
		skeleton.set_bone_pose_rotation(bone_idx, rest_rot * droop_quat)


func _apply_shaft_base_scale(level: float) -> void:
	# DEF.Shaft (index 0) is the main scale bone
	# It controls overall size: Y for length, X/Z for girth
	var shaft_bones_array: Array = bone_map.get("shaft_bones", [])
	if shaft_bones_array.size() == 0:
		return

	var base_entry: Dictionary = shaft_bones_array[0]
	if base_entry["index"] == -1:
		return

	var bone_idx: int = base_entry["index"]

	var y_scale: float = lerpf(config.flaccid_shaft_y_scale, config.erect_shaft_y_scale, level)
	var girth_scale: float = lerpf(config.flaccid_girth_scale, config.erect_girth_scale, level)

	var rest_scale: Vector3 = _rest_scales.get(bone_idx, Vector3.ONE)
	var new_scale: Vector3 = Vector3(
		rest_scale.x * girth_scale,
		rest_scale.y * y_scale,
		rest_scale.z * girth_scale
	)

	skeleton.set_bone_pose_scale(bone_idx, new_scale)


func _apply_shaft_per_bone_scale(level: float) -> void:
	# Subtle per-bone scaling for bones 1-6
	# Simulates blood engorgement making it slightly thicker/longer when erect
	var shaft_bones_array: Array = bone_map.get("shaft_bones", [])

	if shaft_bones_array.size() <= 1:
		return

	var droop_bone_count: int = shaft_bones_array.size() - 1

	for i in range(1, shaft_bones_array.size()):
		var entry: Dictionary = shaft_bones_array[i]
		if entry["index"] == -1:
			continue

		var bone_idx: int = entry["index"]
		var normalized_pos: float = float(i - 1) / float(droop_bone_count - 1) if droop_bone_count > 1 else 0.0

		# Length per bone
		var y_scale: float = lerpf(config.per_bone_length_scale_flaccid, config.per_bone_length_scale_erect, level)

		# Girth varies along length: thicker at base, thinner at tip
		var girth_variation: float = lerpf(config.base_girth_bonus, -config.tip_girth_reduction, normalized_pos)
		var girth_scale: float = lerpf(config.flaccid_girth_scale, config.erect_girth_scale, level)
		girth_scale += girth_variation * level

		var rest_scale: Vector3 = _rest_scales.get(bone_idx, Vector3.ONE)
		var new_scale: Vector3 = Vector3(
			rest_scale.x * girth_scale,
			rest_scale.y * y_scale,
			rest_scale.z * girth_scale
		)

		skeleton.set_bone_pose_scale(bone_idx, new_scale)


func _apply_balls_scale(level: float) -> void:
	# Balls tighten up when erect, hang loose when flaccid
	# Y scale: tight (smaller) when erect, hanging (larger) when flaccid
	var ball_l_idx: int = bone_map.get("ball_l", -1)
	var ball_r_idx: int = bone_map.get("ball_r", -1)

	# How much the balls follow erection state
	var follow: float = config.balls_erection_follow
	var effective_level: float = level * follow

	# Erect = tight (smaller Y), Flaccid = hang (larger Y)
	var y_scale: float = lerpf(config.balls_hang_y_scale, config.balls_tight_y_scale, effective_level)

	if ball_l_idx != -1:
		var rest_scale_l: Vector3 = _rest_scales.get(ball_l_idx, Vector3.ONE)
		skeleton.set_bone_pose_scale(ball_l_idx, Vector3(rest_scale_l.x, rest_scale_l.y * y_scale, rest_scale_l.z))

	if ball_r_idx != -1:
		var rest_scale_r: Vector3 = _rest_scales.get(ball_r_idx, Vector3.ONE)
		skeleton.set_bone_pose_scale(ball_r_idx, Vector3(rest_scale_r.x, rest_scale_r.y * y_scale, rest_scale_r.z))


# === PUBLIC API ===

func set_erection_target(level: float) -> void:
	if erection_manager:
		erection_manager.set_target(level)


func set_erection_immediate(level: float) -> void:
	if erection_manager:
		erection_manager.set_immediate(level)


func set_erection_speed(speed: float) -> void:
	if erection_manager:
		erection_manager.set_speed(speed)


func get_erection_level() -> float:
	if erection_manager:
		return erection_manager.current_level
	return 0.0


func get_erection_state() -> String:
	if erection_manager:
		return erection_manager.get_state_name()
	return "Unknown"


# === SIGNAL HANDLERS ===

func _on_erection_changed(level: float) -> void:
	erection_level_changed.emit(level)


func _on_erection_state_changed(state: String) -> void:
	erection_state_changed.emit(state)


# === VALIDATION ===

func _validate_rig() -> void:
	validation_errors.clear()
	is_valid = true

	var critical_bones: Dictionary = {
		"root": bone_map.get("root", -1),
		"swing": bone_map.get("swing", -1),
		"ball_l": bone_map.get("ball_l", -1),
		"ball_r": bone_map.get("ball_r", -1),
	}

	for bone_key in critical_bones:
		if critical_bones[bone_key] == -1:
			var error_msg: String = "CRITICAL: Bone '%s' not found in skeleton." % bone_key
			validation_errors.append(error_msg)
			is_valid = false

	var shaft_bones_array: Array = bone_map.get("shaft_bones", [])
	var found_shaft_count: int = 0
	for shaft_entry in shaft_bones_array:
		if shaft_entry["index"] != -1:
			found_shaft_count += 1
		else:
			validation_errors.append("WARNING: Shaft bone '%s' not found." % shaft_entry["name"])

	if found_shaft_count == 0:
		validation_errors.append("CRITICAL: No shaft bones found at all.")
		is_valid = false

	if is_valid:
		var success_msg: String = "Rig validated successfully. Found %d/%d shaft bones." % [found_shaft_count, config.shaft_bone_count]
		print("PenisController: %s" % success_msg)
		rig_validated.emit(true, success_msg)
	else:
		for error in validation_errors:
			push_error("PenisController: %s" % error)
		rig_validated.emit(false, "Rig validation failed. See errors above.")

	_print_full_report()


func get_bone_index(key: String) -> int:
	return bone_map.get(key, -1)


func get_shaft_bone_index(shaft_index: int) -> int:
	var shaft_bones_array: Array = bone_map.get("shaft_bones", [])
	if shaft_index >= 0 and shaft_index < shaft_bones_array.size():
		return shaft_bones_array[shaft_index]["index"]
	return -1


func get_shaft_bone_count_found() -> int:
	var count: int = 0
	var shaft_bones_array: Array = bone_map.get("shaft_bones", [])
	for entry in shaft_bones_array:
		if entry["index"] != -1:
			count += 1
	return count


func _print_full_report() -> void:
	print("\n========================================")
	print("   PENIS CONTROLLER - RIG REPORT")
	print("========================================")
	print("Skeleton: %s" % (skeleton.name if skeleton else "NONE"))
	print("Config: %s" % (config.resource_path if config else "NONE"))
	print("Valid: %s" % str(is_valid))
	print("----------------------------------------")
	print("Root Bone: %s (ID: %d)" % [config.root_bone_name, bone_map.get("root", -1)])
	print("Swing Bone: %s (ID: %d)" % [config.swing_bone_name, bone_map.get("swing", -1)])
	print("Ball L: %s (ID: %d)" % [config.ball_left_bone_name, bone_map.get("ball_l", -1)])
	print("Ball R: %s (ID: %d)" % [config.ball_right_bone_name, bone_map.get("ball_r", -1)])
	print("Foreskin: %s (ID: %d)" % [config.foreskin_bone_name, bone_map.get("foreskin", -1)])
	print("Shaft Skin: %s (ID: %d)" % [config.shaft_skin_bone_name, bone_map.get("shaft_skin", -1)])
	print("----------------------------------------")
	print("Shaft Bones:")
	var shaft_bones_array: Array = bone_map.get("shaft_bones", [])
	for entry in shaft_bones_array:
		var status: String = "OK" if entry["index"] != -1 else "MISSING"
		print("  %s (ID: %d) [%s]" % [entry["name"], entry["index"], status])
	print("----------------------------------------")
	print("Erection Config:")
	print("  Flaccid droop: %.1f degrees" % config.flaccid_droop_degrees)
	print("  Shaft Y scale range: %.2f - %.2f" % [config.flaccid_shaft_y_scale, config.erect_shaft_y_scale])
	print("  Girth scale range: %.2f - %.2f" % [config.flaccid_girth_scale, config.erect_girth_scale])
	print("  Balls Y scale range: %.2f (tight) - %.2f (hang)" % [config.balls_tight_y_scale, config.balls_hang_y_scale])
	print("----------------------------------------")
	if validation_errors.size() > 0:
		print("Errors/Warnings:")
		for error in validation_errors:
			print("  ! %s" % error)
	else:
		print("No errors detected.")
	print("========================================\n")
