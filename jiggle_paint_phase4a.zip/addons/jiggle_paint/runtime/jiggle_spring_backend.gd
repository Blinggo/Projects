@tool
extends RefCounted
class_name JiggleSpringBackend

## Mobile-friendly custom spring backend.
##
## Phase 3A supports static/non-skinned MeshInstance3D nodes. It duplicates the
## source mesh into a runtime ArrayMesh, keeps per-vertex world-space simulation
## buffers, and writes weighted deformation back into the runtime mesh.
##
## The simulation is intentionally simple and stable:
## - Rest positions follow the MeshInstance3D transform.
## - Simulated positions lag/spring toward the rest positions.
## - Painted weights blend the simulated offset into the output vertices.
## - Unpainted vertices are written back to their rest positions.

const EPSILON := 0.000001

var rest_vertices: PackedVector3Array = PackedVector3Array()
var current_vertices: PackedVector3Array = PackedVector3Array()
var velocities: PackedVector3Array = PackedVector3Array()
var weights: PackedFloat32Array = PackedFloat32Array()

var _source_mesh: Mesh
var _runtime_mesh: ArrayMesh
var _configured := false
var _time := 0.0

var _surface_arrays: Array = []
var _surface_rest_vertices: Array = []
var _surface_current_world: Array = []
var _surface_velocities: Array = []
var _surface_weights: Array = []
var _surface_materials: Array = []


func is_configured() -> bool:
	return _configured


func get_runtime_mesh() -> ArrayMesh:
	return _runtime_mesh


func get_source_mesh() -> Mesh:
	return _source_mesh


func configure_from_mesh(_mesh: Mesh, _weight_map: JiggleWeightMap) -> bool:
	# Kept for API compatibility. Runtime use should call
	# configure_from_mesh_instance() so object transforms can drive inertia.
	if _mesh == null or _weight_map == null:
		clear()
		return false
	return _configure_internal(_mesh, Transform3D.IDENTITY, _weight_map)


func configure_from_mesh_instance(target: MeshInstance3D, weight_map: JiggleWeightMap) -> bool:
	if target == null or target.mesh == null or weight_map == null:
		clear()
		return false
	if not weight_map.matches_mesh(target.mesh):
		push_warning("JiggleSpringBackend: weight map does not match target mesh vertex layout.")
		clear()
		return false

	var configured_ok: bool = _configure_internal(target.mesh, target.global_transform, weight_map)
	if configured_ok:
		target.mesh = _runtime_mesh
	return configured_ok


func clear() -> void:
	_configured = false
	_time = 0.0
	_source_mesh = null
	_runtime_mesh = null
	rest_vertices = PackedVector3Array()
	current_vertices = PackedVector3Array()
	velocities = PackedVector3Array()
	weights = PackedFloat32Array()
	_surface_arrays.clear()
	_surface_rest_vertices.clear()
	_surface_current_world.clear()
	_surface_velocities.clear()
	_surface_weights.clear()
	_surface_materials.clear()


func restore_original_mesh(target: MeshInstance3D) -> void:
	if target != null and _source_mesh != null:
		target.mesh = _source_mesh
	clear()


func reset_simulation(target: MeshInstance3D) -> void:
	if not _configured or target == null:
		return
	var transform: Transform3D = target.global_transform
	for surface_index in range(_surface_rest_vertices.size()):
		var surface_rest: PackedVector3Array = _surface_rest_vertices[surface_index]
		var surface_current: PackedVector3Array = _surface_current_world[surface_index]
		var surface_velocity: PackedVector3Array = _surface_velocities[surface_index]
		for vertex_index in range(surface_rest.size()):
			surface_current[vertex_index] = transform * surface_rest[vertex_index]
			surface_velocity[vertex_index] = Vector3.ZERO
		_surface_current_world[surface_index] = surface_current
		_surface_velocities[surface_index] = surface_velocity
	_write_rest_pose_to_runtime_mesh()


func write_rest_pose(target: MeshInstance3D) -> void:
	if not _configured:
		return
	if target != null and target.mesh != _runtime_mesh:
		target.mesh = _runtime_mesh
	_write_rest_pose_to_runtime_mesh()


func simulate(delta: float, target: MeshInstance3D, settings: Dictionary) -> void:
	if not _configured or target == null:
		return
	if target.mesh != _runtime_mesh:
		target.mesh = _runtime_mesh

	var safe_delta: float = float(clamp(delta, 0.0, 0.05))
	if safe_delta <= 0.0:
		return

	var quality: int = int(settings.get("quality", 1))
	var substeps: int = _substeps_for_quality(quality)
	var step_delta: float = safe_delta / float(substeps)
	for _substep_index in range(substeps):
		_integrate(step_delta, target, settings)

	_rebuild_runtime_mesh(target.global_transform)


func _configure_internal(source_mesh: Mesh, initial_transform: Transform3D, weight_map: JiggleWeightMap) -> bool:
	clear()
	if source_mesh == null or weight_map == null:
		return false
	if not weight_map.matches_mesh(source_mesh):
		return false

	_source_mesh = source_mesh
	_runtime_mesh = ArrayMesh.new()
	_runtime_mesh.resource_name = "%s_JiggleRuntimeMesh" % source_mesh.resource_name

	var global_index := 0
	for surface_index in range(source_mesh.get_surface_count()):
		var source_arrays: Array = source_mesh.surface_get_arrays(surface_index)
		var arrays: Array = source_arrays.duplicate(true)
		var surface_rest: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var surface_current := PackedVector3Array()
		var surface_velocity := PackedVector3Array()
		var surface_weights := PackedFloat32Array()

		surface_current.resize(surface_rest.size())
		surface_velocity.resize(surface_rest.size())
		surface_weights.resize(surface_rest.size())

		for vertex_index in range(surface_rest.size()):
			surface_current[vertex_index] = initial_transform * surface_rest[vertex_index]
			surface_velocity[vertex_index] = Vector3.ZERO
			surface_weights[vertex_index] = weight_map.get_weight(global_index)
			global_index += 1

		_surface_arrays.append(arrays)
		_surface_rest_vertices.append(surface_rest)
		_surface_current_world.append(surface_current)
		_surface_velocities.append(surface_velocity)
		_surface_weights.append(surface_weights)
		_surface_materials.append(source_mesh.surface_get_material(surface_index))

		_append_surface_to_runtime_mesh(surface_index, arrays)

	_flatten_debug_buffers()
	_configured = true
	return true


func _integrate(delta: float, target: MeshInstance3D, settings: Dictionary) -> void:
	_time += delta

	var transform: Transform3D = target.global_transform
	var stiffness: float = float(max(float(settings.get("stiffness", 12.0)), 0.0))
	var damping: float = float(clamp(float(settings.get("damping", 0.65)), 0.0, 1.0))
	var gravity_influence: float = float(settings.get("gravity_influence", 1.0))
	var wind_influence: float = float(settings.get("wind_influence", 0.0))
	var weight_threshold: float = float(max(float(settings.get("weight_threshold", 0.001)), 0.0))
	var max_displacement: float = float(max(float(settings.get("max_displacement", 1.0)), 0.001))
	var wind_frequency: float = float(max(float(settings.get("wind_frequency", 1.0)), 0.01))
	var wind_direction_value: Variant = settings.get("wind_direction", Vector3.RIGHT)
	var wind_direction: Vector3 = Vector3.RIGHT
	if wind_direction_value is Vector3:
		wind_direction = wind_direction_value
	if wind_direction.length_squared() <= EPSILON:
		wind_direction = Vector3.RIGHT
	wind_direction = wind_direction.normalized()

	# Damping is authored as 0..1. Convert it into a stable per-step velocity loss.
	var damping_factor: float = float(clamp(1.0 - damping * delta * 10.0, 0.0, 1.0))
	var gravity_force: Vector3 = Vector3.DOWN * 3.0 * gravity_influence
	var wind_wave: float = 0.5 + 0.5 * sin(_time * TAU * wind_frequency)
	var wind_force: Vector3 = wind_direction * wind_influence * wind_wave * 2.0

	for surface_index in range(_surface_rest_vertices.size()):
		var surface_rest: PackedVector3Array = _surface_rest_vertices[surface_index]
		var surface_current: PackedVector3Array = _surface_current_world[surface_index]
		var surface_velocity: PackedVector3Array = _surface_velocities[surface_index]
		var surface_weights: PackedFloat32Array = _surface_weights[surface_index]

		for vertex_index in range(surface_rest.size()):
			var weight: float = surface_weights[vertex_index]
			var rest_world: Vector3 = transform * surface_rest[vertex_index]

			if weight <= weight_threshold:
				surface_current[vertex_index] = rest_world
				surface_velocity[vertex_index] = Vector3.ZERO
				continue

			var current_world: Vector3 = surface_current[vertex_index]
			var velocity: Vector3 = surface_velocity[vertex_index]
			var displacement_to_rest: Vector3 = rest_world - current_world
			var acceleration: Vector3 = displacement_to_rest * stiffness
			acceleration += (gravity_force + wind_force) * weight

			velocity += acceleration * delta
			velocity *= damping_factor
			current_world += velocity * delta

			var offset_from_rest: Vector3 = current_world - rest_world
			var offset_length: float = offset_from_rest.length()
			if offset_length > max_displacement:
				offset_from_rest = offset_from_rest.normalized() * max_displacement
				current_world = rest_world + offset_from_rest
				velocity *= 0.35

			surface_current[vertex_index] = current_world
			surface_velocity[vertex_index] = velocity

		_surface_current_world[surface_index] = surface_current
		_surface_velocities[surface_index] = surface_velocity


func _rebuild_runtime_mesh(current_transform: Transform3D) -> void:
	if _runtime_mesh == null:
		return
	_runtime_mesh.clear_surfaces()
	var inverse_transform: Transform3D = current_transform.affine_inverse()

	for surface_index in range(_surface_arrays.size()):
		var arrays: Array = _surface_arrays[surface_index]
		var surface_rest: PackedVector3Array = _surface_rest_vertices[surface_index]
		var surface_current: PackedVector3Array = _surface_current_world[surface_index]
		var surface_weights: PackedFloat32Array = _surface_weights[surface_index]
		var output_vertices := PackedVector3Array()
		output_vertices.resize(surface_rest.size())

		for vertex_index in range(surface_rest.size()):
			var weight: float = surface_weights[vertex_index]
			if weight <= 0.0:
				output_vertices[vertex_index] = surface_rest[vertex_index]
			else:
				var simulated_local: Vector3 = inverse_transform * surface_current[vertex_index]
				output_vertices[vertex_index] = surface_rest[vertex_index].lerp(simulated_local, weight)

		arrays[Mesh.ARRAY_VERTEX] = output_vertices
		_append_surface_to_runtime_mesh(surface_index, arrays)


func _write_rest_pose_to_runtime_mesh() -> void:
	if _runtime_mesh == null:
		return
	_runtime_mesh.clear_surfaces()
	for surface_index in range(_surface_arrays.size()):
		var arrays: Array = _surface_arrays[surface_index]
		var surface_rest: PackedVector3Array = _surface_rest_vertices[surface_index]
		arrays[Mesh.ARRAY_VERTEX] = surface_rest
		_append_surface_to_runtime_mesh(surface_index, arrays)


func _append_surface_to_runtime_mesh(surface_index: int, arrays: Array) -> void:
	if _runtime_mesh == null:
		return
	_runtime_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	if surface_index < _surface_materials.size():
		var material: Material = _surface_materials[surface_index]
		if material != null:
			_runtime_mesh.surface_set_material(surface_index, material)


func _substeps_for_quality(quality: int) -> int:
	match quality:
		2:
			return 2
		_:
			return 1


func _flatten_debug_buffers() -> void:
	rest_vertices = PackedVector3Array()
	current_vertices = PackedVector3Array()
	velocities = PackedVector3Array()
	weights = PackedFloat32Array()

	for surface_index in range(_surface_rest_vertices.size()):
		var surface_rest: PackedVector3Array = _surface_rest_vertices[surface_index]
		var surface_current: PackedVector3Array = _surface_current_world[surface_index]
		var surface_velocity: PackedVector3Array = _surface_velocities[surface_index]
		var surface_weights: PackedFloat32Array = _surface_weights[surface_index]
		for vertex_index in range(surface_rest.size()):
			rest_vertices.push_back(surface_rest[vertex_index])
			current_vertices.push_back(surface_current[vertex_index])
			velocities.push_back(surface_velocity[vertex_index])
			weights.push_back(surface_weights[vertex_index])
