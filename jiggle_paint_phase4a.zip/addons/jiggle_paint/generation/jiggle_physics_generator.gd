@tool
extends RefCounted
class_name JigglePhysicsGenerator

const RuntimeController := preload("res://addons/jiggle_paint/runtime/jiggle_runtime_controller.gd")


static func generate_selected_backend(target: MeshInstance3D, weight_map: JiggleWeightMap, settings: Dictionary) -> Node:
	var backend: String = String(settings.get("backend", "hybrid"))
	if backend == "softbody":
		return generate_softbody_peer(target, weight_map, settings)
	return generate_hybrid_controller(target, weight_map, settings)


static func generate_hybrid_controller(target: MeshInstance3D, weight_map: JiggleWeightMap, settings: Dictionary) -> JiggleRuntimeController:
	if target == null:
		push_error("JigglePhysicsGenerator: target MeshInstance3D is null.")
		return null
	if weight_map == null:
		push_error("JigglePhysicsGenerator: weight_map is null.")
		return null

	var controller: JiggleRuntimeController = _find_existing_controller(target)
	if controller == null:
		controller = RuntimeController.new()
		controller.name = _unique_child_name(target, "%s_JiggleRuntime" % target.name)
		controller.target_mesh_path = NodePath("..")
		target.add_child(controller)

	controller.weight_map = weight_map
	controller.backend = String(settings.get("backend", "hybrid"))
	controller.apply_settings(settings)
	var edited_root: Node = target.get_tree().edited_scene_root if target.get_tree() != null else null
	if edited_root != null:
		controller.owner = edited_root
	return controller


static func generate_softbody_peer(target: MeshInstance3D, weight_map: JiggleWeightMap, settings: Dictionary) -> SoftBody3D:
	# Phase 4A implementation.
	# Creates or updates a SoftBody3D sibling for the target mesh. Painted weights are
	# approximated through pinning: vertices at/below soft_pin_threshold are pinned,
	# vertices above the threshold are simulated by SoftBody3D/Jolt.
	if target == null or target.mesh == null:
		push_error("JigglePhysicsGenerator: target MeshInstance3D is missing a mesh.")
		return null
	if weight_map == null:
		push_error("JigglePhysicsGenerator: weight_map is null.")
		return null
	if not weight_map.matches_mesh(target.mesh):
		push_error("JigglePhysicsGenerator: weight map does not match selected mesh.")
		return null

	var parent: Node = target.get_parent()
	if parent == null:
		push_error("JigglePhysicsGenerator: target must have a parent to create a SoftBody3D peer.")
		return null

	var soft_body: SoftBody3D = _find_existing_softbody_peer(target)
	var was_created: bool = false
	if soft_body == null:
		soft_body = SoftBody3D.new()
		soft_body.name = _unique_child_name(parent, "%s_SoftBody3D" % target.name)
		parent.add_child(soft_body)
		was_created = true

	soft_body.transform = target.transform
	soft_body.visible = true
	soft_body.mesh = _copy_mesh_as_array_mesh(target.mesh)
	soft_body.set_meta("jiggle_paint_source_path", target.get_path())
	soft_body.set_meta("jiggle_paint_weight_map_path", weight_map.resource_path)

	_apply_softbody_settings(soft_body, settings)
	_apply_softbody_pins(soft_body, weight_map, settings)

	var hide_original: bool = bool(settings.get("soft_hide_original", true))
	if hide_original:
		target.visible = false

	var edited_root: Node = target.get_tree().edited_scene_root if target.get_tree() != null else null
	if edited_root != null:
		soft_body.owner = edited_root
		if was_created:
			# Keep generated mesh visible/savable in the scene file.
			soft_body.owner = edited_root
	return soft_body


static func _apply_softbody_settings(soft_body: SoftBody3D, settings: Dictionary) -> void:
	var quality: int = int(settings.get("quality", 1))
	var stiffness: float = float(clamp(float(settings.get("stiffness", 12.0)) / 100.0, 0.0, 1.0))
	var damping: float = float(clamp(float(settings.get("damping", 0.65)), 0.0, 1.0))
	var drag: float = float(clamp(damping * 0.35, 0.0, 1.0))

	_try_set_property(soft_body, "simulation_precision", _quality_to_precision(quality))
	_try_set_property(soft_body, "linear_stiffness", stiffness)
	_try_set_property(soft_body, "damping_coefficient", damping)
	_try_set_property(soft_body, "drag_coefficient", drag)
	_try_set_property(soft_body, "total_mass", 1.0)


static func _apply_softbody_pins(soft_body: SoftBody3D, weight_map: JiggleWeightMap, settings: Dictionary) -> void:
	if soft_body == null or weight_map == null:
		return
	if not soft_body.has_method("set_point_pinned"):
		push_warning("SoftBody3D does not expose set_point_pinned() in this Godot build. Pins were skipped.")
		return

	var threshold: float = float(clamp(float(settings.get("soft_pin_threshold", 0.05)), 0.0, 1.0))
	for point_index in range(weight_map.weights.size()):
		var should_pin: bool = weight_map.get_weight(point_index) <= threshold
		soft_body.call("set_point_pinned", point_index, should_pin)


static func _copy_mesh_as_array_mesh(source_mesh: Mesh) -> ArrayMesh:
	var array_mesh: ArrayMesh = ArrayMesh.new()
	if source_mesh == null:
		return array_mesh

	array_mesh.resource_name = "%s_SoftBodyMesh" % source_mesh.resource_name
	for surface_index in range(source_mesh.get_surface_count()):
		var arrays: Array = source_mesh.surface_get_arrays(surface_index).duplicate(true)
		array_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		var material: Material = source_mesh.surface_get_material(surface_index)
		if material != null:
			array_mesh.surface_set_material(surface_index, material)
	return array_mesh


static func _quality_to_precision(quality: int) -> int:
	match quality:
		0:
			return 2
		2:
			return 8
		_:
			return 5


static func _try_set_property(object: Object, property_name: String, value: Variant) -> void:
	for property in object.get_property_list():
		if String(property.get("name", "")) == property_name:
			object.set(property_name, value)
			return


static func _find_existing_controller(target: MeshInstance3D) -> JiggleRuntimeController:
	if target == null:
		return null
	for child in target.get_children():
		if child is JiggleRuntimeController:
			return child
	return null


static func _find_existing_softbody_peer(target: MeshInstance3D) -> SoftBody3D:
	if target == null or target.get_parent() == null:
		return null
	var expected_prefix: String = "%s_SoftBody3D" % target.name
	for child in target.get_parent().get_children():
		if child is SoftBody3D and String(child.name).begins_with(expected_prefix):
			return child
		if child is SoftBody3D and child.has_meta("jiggle_paint_source_path"):
			if String(child.get_meta("jiggle_paint_source_path")) == String(target.get_path()):
				return child
	return null


static func _unique_child_name(parent: Node, base_name: String) -> String:
	if parent == null:
		return base_name
	var candidate: String = base_name
	var suffix: int = 2
	while parent.has_node(candidate):
		candidate = "%s_%d" % [base_name, suffix]
		suffix += 1
	return candidate
