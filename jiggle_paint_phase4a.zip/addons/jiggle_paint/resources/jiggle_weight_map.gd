@tool
extends Resource
class_name JiggleWeightMap

## Stores per-vertex jiggle influence weights for one Mesh resource.
## The array is flat: all mesh surfaces are concatenated in surface order.
## Later phases can add region masks, texture baking, and skeletal remapping.

const FORMAT_VERSION := 2

@export var version: int = FORMAT_VERSION
@export var source_mesh_path: NodePath
@export var source_mesh_resource_path: String = ""
@export var mesh_vertex_count: int = 0
@export var surface_vertex_counts: PackedInt32Array = PackedInt32Array()
@export var weights: PackedFloat32Array = PackedFloat32Array()

@export_group("Default Physics")
@export var stiffness: float = 12.0
@export var damping: float = 0.65
@export var gravity_influence: float = 1.0
@export var wind_influence: float = 0.0
@export var simulation_quality: int = 1 # 0 Low, 1 Medium, 2 High

@export_group("Metadata")
@export var author_notes: String = ""
@export var mesh_signature: String = ""


func configure_from_mesh(mesh: Mesh, fill_weight: float = 0.0) -> void:
	version = FORMAT_VERSION
	surface_vertex_counts = PackedInt32Array()
	mesh_vertex_count = 0
	source_mesh_resource_path = ""
	mesh_signature = ""

	if mesh == null:
		weights = PackedFloat32Array()
		return

	source_mesh_resource_path = mesh.resource_path
	var signature_parts := PackedStringArray()
	for surface_index in range(mesh.get_surface_count()):
		var arrays: Array = mesh.surface_get_arrays(surface_index)
		var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var count := vertices.size()
		surface_vertex_counts.push_back(count)
		mesh_vertex_count += count
		signature_parts.append(str(count))

	mesh_signature = ";".join(signature_parts)
	weights = PackedFloat32Array()
	weights.resize(mesh_vertex_count)
	var clamped_weight: float = float(clamp(fill_weight, 0.0, 1.0))
	for i in range(weights.size()):
		weights[i] = clamped_weight


func matches_mesh(mesh: Mesh) -> bool:
	if mesh == null:
		return mesh_vertex_count == 0
	if mesh.get_surface_count() != surface_vertex_counts.size():
		return false
	var total := 0
	for surface_index in range(mesh.get_surface_count()):
		var arrays: Array = mesh.surface_get_arrays(surface_index)
		var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		if vertices.size() != surface_vertex_counts[surface_index]:
			return false
		total += vertices.size()
	return total == mesh_vertex_count and weights.size() == mesh_vertex_count


func ensure_matches_mesh(mesh: Mesh, fill_weight: float = 0.0) -> bool:
	if matches_mesh(mesh):
		return true
	configure_from_mesh(mesh, fill_weight)
	return false


func get_surface_offset(surface_index: int) -> int:
	var offset := 0
	var safe_surface: int = int(clamp(surface_index, 0, surface_vertex_counts.size()))
	for i in range(safe_surface):
		offset += surface_vertex_counts[i]
	return offset


func get_global_index(surface_index: int, vertex_index: int) -> int:
	return get_surface_offset(surface_index) + vertex_index


func is_valid_index(global_index: int) -> bool:
	return global_index >= 0 and global_index < weights.size()


func get_weight(global_index: int) -> float:
	if not is_valid_index(global_index):
		return 0.0
	return weights[global_index]


func set_weight(global_index: int, value: float) -> void:
	set_weight_silent(global_index, value)
	emit_changed()


func set_weight_silent(global_index: int, value: float) -> void:
	if not is_valid_index(global_index):
		return
	weights[global_index] = float(clamp(value, 0.0, 1.0))


func blend_weight(global_index: int, target: float, alpha: float) -> void:
	if not is_valid_index(global_index):
		return
	var current: float = weights[global_index]
	var clamped_target: float = float(clamp(target, 0.0, 1.0))
	var clamped_alpha: float = float(clamp(alpha, 0.0, 1.0))
	weights[global_index] = float(clamp(current + (clamped_target - current) * clamped_alpha, 0.0, 1.0))


func apply_paint(global_index: int, amount: float, mode: String = "add") -> void:
	if not is_valid_index(global_index):
		return
	match mode:
		"subtract":
			weights[global_index] = float(clamp(weights[global_index] - amount, 0.0, 1.0))
		"set":
			weights[global_index] = float(clamp(amount, 0.0, 1.0))
		_:
			weights[global_index] = float(clamp(weights[global_index] + amount, 0.0, 1.0))


func clear(value: float = 0.0) -> void:
	var clamped_weight: float = float(clamp(value, 0.0, 1.0))
	for i in range(weights.size()):
		weights[i] = clamped_weight
	emit_changed()


func copy_weights_from(new_weights: PackedFloat32Array) -> void:
	weights = PackedFloat32Array()
	weights.resize(new_weights.size())
	for i in range(new_weights.size()):
		weights[i] = new_weights[i]
	emit_changed()


func get_stats() -> Dictionary:
	if weights.is_empty():
		return {
			"count": 0,
			"painted": 0,
			"min": 0.0,
			"max": 0.0,
			"average": 0.0,
		}

	var min_value: float = 1.0
	var max_value: float = 0.0
	var total: float = 0.0
	var painted := 0
	for weight in weights:
		min_value = float(min(min_value, weight))
		max_value = float(max(max_value, weight))
		total += weight
		if weight > 0.001:
			painted += 1

	return {
		"count": weights.size(),
		"painted": painted,
		"min": min_value,
		"max": max_value,
		"average": total / float(weights.size()),
	}


static func color_for_weight(weight: float) -> Color:
	# Blender-like readable ramp: blue -> cyan -> yellow -> red.
	var w: float = float(clamp(weight, 0.0, 1.0))
	if w < 0.3333:
		var t_a: float = w / 0.3333
		return Color(0.0, t_a, 1.0, 0.88)
	elif w < 0.6666:
		var t_b: float = (w - 0.3333) / 0.3333
		return Color(t_b, 1.0, 1.0 - t_b, 0.88)
	else:
		var t_c: float = (w - 0.6666) / 0.3334
		return Color(1.0, 1.0 - t_c, 0.0, 0.88)
