extends Node3D

## Optional helper for quickly testing Phase 3A runtime jiggle.
## Attach this to a parent Node3D of the MeshInstance3D that has a
## JiggleRuntimeController. Run the scene to move the object side-to-side.

@export var amplitude: float = 1.0
@export var frequency: float = 1.0
@export var move_axis: Vector3 = Vector3.RIGHT

var _start_position: Vector3
var _time: float = 0.0


func _ready() -> void:
	_start_position = position
	if move_axis.length_squared() == 0.0:
		move_axis = Vector3.RIGHT
	move_axis = move_axis.normalized()


func _process(delta: float) -> void:
	_time += delta
	var offset: float = sin(_time * TAU * frequency) * amplitude
	position = _start_position + move_axis * offset
