# Samples Placeholder / Test Helpers

Full sample scenes will be added in later polish phases.

Current helper:

```text
jiggle_test_mover.gd
```

Attach `jiggle_test_mover.gd` to a parent `Node3D` of your painted `MeshInstance3D` to quickly test custom-spring runtime jiggle.

Basic custom-spring test flow:

1. Paint a mesh.
2. Save its weight map.
3. Select **Custom Springs** or **Hybrid**.
4. Generate the selected backend.
5. Add a parent `Node3D` above the mesh if needed.
6. Attach `jiggle_test_mover.gd` to that parent.
7. Run the scene.
8. The parent moves side-to-side, and painted vertices should jiggle.

Basic SoftBody3D test flow:

1. Paint blue/low weights where the mesh should stay anchored.
2. Paint red/high weights where the mesh should simulate.
3. Select **SoftBody3D/Jolt**.
4. Generate the selected backend.
5. Run the scene and test with gravity/collisions/movement.

Planned later samples:

1. Static prop jiggle sample.
2. Character accessory/hair jiggle sample.
3. SoftBody3D backend comparison sample.
4. Mobile quality/LOD sample.
