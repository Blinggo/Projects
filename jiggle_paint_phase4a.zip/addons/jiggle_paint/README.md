# Jiggle Paint Physics — Godot Add-on

Phase: **0.4.0 / Phase 4A SoftBody3D-Jolt backend MVP**  
Target: **Godot 4.6.x**, GDScript, Android-friendly/mobile-renderer workflow.

This add-on is being built in phases. The final goal is a Godot editor plugin that lets artists paint per-vertex jiggle influence onto 3D meshes and generate runtime jiggle physics automatically.

## Current Phase 4A Contents

Implemented from earlier phases:

- Editor toolbar toggle: **Jiggle Paint**.
- Dock panel: **Jiggle Physics**.
- Touch-friendly brush controls:
  - Size
  - Strength
  - Falloff
  - Add mode
  - Subtract mode
  - Set Target mode
  - Smooth mode
  - Numeric Target weight slider from `0.0` to `1.0`
  - Front Face Only toggle
- `JiggleWeightMap` custom Resource for per-vertex weights.
- Surface-based mesh hit testing.
- Basic back-side rejection when **Front Face Only** is enabled.
- Basic 3D brush ring preview on the hit surface.
- Temporary vertex color overlay for painted weights.
- Save painted weights as `.tres`.
- Load an existing `.tres` map by entering its `res://` path.
- Undo/redo support for paint strokes through Godot's editor undo stack.
- Custom-spring runtime deformation for static/non-skinned MeshInstance3D nodes.

New in Phase 4A:

- Backend selector:
  - **Custom Springs**
  - **SoftBody3D/Jolt**
  - **Hybrid**
- SoftBody3D/Jolt generation from the selected painted mesh.
- Painted weights are converted into SoftBody3D pinning:
  - vertices with weight at/below **Pin <= Weight** are pinned,
  - vertices above the threshold are simulated by SoftBody3D.
- SoftBody3D settings are mapped from the dock controls:
  - Quality -> `simulation_precision`
  - Stiffness -> `linear_stiffness`
  - Damping -> `damping_coefficient`
- Optional **Hide Original For SoftBody** toggle to avoid double visuals.
- Re-running generation updates existing generated controllers/SoftBody3D peers instead of creating endless duplicates.

## Backend Notes

### Custom Springs

Best for mobile-friendly predictable deformation. This is the recommended default for Android/mobile renderer projects.

Use this for:

- simple props,
- accessories,
- stylized jiggle,
- mobile runtime.

### SoftBody3D/Jolt

Uses Godot's SoftBody3D node and the configured physics engine. In Godot 4.6.x this should target Jolt-based 3D physics behavior.

Use this for:

- higher-quality soft-body experiments,
- cloth-like props,
- desktop/high-quality modes,
- comparison against the custom spring backend.

Phase 4A only maps weights to pinned/unpinned points. Partial per-vertex stiffness is not implemented yet.

### Hybrid

Currently generates/updates the custom spring controller. Later, Hybrid can become a combined workflow where the tool can switch/fallback between custom springs and SoftBody3D depending on platform/quality.

## Install

1. Copy the `addons/jiggle_paint` folder into your Godot project.
2. Open Godot.
3. Go to **Project > Project Settings > Plugins**.
4. Enable **Jiggle Paint Physics**.
5. Select a `MeshInstance3D` in your scene.
6. Open the **Jiggle Physics** dock.
7. Press **Create/Reset Map**.
8. Toggle **Jiggle Paint**.
9. Paint red/high influence where you want jiggle.
10. Use **Save .tres** to save the painted data.
11. Choose a backend.
12. Press **Generate Selected Backend**.

## Testing Custom Springs

1. Select **Custom Springs** or **Hybrid**.
2. Generate the backend.
3. Run the scene.
4. Move the mesh or its parent.

To see jiggle clearly, use `addons/jiggle_paint/samples/jiggle_test_mover.gd` on a parent Node3D.

## Testing SoftBody3D/Jolt

1. Paint low/blue weights where the mesh should stay attached.
2. Paint red/high weights where the mesh should be simulated.
3. Select **SoftBody3D/Jolt**.
4. Set **Pin <= Weight** around `0.05` to pin only almost-blue vertices.
5. Keep **Hide Original For SoftBody** enabled if you do not want double visuals.
6. Press **Generate Selected Backend**.
7. Run the scene.

If too much of the mesh moves, increase **Pin <= Weight** or paint more blue/low-weight anchor areas.

## Subdivision / Mesh Density Guidance

More subdivisions can improve visual smoothness because there are more vertices to paint and deform. However:

- cost increases with vertex count,
- Phase 3A custom springs rebuild runtime mesh surfaces during updates,
- unpainted subdivisions do not help much,
- SoftBody3D can become expensive quickly on mobile.

Best practice: subdivide only the areas that need to jiggle, not the entire mesh.

## Current Limitations

- Custom spring runtime deformation supports static/non-skinned MeshInstance3D nodes first.
- SoftBody3D weight support is currently pin/unpin approximation, not continuous per-vertex stiffness.
- SoftBody3D behavior depends on the Godot/Jolt physics implementation and project physics settings.
- Normals/tangents are not recalculated every frame for custom springs yet.
- Very dense runtime-deformed meshes can be expensive on mobile.
- Skeletal mesh/bone-aware jiggle is planned for Phase 5.
- Editor-time physics preview is planned for Phase 6.
- Baking is planned for Phase 7.

See [`docs/PHASES.md`](docs/PHASES.md) for the planned milestones.
