# Jiggle Paint Physics — Phased Development Plan

## Decision Record

- Language: **GDScript**.
- Target workflow: **Android-friendly editor usage + mobile renderer game runtime**.
- Backend strategy: **Hybrid**.
  - Start with a custom spring backend for predictable mobile performance.
  - Add SoftBody3D/Jolt generation as an optional high-quality backend.
  - Add PhysicalBone/bone-chain support later for skeletal secondary motion.

## Phase 0 — Scope Lock and Technical Validation

Goal: prevent overbuilding the wrong architecture.

Status: **Informally complete enough to start implementation.**

Tasks:

- Confirm target Godot version and Android editor behavior.
- Validate available SoftBody3D properties in the actual Godot build.
- Test editor plugin loading on desktop and Android editor.
- Confirm target mesh types:
  - Static props
  - Character hair
  - Clothing
  - Accessories
- Define acceptable mobile performance budgets.

## Phase 1 — Editor Plugin Scaffold and Weight Resource

Goal: create a usable foundation.

Status: **Complete / validated by user on Godot 4.6.2 Android editor.**

Implemented:

- Add `addons/jiggle_paint` plugin structure.
- Add editor toolbar toggle.
- Add dock UI with brush and physics controls.
- Add `JiggleWeightMap` Resource.
- Store weights by mesh surface/vertex index.
- Add basic painting input path.
- Add basic color overlay.
- Add save-to-`.tres` support.
- Add placeholder runtime controller generation.

## Phase 2 — Real Weight Painting MVP

Goal: make painting reliable and artist-friendly.

Status: **Phase 2A complete / validated by user. Phase 2B optimization remains pending.**

### Phase 2A Implemented

- Replaced ray-cylinder painting with closest-triangle surface hit testing.
- Added a cached mesh paint data pass:
  - world-space vertices
  - world-space normals
  - triangle indices
- Added **Front Face Only** painting option.
- Added basic rejection for opposite-side vertices.
- Added 3D brush ring preview on the surface hit.
- Added **Set Target** mode with numeric target weight.
- Added **Smooth** brush mode.
- Added load/reassign by `res://...tres` path.
- Added stroke-level editor undo/redo support.
- Kept all changes GDScript/mobile-editor friendly.

### Phase 2B Pending

- Build a stronger triangle/vertex acceleration structure for meshes up to 50k vertices.
- Add proper brush preview scaling/visibility polish.
- Add mirror painting option.
- Add flood fill tool.
- Add a full selected-vertex inspector for individual numeric vertex weights.
- Add stronger map assignment UI using an editor resource picker/file dialog.
- Add map compatibility/repair tools.

## Phase 3 — Custom Spring Runtime Backend

Goal: mobile-friendly runtime jiggle deformation.

Status: **Phase 3A complete / validated by user. Phase 3B optimization remains pending.**

### Phase 3A Implemented

- `JiggleRuntimeController` performs runtime updates in play mode.
- `JiggleSpringBackend` duplicates the source mesh into a runtime `ArrayMesh`.
- Keeps rest positions, simulated world positions, velocities, and per-vertex weights.
- Updates weighted vertices above a threshold.
- Implements semi-implicit spring integration.
- Supports stiffness, damping, gravity, wind, quality, and max displacement.
- Blends simulated offsets by painted weight.
- Keeps unpainted vertices fixed to rest shape.
- Adds basic distance LOD disable/low-quality behavior.
- Works in runtime and editor when `enable_in_editor` is turned on.

### Phase 3B Pending

- Improve performance by updating mesh surfaces more efficiently.
- Recalculate normals/tangents optionally.
- Add better mobile profiling controls.
- Add reset-on-teleport detection.
- Add per-region physics settings.
- Add sample scene with animation demonstrating runtime jiggle.

## Phase 4 — SoftBody3D/Jolt Backend

Goal: optional high-quality physics backend.

Status: **Phase 4A implemented. Needs user validation.**

### Phase 4A Implemented

- Added backend selector in the dock:
  - Custom Springs
  - SoftBody3D/Jolt
  - Hybrid
- Added SoftBody3D peer generation from selected mesh.
- Added mesh copy generation for SoftBody3D.
- Added basic weight-to-pin conversion:
  - low/blue weights are pinned,
  - higher weights are simulated.
- Added **Pin <= Weight** threshold control.
- Added **Hide Original For SoftBody** option.
- Mapped dock settings to SoftBody3D properties where available:
  - `simulation_precision`
  - `linear_stiffness`
  - `damping_coefficient`
  - `drag_coefficient`
  - `total_mass`
- Re-running generation updates an existing generated SoftBody3D peer where possible.

### Phase 4B Pending

- Validate exact SoftBody3D/Jolt behavior on Godot 4.6.2 Android editor/runtime.
- Add better collision layer/mask UI.
- Add better partial-weight mapping beyond pin/unpin.
- Add optional anchor/attachment node generation.
- Add platform warnings for expensive mobile SoftBody3D setups.
- Add comparison sample: custom springs vs SoftBody3D.

Exit criteria:

- Users can choose Custom Springs or SoftBody3D per object.
- SoftBody3D output is generated consistently.
- Mobile warnings are displayed when settings are expensive.

## Phase 5 — Skeletal Mesh Support

Goal: support characters, hair, clothing, and animated meshes.

Tasks:

- Detect `Skeleton3D` and `Skin` relationships.
- Support jiggle offsets in local/bone space.
- Add bone-chain/PhysicalBone generation option.
- Support painted regions tied to bones.
- Handle animation pose changes before jiggle simulation.
- Add reset-on-teleport logic.

Exit criteria:

- Animated characters can use painted jiggle regions.
- Jiggle follows animation and settles correctly.

## Phase 6 — Editor Realtime Preview

Goal: preview without entering game mode.

Tasks:

- Add play/pause/reset simulation controls.
- Run controlled editor-time simulation.
- Add gizmo overlays for velocity/anchors.
- Add safe scene cleanup for temporary nodes.
- Add preview frame stepping.

Exit criteria:

- Artists can paint and preview in the editor viewport.

## Phase 7 — Baking and Optimization

Goal: production performance.

Tasks:

- Bake jiggle deformation into animation tracks or mesh caches.
- Add distance/visibility LOD.
- Add update-rate reduction.
- Add vertex influence thresholding.
- Add optional compute/multithreading investigation.
- Add profiling UI.

Exit criteria:

- Users can bake or reduce runtime jiggle cost for mobile/low-end devices.

## Phase 8 — Samples, Documentation, and Polish

Goal: ship-quality add-on.

Tasks:

- Add sample character scene.
- Add sample prop scene.
- Add user manual in Markdown.
- Add developer API docs.
- Add troubleshooting guide.
- Add test matrix.
- Add versioned release package.

Exit criteria:

- New users can install and complete a basic jiggle setup without help.
