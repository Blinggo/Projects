# Jiggle Paint Physics — Developer API Draft

## `JiggleWeightMap`

Resource storing per-vertex influence weights.

Main properties:

- `surface_vertex_counts: PackedInt32Array`
- `weights: PackedFloat32Array`
- `stiffness: float`
- `damping: float`
- `gravity_influence: float`
- `wind_influence: float`
- `simulation_quality: int`

Main methods:

- `configure_from_mesh(mesh: Mesh, fill_weight := 0.0)`
- `matches_mesh(mesh: Mesh) -> bool`
- `ensure_matches_mesh(mesh: Mesh, fill_weight := 0.0) -> bool`
- `get_surface_offset(surface_index: int) -> int`
- `get_global_index(surface_index: int, vertex_index: int) -> int`
- `is_valid_index(global_index: int) -> bool`
- `get_weight(global_index: int) -> float`
- `set_weight(global_index: int, value: float)`
- `set_weight_silent(global_index: int, value: float)`
- `blend_weight(global_index: int, target: float, alpha: float)`
- `apply_paint(global_index: int, amount: float, mode := "add")`
- `clear(value := 0.0)`
- `copy_weights_from(new_weights: PackedFloat32Array)`
- `get_stats() -> Dictionary`
- `color_for_weight(weight: float) -> Color`

## `JiggleRuntimeController`

Generated runtime node. Phase 3A uses `JiggleSpringBackend` for custom-spring runtime deformation.

Main properties:

- `target_mesh_path: NodePath`
- `weight_map: JiggleWeightMap`
- `backend: String`
- `enabled: bool`
- `enable_in_editor: bool`
- `auto_initialize: bool`
- `stiffness: float`
- `damping: float`
- `gravity_influence: float`
- `wind_influence: float`
- `wind_direction: Vector3`
- `wind_frequency: float`
- `quality: int`
- `weight_threshold: float`
- `max_displacement: float`
- `lod_enabled: bool`
- `lod_disable_distance: float`
- `lod_low_quality_distance: float`

Main methods:

- `initialize_runtime() -> bool`
- `reset_simulation()`
- `restore_original_mesh()`
- `apply_settings(settings: Dictionary)`
- `get_target_mesh() -> MeshInstance3D`
- `get_influence_stats() -> Dictionary`
- `is_runtime_initialized() -> bool`

## `JiggleSpringBackend`

Runtime backend for static/non-skinned mesh deformation.

Main methods:

- `configure_from_mesh_instance(target: MeshInstance3D, weight_map: JiggleWeightMap) -> bool`
- `configure_from_mesh(mesh: Mesh, weight_map: JiggleWeightMap) -> bool`
- `simulate(delta: float, target: MeshInstance3D, settings: Dictionary)`
- `reset_simulation(target: MeshInstance3D)`
- `write_rest_pose(target: MeshInstance3D)`
- `restore_original_mesh(target: MeshInstance3D)`
- `is_configured() -> bool`
- `get_runtime_mesh() -> ArrayMesh`
- `get_source_mesh() -> Mesh`

## `JigglePhysicsGenerator`

Editor-time helper for generated nodes.

Main methods:

- `generate_selected_backend(target, weight_map, settings) -> Node`
- `generate_hybrid_controller(target, weight_map, settings) -> JiggleRuntimeController`
- `generate_softbody_peer(target, weight_map, settings) -> SoftBody3D`

Relevant generator settings:

- `backend: String`
  - `custom_springs`
  - `softbody`
  - `hybrid`
- `stiffness: float`
- `damping: float`
- `quality: int`
- `soft_pin_threshold: float`
- `soft_hide_original: bool`

## SoftBody3D Weight Mapping

Phase 4A maps weights to SoftBody3D pins:

```text
weight <= soft_pin_threshold -> pinned
weight > soft_pin_threshold  -> unpinned/simulated
```

This is an approximation. Continuous per-vertex stiffness/partial influence for SoftBody3D is planned for a later refinement if the engine API allows a clean mapping.

## Editor Plugin Internals

Paint internals are currently kept inside `jiggle_paint_plugin.gd`:

- closest-triangle ray hit testing
- world-space mesh paint cache
- front-face-only filtering
- brush ring preview
- stroke-level undo/redo snapshots

These may be split into separate helper classes when the acceleration structure is improved.
