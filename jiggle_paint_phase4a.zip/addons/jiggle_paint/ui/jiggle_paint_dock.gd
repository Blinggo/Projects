@tool
extends VBoxContainer
class_name JigglePaintDock

signal paint_mode_toggled(enabled: bool)
signal brush_changed(brush: Dictionary)
signal physics_changed(settings: Dictionary)
signal create_weight_map_requested()
signal clear_weight_map_requested()
signal save_weight_map_requested()
signal load_weight_map_requested(path: String)
signal generate_requested()
signal preview_toggled(enabled: bool)
signal bake_requested()

var _selected_label: Label
var _status_label: Label
var _stats_label: Label
var _paint_toggle: CheckButton
var _preview_toggle: CheckButton
var _mode_option: OptionButton
var _map_path_line: LineEdit

var _selected_mesh: MeshInstance3D
var _weight_map: Resource

var _brush := {
	"size": 0.35,
	"strength": 0.35,
	"falloff": 1.0,
	"mode": "add",
	"target_weight": 1.0,
	"front_face_only": true,
}

var _physics_settings := {
	"stiffness": 12.0,
	"damping": 0.65,
	"gravity_influence": 1.0,
	"wind_influence": 0.0,
	"quality": 1,
	"backend": "hybrid",
	"soft_pin_threshold": 0.05,
	"soft_hide_original": true,
}


func _ready() -> void:
	_build_ui()
	_update_selected_label()
	_update_stats_label()
	_set_status("Phase 3 custom spring runtime ready. Select a MeshInstance3D.")


func _build_ui() -> void:
	if get_child_count() > 0:
		return

	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	custom_minimum_size = Vector2(300, 560)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_child(scroll)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_theme_constant_override("separation", 8)
	scroll.add_child(root)

	var title := Label.new()
	title.text = "Jiggle Physics"
	title.add_theme_font_size_override("font_size", 18)
	root.add_child(title)

	_selected_label = Label.new()
	_selected_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(_selected_label)

	_status_label = Label.new()
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(_status_label)

	root.add_child(_section_title("Paint Mode"))
	_paint_toggle = CheckButton.new()
	_paint_toggle.text = "Jiggle Paint"
	_paint_toggle.tooltip_text = "Toggle viewport painting. Select a MeshInstance3D first."
	_paint_toggle.toggled.connect(func(enabled: bool) -> void:
		paint_mode_toggled.emit(enabled)
	)
	root.add_child(_paint_toggle)

	var row := HBoxContainer.new()
	root.add_child(row)
	var create_button := Button.new()
	create_button.text = "Create/Reset Map"
	create_button.tooltip_text = "Create a new JiggleWeightMap for the selected mesh."
	create_button.pressed.connect(func() -> void:
		create_weight_map_requested.emit()
	)
	row.add_child(create_button)

	var clear_button := Button.new()
	clear_button.text = "Clear"
	clear_button.tooltip_text = "Set all weights to 0."
	clear_button.pressed.connect(func() -> void:
		clear_weight_map_requested.emit()
	)
	row.add_child(clear_button)

	var save_button := Button.new()
	save_button.text = "Save .tres"
	save_button.tooltip_text = "Save the current JiggleWeightMap next to the scene."
	save_button.pressed.connect(func() -> void:
		save_weight_map_requested.emit()
	)
	root.add_child(save_button)

	var path_label := Label.new()
	path_label.text = "Weight Map Path"
	root.add_child(path_label)

	var path_row := HBoxContainer.new()
	path_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(path_row)

	_map_path_line = LineEdit.new()
	_map_path_line.placeholder_text = "res://mesh_jiggle_weights.tres"
	_map_path_line.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	path_row.add_child(_map_path_line)

	var load_button := Button.new()
	load_button.text = "Load"
	load_button.tooltip_text = "Load an existing JiggleWeightMap .tres for the selected mesh."
	load_button.pressed.connect(func() -> void:
		load_weight_map_requested.emit(_map_path_line.text.strip_edges())
	)
	path_row.add_child(load_button)

	_stats_label = Label.new()
	_stats_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(_stats_label)

	root.add_child(_section_title("Brush"))
	root.add_child(_make_slider("Size", 0.02, 5.0, 0.01, _brush["size"], func(value: float) -> void:
		_brush["size"] = value
		_emit_brush_changed()
	))
	root.add_child(_make_slider("Strength", 0.01, 1.0, 0.01, _brush["strength"], func(value: float) -> void:
		_brush["strength"] = value
		_emit_brush_changed()
	))
	root.add_child(_make_slider("Falloff", 0.05, 4.0, 0.05, _brush["falloff"], func(value: float) -> void:
		_brush["falloff"] = value
		_emit_brush_changed()
	))
	root.add_child(_make_slider("Target", 0.0, 1.0, 0.01, _brush["target_weight"], func(value: float) -> void:
		_brush["target_weight"] = value
		_emit_brush_changed()
	))

	var mode_row := HBoxContainer.new()
	var mode_label := Label.new()
	mode_label.text = "Mode"
	mode_label.custom_minimum_size = Vector2(96, 0)
	mode_row.add_child(mode_label)
	_mode_option = OptionButton.new()
	_mode_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_mode_option.add_item("Add", 0)
	_mode_option.add_item("Subtract", 1)
	_mode_option.add_item("Set Target", 2)
	_mode_option.add_item("Smooth", 3)
	_mode_option.item_selected.connect(func(index: int) -> void:
		match index:
			1:
				_brush["mode"] = "subtract"
			2:
				_brush["mode"] = "set"
			3:
				_brush["mode"] = "smooth"
			_:
				_brush["mode"] = "add"
		_emit_brush_changed()
	)
	mode_row.add_child(_mode_option)
	root.add_child(mode_row)

	var front_face_check := CheckBox.new()
	front_face_check.text = "Front Face Only"
	front_face_check.tooltip_text = "When enabled, painting starts from the closest visible triangle and rejects back-facing/opposite-side vertices."
	front_face_check.button_pressed = bool(_brush["front_face_only"])
	front_face_check.toggled.connect(func(enabled: bool) -> void:
		_brush["front_face_only"] = enabled
		_emit_brush_changed()
	)
	root.add_child(front_face_check)

	var phase2_note := Label.new()
	phase2_note.text = "Phase 2: paint now uses mesh surface hits instead of painting along the whole camera ray. Use Set Target for numeric 0-1 weight painting."
	phase2_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(phase2_note)

	root.add_child(_section_title("Physics Defaults"))

	var backend_row := HBoxContainer.new()
	var backend_label := Label.new()
	backend_label.text = "Backend"
	backend_label.custom_minimum_size = Vector2(96, 0)
	backend_row.add_child(backend_label)
	var backend_option := OptionButton.new()
	backend_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	backend_option.add_item("Custom Springs", 0)
	backend_option.add_item("SoftBody3D/Jolt", 1)
	backend_option.add_item("Hybrid", 2)
	backend_option.select(2)
	backend_option.item_selected.connect(func(index: int) -> void:
		match index:
			0:
				_physics_settings["backend"] = "custom_springs"
			1:
				_physics_settings["backend"] = "softbody"
			_:
				_physics_settings["backend"] = "hybrid"
		_emit_physics_changed()
	)
	backend_row.add_child(backend_option)
	root.add_child(backend_row)

	root.add_child(_make_slider("Stiffness", 0.0, 100.0, 0.1, _physics_settings["stiffness"], func(value: float) -> void:
		_physics_settings["stiffness"] = value
		_emit_physics_changed()
	))
	root.add_child(_make_slider("Damping", 0.0, 1.0, 0.01, _physics_settings["damping"], func(value: float) -> void:
		_physics_settings["damping"] = value
		_emit_physics_changed()
	))
	root.add_child(_make_slider("Gravity", 0.0, 2.0, 0.01, _physics_settings["gravity_influence"], func(value: float) -> void:
		_physics_settings["gravity_influence"] = value
		_emit_physics_changed()
	))
	root.add_child(_make_slider("Wind", 0.0, 2.0, 0.01, _physics_settings["wind_influence"], func(value: float) -> void:
		_physics_settings["wind_influence"] = value
		_emit_physics_changed()
	))

	var quality_row := HBoxContainer.new()
	var quality_label := Label.new()
	quality_label.text = "Quality"
	quality_label.custom_minimum_size = Vector2(96, 0)
	quality_row.add_child(quality_label)
	var quality_option := OptionButton.new()
	quality_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	quality_option.add_item("Low", 0)
	quality_option.add_item("Medium", 1)
	quality_option.add_item("High", 2)
	quality_option.select(1)
	quality_option.item_selected.connect(func(index: int) -> void:
		_physics_settings["quality"] = index
		_emit_physics_changed()
	)
	quality_row.add_child(quality_option)
	root.add_child(quality_row)

	root.add_child(_section_title("SoftBody3D / Jolt"))
	root.add_child(_make_slider("Pin <= Weight", 0.0, 1.0, 0.01, _physics_settings["soft_pin_threshold"], func(value: float) -> void:
		_physics_settings["soft_pin_threshold"] = value
		_emit_physics_changed()
	))

	var hide_original_check := CheckBox.new()
	hide_original_check.text = "Hide Original For SoftBody"
	hide_original_check.tooltip_text = "When generating SoftBody3D, hide the original MeshInstance3D to avoid double visuals."
	hide_original_check.button_pressed = bool(_physics_settings["soft_hide_original"])
	hide_original_check.toggled.connect(func(enabled: bool) -> void:
		_physics_settings["soft_hide_original"] = enabled
		_emit_physics_changed()
	)
	root.add_child(hide_original_check)

	root.add_child(_section_title("Generation / Preview"))
	var generate_button := Button.new()
	generate_button.text = "Generate Selected Backend"
	generate_button.tooltip_text = "Generates the selected backend: custom spring controller or SoftBody3D peer."
	generate_button.pressed.connect(func() -> void:
		generate_requested.emit()
	)
	root.add_child(generate_button)

	_preview_toggle = CheckButton.new()
	_preview_toggle.text = "Preview Simulation"
	_preview_toggle.tooltip_text = "Reserved for live editor simulation in a later phase."
	_preview_toggle.toggled.connect(func(enabled: bool) -> void:
		preview_toggled.emit(enabled)
	)
	root.add_child(_preview_toggle)

	var bake_button := Button.new()
	bake_button.text = "Bake Animation (Phase 7)"
	bake_button.disabled = true
	bake_button.tooltip_text = "Baking will be implemented after runtime simulation is stable."
	bake_button.pressed.connect(func() -> void:
		bake_requested.emit()
	)
	root.add_child(bake_button)

	var note := Label.new()
	note.text = "Tip: On Android, keep Front Face Only on while painting and use Low/Medium runtime quality for dense meshes."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(note)


func _section_title(text: String) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 15)
	return label


func _make_slider(label_text: String, min_value: float, max_value: float, step: float, value: float, callback: Callable) -> Control:
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var row := HBoxContainer.new()
	box.add_child(row)
	var label := Label.new()
	label.text = label_text
	label.custom_minimum_size = Vector2(96, 0)
	row.add_child(label)
	var value_label := Label.new()
	value_label.text = str(snapped(value, step))
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(value_label)

	var slider := HSlider.new()
	slider.min_value = min_value
	slider.max_value = max_value
	slider.step = step
	slider.value = value
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.custom_minimum_size = Vector2(220, 42)
	slider.value_changed.connect(func(new_value: float) -> void:
		value_label.text = str(snapped(new_value, step))
		callback.call(new_value)
	)
	box.add_child(slider)
	return box


func _emit_brush_changed() -> void:
	brush_changed.emit(_brush.duplicate(true))


func _emit_physics_changed() -> void:
	physics_changed.emit(_physics_settings.duplicate(true))


func set_selected_mesh(mesh: MeshInstance3D) -> void:
	_selected_mesh = mesh
	_update_selected_label()


func set_weight_map(weight_map: Resource) -> void:
	_weight_map = weight_map
	_update_stats_label()


func set_weight_map_path(path: String) -> void:
	if _map_path_line != null:
		_map_path_line.text = path


func refresh_weight_stats() -> void:
	_update_stats_label()


func set_paint_mode(enabled: bool) -> void:
	if _paint_toggle != null:
		_paint_toggle.set_pressed_no_signal(enabled)


func set_preview_mode(enabled: bool) -> void:
	if _preview_toggle != null:
		_preview_toggle.set_pressed_no_signal(enabled)


func set_status(message: String) -> void:
	_set_status(message)


func get_brush() -> Dictionary:
	return _brush.duplicate(true)


func get_physics_settings() -> Dictionary:
	return _physics_settings.duplicate(true)


func _update_selected_label() -> void:
	if _selected_label == null:
		return
	if _selected_mesh == null:
		_selected_label.text = "Selected: none"
	else:
		_selected_label.text = "Selected: %s" % _selected_mesh.name


func _update_stats_label() -> void:
	if _stats_label == null:
		return
	if _weight_map == null or not _weight_map.has_method("get_stats"):
		_stats_label.text = "Weight map: none"
		return
	var stats: Dictionary = _weight_map.get_stats()
	_stats_label.text = "Weights: %d vertices | painted: %d | avg: %.3f" % [stats["count"], stats["painted"], stats["average"]]


func _set_status(message: String) -> void:
	if _status_label == null:
		return
	_status_label.text = message
