@tool
extends EditorPlugin

const DockScript := preload("res://addons/jiggle_paint/ui/jiggle_paint_dock.gd")
const WeightMapScript := preload("res://addons/jiggle_paint/resources/jiggle_weight_map.gd")
const Generator := preload("res://addons/jiggle_paint/generation/jiggle_physics_generator.gd")

const RAY_EPSILON := 0.000001
const BRUSH_RING_SEGMENTS := 64

var _dock: JigglePaintDock
var _toolbar_button: Button
var _paint_enabled := false
var _preview_enabled := false
var _selected_mesh: MeshInstance3D
var _weight_map: JiggleWeightMap

var _brush := {
	"size": 0.35,
	"strength": 0.35,
	"falloff": 1.0,
	"mode": "add",
	"target_weight": 1.0,
	"front_face_only": true,
}

var _physics_settings := {
	"stiffness": 12.0,
	"damping": 0.65,
	"gravity_influence": 1.0,
	"wind_influence": 0.0,
	"quality": 1,
	"backend": "hybrid",
	"soft_pin_threshold": 0.05,
	"soft_hide_original": true,
}

var _preview_instance: MeshInstance3D
var _brush_preview_instance: MeshInstance3D
var _painted_since_preview := false

var _mesh_cache := {}
var _stroke_active := false
var _stroke_before_weights: PackedFloat32Array = PackedFloat32Array()
var _stroke_changed := false


func _enter_tree() -> void:
	_dock = DockScript.new()
	_dock.name = "Jiggle Physics"
	add_control_to_dock(DOCK_SLOT_RIGHT_UL, _dock)

	_toolbar_button = Button.new()
	_toolbar_button.text = "Jiggle Paint"
	_toolbar_button.toggle_mode = true
	_toolbar_button.tooltip_text = "Toggle Jiggle Paint mode for the selected MeshInstance3D."
	add_control_to_container(CONTAINER_SPATIAL_EDITOR_MENU, _toolbar_button)

	_toolbar_button.toggled.connect(_set_paint_enabled)
	_dock.paint_mode_toggled.connect(_set_paint_enabled)
	_dock.brush_changed.connect(_on_brush_changed)
	_dock.physics_changed.connect(_on_physics_changed)
	_dock.create_weight_map_requested.connect(_create_weight_map)
	_dock.clear_weight_map_requested.connect(_clear_weight_map)
	_dock.save_weight_map_requested.connect(_save_weight_map)
	_dock.load_weight_map_requested.connect(_load_weight_map)
	_dock.generate_requested.connect(_generate_runtime_controller)
	_dock.preview_toggled.connect(_set_preview_enabled)

	get_editor_interface().get_selection().selection_changed.connect(_on_selection_changed)
	_on_selection_changed()


func _exit_tree() -> void:
	_end_paint_stroke()
	_remove_preview_instance()
	_remove_brush_preview_instance()

	if get_editor_interface().get_selection().selection_changed.is_connected(_on_selection_changed):
		get_editor_interface().get_selection().selection_changed.disconnect(_on_selection_changed)

	if _toolbar_button != null:
		remove_control_from_container(CONTAINER_SPATIAL_EDITOR_MENU, _toolbar_button)
		_toolbar_button.queue_free()
		_toolbar_button = null

	if _dock != null:
		remove_control_from_docks(_dock)
		_dock.queue_free()
		_dock = null


func _handles(object: Object) -> bool:
	return object is MeshInstance3D


func _forward_3d_gui_input(viewport_camera: Camera3D, event: InputEvent) -> int:
	if not _paint_enabled:
		return AFTER_GUI_INPUT_PASS
	if _selected_mesh == null or _selected_mesh.mesh == null:
		return AFTER_GUI_INPUT_PASS
	if _weight_map == null:
		_create_weight_map()

	if event is InputEventMouseButton:
		var mouse_button: InputEventMouseButton = event as InputEventMouseButton
		if mouse_button.button_index == MOUSE_BUTTON_LEFT:
			_update_brush_preview(viewport_camera, mouse_button.position)
			if mouse_button.pressed:
				_begin_paint_stroke()
				_paint_at_screen_position(viewport_camera, mouse_button.position)
			else:
				_end_paint_stroke()
			return AFTER_GUI_INPUT_STOP

	elif event is InputEventMouseMotion:
		var mouse_motion: InputEventMouseMotion = event as InputEventMouseMotion
		_update_brush_preview(viewport_camera, mouse_motion.position)
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
			if not _stroke_active:
				_begin_paint_stroke()
			_paint_at_screen_position(viewport_camera, mouse_motion.position)
			return AFTER_GUI_INPUT_STOP

	elif event is InputEventScreenTouch:
		var touch: InputEventScreenTouch = event as InputEventScreenTouch
		_update_brush_preview(viewport_camera, touch.position)
		if touch.pressed:
			_begin_paint_stroke()
			_paint_at_screen_position(viewport_camera, touch.position)
		else:
			_end_paint_stroke()
		return AFTER_GUI_INPUT_STOP

	elif event is InputEventScreenDrag:
		var drag: InputEventScreenDrag = event as InputEventScreenDrag
		_update_brush_preview(viewport_camera, drag.position)
		if not _stroke_active:
			_begin_paint_stroke()
		_paint_at_screen_position(viewport_camera, drag.position)
		return AFTER_GUI_INPUT_STOP

	return AFTER_GUI_INPUT_PASS


func _on_selection_changed() -> void:
	_selected_mesh = null
	_mesh_cache.clear()
	_remove_brush_preview_instance()

	var selected_nodes := get_editor_interface().get_selection().get_selected_nodes()
	for node in selected_nodes:
		if node is MeshInstance3D and node.mesh != null:
			_selected_mesh = node
			break

	if _dock != null:
		_dock.set_selected_mesh(_selected_mesh)

	if _selected_mesh == null:
		_set_paint_enabled(false)
		_weight_map = null
		_remove_preview_instance()
		if _dock != null:
			_dock.set_weight_map(null)
			_dock.set_status("Select a MeshInstance3D to start painting.")
		return

	if _weight_map == null or not _weight_map.matches_mesh(_selected_mesh.mesh):
		_weight_map = WeightMapScript.new()
		_weight_map.configure_from_mesh(_selected_mesh.mesh, 0.0)
		_weight_map.source_mesh_path = _selected_mesh.get_path()

	_rebuild_mesh_cache()

	if _dock != null:
		_dock.set_weight_map(_weight_map)
		_dock.set_status("Ready. Toggle Jiggle Paint, then drag on the visible mesh surface.")

	_rebuild_preview_instance()


func _set_paint_enabled(enabled: bool) -> void:
	if enabled and (_selected_mesh == null or _selected_mesh.mesh == null):
		enabled = false
		if _dock != null:
			_dock.set_status("Cannot enter paint mode: select a MeshInstance3D first.")

	_paint_enabled = enabled
	if _toolbar_button != null:
		_toolbar_button.set_pressed_no_signal(_paint_enabled)
	if _dock != null:
		_dock.set_paint_mode(_paint_enabled)

	if _paint_enabled:
		_rebuild_mesh_cache()
		_rebuild_preview_instance()
	else:
		_end_paint_stroke()
		_remove_preview_instance()
		_remove_brush_preview_instance()


func _set_preview_enabled(enabled: bool) -> void:
	_preview_enabled = enabled
	if _dock != null:
		_dock.set_preview_mode(enabled)
		_dock.set_status("Preview simulation is reserved for a later phase." if enabled else "Preview stopped.")


func _on_brush_changed(brush: Dictionary) -> void:
	_brush = brush.duplicate(true)
	_refresh_brush_preview_mesh()


func _on_physics_changed(settings: Dictionary) -> void:
	_physics_settings = settings.duplicate(true)
	if _weight_map != null:
		_weight_map.stiffness = float(_physics_settings.get("stiffness", _weight_map.stiffness))
		_weight_map.damping = float(_physics_settings.get("damping", _weight_map.damping))
		_weight_map.gravity_influence = float(_physics_settings.get("gravity_influence", _weight_map.gravity_influence))
		_weight_map.wind_influence = float(_physics_settings.get("wind_influence", _weight_map.wind_influence))
		_weight_map.simulation_quality = int(_physics_settings.get("quality", _weight_map.simulation_quality))


func _create_weight_map() -> void:
	if _selected_mesh == null or _selected_mesh.mesh == null:
		if _dock != null:
			_dock.set_status("Select a MeshInstance3D before creating a weight map.")
		return
	_weight_map = WeightMapScript.new()
	_weight_map.configure_from_mesh(_selected_mesh.mesh, 0.0)
	_weight_map.source_mesh_path = _selected_mesh.get_path()
	_on_physics_changed(_physics_settings)
	_rebuild_mesh_cache()
	if _dock != null:
		_dock.set_weight_map(_weight_map)
		_dock.set_status("Created fresh JiggleWeightMap for %s." % _selected_mesh.name)
	_rebuild_preview_instance()


func _clear_weight_map() -> void:
	if _weight_map == null:
		return
	_begin_paint_stroke()
	_weight_map.clear(0.0)
	_stroke_changed = true
	_end_paint_stroke()
	if _dock != null:
		_dock.refresh_weight_stats()
		_dock.set_status("Cleared all weights.")
	_refresh_preview_colors()


func _save_weight_map() -> void:
	if _weight_map == null:
		if _dock != null:
			_dock.set_status("No weight map to save.")
		return

	var base_name: String = "jiggle_weights"
	if _selected_mesh != null:
		base_name = _selected_mesh.name.to_snake_case() + "_jiggle_weights"
	var edited_root: Node = get_editor_interface().get_edited_scene_root()
	var scene_path: String = edited_root.scene_file_path if edited_root != null else ""
	var directory: String = "res://"
	if scene_path != "":
		directory = scene_path.get_base_dir()
		if not directory.ends_with("/"):
			directory += "/"
	var save_path: String = directory + base_name + ".tres"

	var error: int = ResourceSaver.save(_weight_map, save_path)
	if error == OK:
		if _dock != null:
			_dock.set_weight_map_path(save_path)
			_dock.set_status("Saved weight map: %s" % save_path)
	else:
		push_error("Failed to save JiggleWeightMap to %s. Error: %s" % [save_path, error])
		if _dock != null:
			_dock.set_status("Save failed. Check the Output panel.")


func _load_weight_map(path: String) -> void:
	var clean_path: String = path.strip_edges()
	if clean_path == "":
		if _dock != null:
			_dock.set_status("Enter a res:// path to a JiggleWeightMap .tres, then press Load.")
		return
	if _selected_mesh == null or _selected_mesh.mesh == null:
		if _dock != null:
			_dock.set_status("Select a MeshInstance3D before loading a weight map.")
		return

	var loaded_resource: Resource = ResourceLoader.load(clean_path)
	if loaded_resource == null:
		if _dock != null:
			_dock.set_status("Could not load: %s" % clean_path)
		return
	if not (loaded_resource is JiggleWeightMap):
		if _dock != null:
			_dock.set_status("Resource is not a JiggleWeightMap: %s" % clean_path)
		return

	var loaded_map: JiggleWeightMap = loaded_resource as JiggleWeightMap
	if not loaded_map.matches_mesh(_selected_mesh.mesh):
		if _dock != null:
			_dock.set_status("Map does not match selected mesh vertex layout.")
		return

	_weight_map = loaded_map
	_weight_map.source_mesh_path = _selected_mesh.get_path()
	_rebuild_mesh_cache()
	if _dock != null:
		_dock.set_weight_map(_weight_map)
		_dock.set_weight_map_path(clean_path)
		_dock.refresh_weight_stats()
		_dock.set_status("Loaded weight map: %s" % clean_path)
	_refresh_preview_colors()


func _generate_runtime_controller() -> void:
	if _selected_mesh == null or _weight_map == null:
		if _dock != null:
			_dock.set_status("Select a mesh and create/paint a weight map first.")
		return

	var generated_node: Node = Generator.generate_selected_backend(_selected_mesh, _weight_map, _physics_settings)
	if generated_node != null:
		if _dock != null:
			var backend: String = String(_physics_settings.get("backend", "hybrid"))
			if backend == "softbody":
				_dock.set_status("Generated/updated %s. SoftBody3D/Jolt backend uses pinned low-weight vertices." % generated_node.name)
			else:
				_dock.set_status("Generated/updated %s under %s. Custom-spring jiggle runs in play mode." % [generated_node.name, _selected_mesh.name])


func _paint_at_screen_position(camera: Camera3D, screen_position: Vector2) -> void:
	if _selected_mesh == null or _selected_mesh.mesh == null or _weight_map == null:
		return

	_ensure_mesh_cache()
	if _mesh_cache.is_empty():
		return

	var ray_origin: Vector3 = camera.project_ray_origin(screen_position)
	var ray_direction: Vector3 = camera.project_ray_normal(screen_position).normalized()
	var front_face_only: bool = bool(_brush.get("front_face_only", true))
	var hit: Dictionary = _raycast_cached_mesh(ray_origin, ray_direction, front_face_only)
	if hit.is_empty():
		_hide_brush_preview()
		if _dock != null:
			_dock.set_status("No visible mesh surface under brush.")
		return

	var brush_size: float = float(_brush.get("size", 0.35))
	var hit_position: Vector3 = hit["position"]
	var hit_normal: Vector3 = hit["normal"]
	_update_brush_ring(hit_position, hit_normal, brush_size)

	var affected_vertices: Array = _collect_affected_vertices(hit, brush_size, front_face_only)
	var changed_count: int = _apply_brush_to_vertices(affected_vertices, brush_size)

	if changed_count > 0:
		_weight_map.emit_changed()
		_stroke_changed = true
		_painted_since_preview = true
		if _dock != null:
			_dock.refresh_weight_stats()
			_dock.set_status("Painted %d vertices on surface." % changed_count)
		_refresh_preview_colors()


func _update_brush_preview(camera: Camera3D, screen_position: Vector2) -> void:
	if not _paint_enabled or _selected_mesh == null or _selected_mesh.mesh == null:
		_hide_brush_preview()
		return

	_ensure_mesh_cache()
	if _mesh_cache.is_empty():
		_hide_brush_preview()
		return

	var ray_origin: Vector3 = camera.project_ray_origin(screen_position)
	var ray_direction: Vector3 = camera.project_ray_normal(screen_position).normalized()
	var front_face_only: bool = bool(_brush.get("front_face_only", true))
	var hit: Dictionary = _raycast_cached_mesh(ray_origin, ray_direction, front_face_only)
	if hit.is_empty():
		_hide_brush_preview()
		return

	var brush_size: float = float(_brush.get("size", 0.35))
	var hit_position: Vector3 = hit["position"]
	var hit_normal: Vector3 = hit["normal"]
	_update_brush_ring(hit_position, hit_normal, brush_size)


func _rebuild_mesh_cache() -> void:
	_mesh_cache.clear()
	if _selected_mesh == null or _selected_mesh.mesh == null:
		return

	var mesh: Mesh = _selected_mesh.mesh
	var global_transform: Transform3D = _selected_mesh.global_transform
	var normal_basis: Basis = global_transform.basis
	var all_vertices := PackedVector3Array()
	var all_normals := PackedVector3Array()
	var all_triangles := PackedInt32Array()
	var vertex_offset := 0

	for surface_index in range(mesh.get_surface_count()):
		var arrays: Array = mesh.surface_get_arrays(surface_index)
		var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var normals := PackedVector3Array()
		var normals_variant: Variant = arrays[Mesh.ARRAY_NORMAL]
		if normals_variant is PackedVector3Array:
			normals = normals_variant

		for vertex_index in range(vertices.size()):
			all_vertices.push_back(global_transform * vertices[vertex_index])
			if vertex_index < normals.size():
				var world_normal: Vector3 = normal_basis * normals[vertex_index]
				if world_normal.length_squared() > RAY_EPSILON:
					world_normal = world_normal.normalized()
				all_normals.push_back(world_normal)
			else:
				all_normals.push_back(Vector3.ZERO)

		var indices := PackedInt32Array()
		var indices_variant: Variant = arrays[Mesh.ARRAY_INDEX]
		if indices_variant is PackedInt32Array:
			indices = indices_variant

		if indices.size() >= 3:
			for index_position in range(0, indices.size() - 2, 3):
				all_triangles.push_back(vertex_offset + int(indices[index_position]))
				all_triangles.push_back(vertex_offset + int(indices[index_position + 1]))
				all_triangles.push_back(vertex_offset + int(indices[index_position + 2]))
		else:
			var triangle_vertex_limit: int = vertices.size() - (vertices.size() % 3)
			for vertex_position in range(0, triangle_vertex_limit, 3):
				all_triangles.push_back(vertex_offset + vertex_position)
				all_triangles.push_back(vertex_offset + vertex_position + 1)
				all_triangles.push_back(vertex_offset + vertex_position + 2)

		vertex_offset += vertices.size()

	_mesh_cache = {
		"mesh": mesh,
		"instance_id": _selected_mesh.get_instance_id(),
		"global_transform": global_transform,
		"vertices": all_vertices,
		"normals": all_normals,
		"triangles": all_triangles,
	}


func _ensure_mesh_cache() -> void:
	if _selected_mesh == null or _selected_mesh.mesh == null:
		_mesh_cache.clear()
		return
	if _mesh_cache.is_empty():
		_rebuild_mesh_cache()
		return
	if _mesh_cache.get("mesh") != _selected_mesh.mesh:
		_rebuild_mesh_cache()
		return
	if int(_mesh_cache.get("instance_id", 0)) != _selected_mesh.get_instance_id():
		_rebuild_mesh_cache()
		return
	var cached_transform: Transform3D = _mesh_cache.get("global_transform", Transform3D.IDENTITY)
	if cached_transform != _selected_mesh.global_transform:
		_rebuild_mesh_cache()


func _raycast_cached_mesh(ray_origin: Vector3, ray_direction: Vector3, front_face_only: bool) -> Dictionary:
	var vertices: PackedVector3Array = _mesh_cache.get("vertices", PackedVector3Array())
	var triangles: PackedInt32Array = _mesh_cache.get("triangles", PackedInt32Array())
	var best_distance: float = INF
	var best_hit := {}

	for triangle_position in range(0, triangles.size() - 2, 3):
		var index_a: int = triangles[triangle_position]
		var index_b: int = triangles[triangle_position + 1]
		var index_c: int = triangles[triangle_position + 2]
		if index_a >= vertices.size() or index_b >= vertices.size() or index_c >= vertices.size():
			continue

		var point_a: Vector3 = vertices[index_a]
		var point_b: Vector3 = vertices[index_b]
		var point_c: Vector3 = vertices[index_c]
		var triangle_normal: Vector3 = (point_b - point_a).cross(point_c - point_a)
		if triangle_normal.length_squared() <= RAY_EPSILON:
			continue
		triangle_normal = triangle_normal.normalized()

		var facing_dot: float = triangle_normal.dot(ray_direction)
		if front_face_only and facing_dot >= 0.0:
			continue

		var hit: Dictionary = _intersect_ray_triangle(ray_origin, ray_direction, point_a, point_b, point_c)
		if hit.is_empty():
			continue

		var hit_distance: float = float(hit["distance"])
		if hit_distance < best_distance:
			best_distance = hit_distance
			var oriented_normal: Vector3 = triangle_normal
			if oriented_normal.dot(ray_direction) > 0.0:
				oriented_normal = -oriented_normal
			best_hit = {
				"position": ray_origin + ray_direction * hit_distance,
				"normal": oriented_normal,
				"distance": hit_distance,
				"triangle": PackedInt32Array([index_a, index_b, index_c]),
			}

	return best_hit


func _intersect_ray_triangle(ray_origin: Vector3, ray_direction: Vector3, point_a: Vector3, point_b: Vector3, point_c: Vector3) -> Dictionary:
	var edge_1: Vector3 = point_b - point_a
	var edge_2: Vector3 = point_c - point_a
	var p_vector: Vector3 = ray_direction.cross(edge_2)
	var determinant: float = edge_1.dot(p_vector)
	if abs(determinant) < RAY_EPSILON:
		return {}

	var inverse_determinant: float = 1.0 / determinant
	var t_vector: Vector3 = ray_origin - point_a
	var u: float = t_vector.dot(p_vector) * inverse_determinant
	if u < 0.0 or u > 1.0:
		return {}

	var q_vector: Vector3 = t_vector.cross(edge_1)
	var v: float = ray_direction.dot(q_vector) * inverse_determinant
	if v < 0.0 or u + v > 1.0:
		return {}

	var distance: float = edge_2.dot(q_vector) * inverse_determinant
	if distance < 0.0:
		return {}

	return {
		"distance": distance,
		"u": u,
		"v": v,
	}


func _collect_affected_vertices(hit: Dictionary, brush_size: float, front_face_only: bool) -> Array:
	var affected: Array = []
	var vertices: PackedVector3Array = _mesh_cache.get("vertices", PackedVector3Array())
	var normals: PackedVector3Array = _mesh_cache.get("normals", PackedVector3Array())
	var hit_position: Vector3 = hit["position"]
	var hit_normal: Vector3 = hit["normal"]
	var depth_limit: float = float(max(brush_size * 0.65, 0.02))

	for global_index in range(vertices.size()):
		var to_vertex: Vector3 = vertices[global_index] - hit_position
		var distance: float = to_vertex.length()
		if distance > brush_size:
			continue

		if front_face_only:
			var plane_distance: float = abs(to_vertex.dot(hit_normal))
			if plane_distance > depth_limit:
				continue
			if global_index < normals.size():
				var vertex_normal: Vector3 = normals[global_index]
				if vertex_normal.length_squared() > RAY_EPSILON and vertex_normal.dot(hit_normal) < -0.15:
					continue

		affected.append({
			"index": global_index,
			"distance": distance,
		})

	return affected


func _apply_brush_to_vertices(affected_vertices: Array, brush_size: float) -> int:
	if _weight_map == null or affected_vertices.is_empty():
		return 0

	var strength: float = float(_brush.get("strength", 0.35))
	var falloff: float = float(max(float(_brush.get("falloff", 1.0)), 0.001))
	var mode: String = String(_brush.get("mode", "add"))
	var target_weight: float = float(clamp(float(_brush.get("target_weight", 1.0)), 0.0, 1.0))
	var safe_brush_size: float = float(max(brush_size, 0.0001))
	var smooth_average: float = 0.0

	if mode == "smooth":
		for item in affected_vertices:
			smooth_average += _weight_map.get_weight(int(item["index"]))
		smooth_average /= float(affected_vertices.size())

	var changed_count := 0
	for item in affected_vertices:
		var global_index: int = int(item["index"])
		var distance: float = float(item["distance"])
		var normalized_distance: float = distance / safe_brush_size
		var influence: float = float(pow(1.0 - normalized_distance, falloff))
		var alpha: float = float(clamp(strength * influence, 0.0, 1.0))
		var before_value: float = _weight_map.get_weight(global_index)
		var after_value: float = before_value

		match mode:
			"subtract":
				after_value = before_value - alpha
			"set":
				after_value = before_value + (target_weight - before_value) * alpha
			"smooth":
				after_value = before_value + (smooth_average - before_value) * alpha
			_:
				after_value = before_value + alpha

		after_value = float(clamp(after_value, 0.0, 1.0))
		if abs(after_value - before_value) > 0.00001:
			_weight_map.set_weight_silent(global_index, after_value)
			changed_count += 1

	return changed_count


func _begin_paint_stroke() -> void:
	if _stroke_active or _weight_map == null:
		return
	_stroke_active = true
	_stroke_changed = false
	_stroke_before_weights = _copy_weights(_weight_map.weights)


func _end_paint_stroke() -> void:
	if not _stroke_active:
		return
	var changed := _stroke_changed
	var before_weights: PackedFloat32Array = _copy_weights(_stroke_before_weights)
	var edited_map: JiggleWeightMap = _weight_map
	var after_weights := PackedFloat32Array()
	if edited_map != null:
		after_weights = _copy_weights(edited_map.weights)

	_stroke_active = false
	_stroke_changed = false
	_stroke_before_weights = PackedFloat32Array()

	if not changed or edited_map == null:
		return

	var undo_redo: EditorUndoRedoManager = get_undo_redo()
	undo_redo.create_action("Jiggle Paint Stroke")
	undo_redo.add_do_method(self, "_apply_weight_snapshot", edited_map, after_weights)
	undo_redo.add_undo_method(self, "_apply_weight_snapshot", edited_map, before_weights)
	undo_redo.commit_action(false)


func _apply_weight_snapshot(map: JiggleWeightMap, snapshot: PackedFloat32Array) -> void:
	if map == null:
		return
	map.copy_weights_from(snapshot)
	if map == _weight_map:
		if _dock != null:
			_dock.refresh_weight_stats()
		_refresh_preview_colors()


func _copy_weights(source: PackedFloat32Array) -> PackedFloat32Array:
	var copy := PackedFloat32Array()
	copy.resize(source.size())
	for i in range(source.size()):
		copy[i] = source[i]
	return copy


func _ensure_brush_preview_instance() -> void:
	if _brush_preview_instance != null and is_instance_valid(_brush_preview_instance):
		return
	if _selected_mesh == null:
		return

	_brush_preview_instance = MeshInstance3D.new()
	_brush_preview_instance.name = "__JigglePaintBrushPreview"
	_brush_preview_instance.top_level = true
	_brush_preview_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(1.0, 0.85, 0.12, 0.95)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_try_set_property(material, "no_depth_test", true)
	_brush_preview_instance.material_override = material

	var parent := _selected_mesh.get_parent()
	if parent != null:
		parent.add_child(_brush_preview_instance)


func _update_brush_ring(position: Vector3, normal: Vector3, radius: float) -> void:
	_ensure_brush_preview_instance()
	if _brush_preview_instance == null or not is_instance_valid(_brush_preview_instance):
		return
	_brush_preview_instance.visible = true
	_brush_preview_instance.global_transform = Transform3D.IDENTITY
	_brush_preview_instance.mesh = _build_brush_ring_mesh(position, normal, radius)


func _refresh_brush_preview_mesh() -> void:
	# The ring is rebuilt on the next hover/paint event. This keeps brush-setting
	# changes cheap on Android.
	pass


func _hide_brush_preview() -> void:
	if _brush_preview_instance != null and is_instance_valid(_brush_preview_instance):
		_brush_preview_instance.visible = false


func _remove_brush_preview_instance() -> void:
	if _brush_preview_instance != null and is_instance_valid(_brush_preview_instance):
		_brush_preview_instance.queue_free()
	_brush_preview_instance = null


func _try_set_property(object: Object, property_name: String, value: Variant) -> void:
	for property in object.get_property_list():
		if String(property.get("name", "")) == property_name:
			object.set(property_name, value)
			return


func _build_brush_ring_mesh(position: Vector3, normal: Vector3, radius: float) -> ArrayMesh:
	var mesh := ArrayMesh.new()
	var safe_radius: float = float(max(radius, 0.001))
	var safe_normal: Vector3 = normal
	if safe_normal.length_squared() <= RAY_EPSILON:
		safe_normal = Vector3.UP
	safe_normal = safe_normal.normalized()

	var tangent: Vector3 = safe_normal.cross(Vector3.UP)
	if tangent.length_squared() <= RAY_EPSILON:
		tangent = safe_normal.cross(Vector3.RIGHT)
	tangent = tangent.normalized()
	var bitangent: Vector3 = safe_normal.cross(tangent).normalized()
	var raised_position: Vector3 = position + safe_normal * 0.01

	var vertices := PackedVector3Array()
	for segment_index in range(BRUSH_RING_SEGMENTS):
		var angle_a: float = TAU * float(segment_index) / float(BRUSH_RING_SEGMENTS)
		var angle_b: float = TAU * float(segment_index + 1) / float(BRUSH_RING_SEGMENTS)
		var point_a: Vector3 = raised_position + (tangent * cos(angle_a) + bitangent * sin(angle_a)) * safe_radius
		var point_b: Vector3 = raised_position + (tangent * cos(angle_b) + bitangent * sin(angle_b)) * safe_radius
		vertices.push_back(point_a)
		vertices.push_back(point_b)

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_LINES, arrays)
	return mesh


func _rebuild_preview_instance() -> void:
	_remove_preview_instance()
	if not _paint_enabled:
		return
	if _selected_mesh == null or _selected_mesh.mesh == null or _weight_map == null:
		return

	_preview_instance = MeshInstance3D.new()
	_preview_instance.name = "__JigglePaintWeightPreview"
	_preview_instance.visible = true
	_preview_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_preview_instance.transform = _selected_mesh.transform
	_preview_instance.mesh = _build_colored_mesh()

	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.vertex_color_use_as_albedo = true
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.albedo_color = Color(1, 1, 1, 0.82)
	_preview_instance.material_override = material

	var parent := _selected_mesh.get_parent()
	if parent != null:
		parent.add_child(_preview_instance)


func _remove_preview_instance() -> void:
	if _preview_instance != null and is_instance_valid(_preview_instance):
		_preview_instance.queue_free()
	_preview_instance = null


func _refresh_preview_colors() -> void:
	if _preview_instance == null or not is_instance_valid(_preview_instance):
		if _paint_enabled:
			_rebuild_preview_instance()
		return
	_preview_instance.mesh = _build_colored_mesh()


func _build_colored_mesh() -> ArrayMesh:
	var colored_mesh := ArrayMesh.new()
	if _selected_mesh == null or _selected_mesh.mesh == null or _weight_map == null:
		return colored_mesh

	var source_mesh := _selected_mesh.mesh
	var global_index := 0
	for surface_index in range(source_mesh.get_surface_count()):
		var arrays: Array = source_mesh.surface_get_arrays(surface_index)
		var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var colors := PackedColorArray()
		colors.resize(vertices.size())
		for vertex_index in range(vertices.size()):
			colors[vertex_index] = WeightMapScript.color_for_weight(_weight_map.get_weight(global_index))
			global_index += 1
		arrays[Mesh.ARRAY_COLOR] = colors
		# PrimitiveMesh resources such as BoxMesh/SphereMesh do not expose
		# surface_get_primitive_type(), even though surface_get_arrays() works.
		# The generated color-preview overlay is triangle-based, which is correct
		# for Godot's built-in 3D PrimitiveMesh surfaces and imported meshes.
		colored_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return colored_mesh
